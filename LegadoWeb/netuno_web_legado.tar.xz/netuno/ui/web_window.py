"""
Janela Desktop Nativa com Interface Web Moderna Integrada (PySide6 / QWebEngineView).
Inicia o servidor FastAPI local em segundo plano e renderiza a interface React/Vite
dentro de uma janela Desktop nativa com aceleração de hardware.
"""

from __future__ import annotations

import os
import sys
import time
import socket
import threading
import subprocess
import webbrowser
from pathlib import Path

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QMessageBox, QProgressBar, QLabel
)
from PySide6.QtCore import Qt, QUrl, QTimer
from PySide6.QtGui import QIcon, QPixmap, QKeySequence, QShortcut

from netuno import APP_VERSION_LABEL, __version__
from netuno.ui.translation import get_resource_path


def find_free_port(preferred: int = 8000) -> int:
    """Retorna uma porta TCP livre, priorizando a porta 8000."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", preferred))
            return preferred
    except OSError:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]


def start_backend_server(port: int) -> uvicorn.Server:
    """Inicia o servidor FastAPI em thread de segundo plano (daemon)."""
    import uvicorn
    from netuno_web.backend.main import app

    os.environ["NETUNO_ALLOW_INLINE"] = "true"
    os.environ["NETUNO_SERVER_PORT"] = str(port)

    config = uvicorn.Config(
        app=app,
        host="127.0.0.1",
        port=port,
        log_level="warning",
        access_log=False,
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    return server


def wait_for_server(port: int, timeout: float = 6.0) -> bool:
    """Aguarda o servidor FastAPI responder na porta local."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.2)
                if s.connect_ex(("127.0.0.1", port)) == 0:
                    return True
        except Exception:
            pass
        time.sleep(0.08)
    return False


class WebEngineDesktopWindow(QMainWindow):
    """Janela Nativa Desktop que renderiza a aplicação Web completa via Chromium/QtWebEngine."""

    def __init__(self, port: int, parent=None):
        super().__init__(parent)
        self.port = port
        self.url_str = f"http://127.0.0.1:{self.port}/netuno/"
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(f"Netuno {__version__} · Aproveitamento de Água de Chuva (UFSC)")
        self.setMinimumSize(1024, 700)

        # Ícone da janela
        icon_path = get_resource_path("Netuno2.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        # Cria a WebEngineView
        try:
            from PySide6.QtWebEngineWidgets import QWebEngineView
            from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings

            self.web_view = QWebEngineView(self)
            
            # Habilita suporte a LocalStorage e WebGL
            profile = self.web_view.page().profile()
            settings = self.web_view.page().settings()
            settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
            settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
            settings.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
            
            self.setCentralWidget(self.web_view)
            self.web_view.setUrl(QUrl(self.url_str))

            # Atalhos úteis de navegação
            self.shortcut_reload = QShortcut(QKeySequence("F5"), self)
            self.shortcut_reload.activated.connect(self.web_view.reload)

            self.shortcut_reload_ctrl = QShortcut(QKeySequence("Ctrl+R"), self)
            self.shortcut_reload_ctrl.activated.connect(self.web_view.reload)

            self.shortcut_fullscreen = QShortcut(QKeySequence("F11"), self)
            self.shortcut_fullscreen.activated.connect(self.toggle_fullscreen)

        except Exception as e:
            # Fallback se QWebEngine falhar na inicialização
            central = QWidget(self)
            layout = QVBoxLayout(central)
            lbl = QLabel(f"O servidor local está ativo em:\n{self.url_str}\n\nAbrindo no seu navegador...")
            lbl.setAlignment(Qt.AlignCenter)
            layout.addWidget(lbl)
            self.setCentralWidget(central)
            webbrowser.open(self.url_str)

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()


def launch_native_browser_app(url: str) -> bool:
    """Tenta abrir o navegador em modo aplicativo (janela limpa e sem abas)."""
    # Candidatos a executáveis do Edge e Chrome no Windows
    candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ]

    for exe in candidates:
        if os.path.exists(exe):
            try:
                subprocess.Popen([exe, f"--app={url}"])
                return True
            except Exception:
                pass

    return webbrowser.open(url)


def run_web_desktop_app(legacy_qt: bool = False, force_browser: bool = False):
    """Ponto de entrada unificado para rodar o Netuno Desktop com a interface Web moderna."""
    port = find_free_port(8000)
    start_backend_server(port)
    wait_for_server(port)

    url = f"http://127.0.0.1:{port}/netuno/"

    if force_browser:
        print(f"[Netuno 5] Abrindo no navegador: {url}")
        launch_native_browser_app(url)
        return

    # Tenta rodar a janela nativa PySide6 com QWebEngineView
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Netuno 5")
    app.setOrganizationName("Grupo de Pesquisa Gestão do Espaço Sustentável")

    try:
        from PySide6.QtWebEngineWidgets import QWebEngineView
        window = WebEngineDesktopWindow(port=port)
        
        primary_screen = app.primaryScreen()
        if primary_screen is not None:
            window.setGeometry(primary_screen.geometry())
            window.winId()
            if window.windowHandle() is not None:
                window.windowHandle().setScreen(primary_screen)
        
        window.showMaximized()
        sys.exit(app.exec())
    except Exception as e:
        print(f"[Aviso] WebEngine não disponível ({e}). Abrindo no navegador dedicado...")
        launch_native_browser_app(url)
        # Mantém processo vivo para atender requisições locais se executado via CLI
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
