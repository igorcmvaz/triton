# Netuno 5 Web

Aplicação web isolada do Netuno 5. O aplicativo desktop continua em `main.py` e `netuno/ui`; a edição web reutiliza diretamente o mesmo motor científico em `netuno/core`.

## Arquitetura

- `frontend/`: React, TypeScript, Vite, Recharts e interface responsiva em 11 etapas.
- `backend/`: API FastAPI em `/netuno/api/v1`.
- `worker/`: tarefas de simulação executadas pela fila RQ.
- Redis: fila, estado transitório e limitação de tarefas.
- Volume `results`: resultados temporários, removidos após 24 horas.

O navegador mantém as premissas no armazenamento local. Séries de chuva e resultados enviados ao servidor não são histórico de usuário e expiram automaticamente.

## Desenvolvimento local

Use Python 3.11 ou superior a partir da raiz do repositório:

```powershell
python -m pip install -r netuno_web/requirements.txt
$env:NETUNO_ALLOW_INLINE="true"
$env:NETUNO_REDIS_URL="redis://127.0.0.1:6399/15"
python -m uvicorn netuno_web.backend.main:app --reload --port 8000
```

Em outro terminal:

```powershell
cd netuno_web/frontend
npm install
npm run dev
```

A interface abre em `http://localhost:5173/netuno/` e encaminha a API para a porta 8000. O modo inline é exclusivo de desenvolvimento e testes.

## Docker e UFSC

```powershell
cd netuno_web
Copy-Item .env.example .env
docker compose up --build -d
```

O serviço é publicado localmente na porta 8080. No proxy reverso institucional, encaminhe `/netuno` para esse serviço preservando `X-Forwarded-For` e `X-Forwarded-Proto`. O Nginx interno já encaminha `/netuno/api/` para a API.

A base climática nacional possui vários gigabytes e não é copiada para a imagem. `NETUNO_CLIMATE_DATA_DIR` aponta para a pasta no host, montada em modo somente leitura nos containers da API e do worker.

Antes da publicação:

1. Troque `NETUNO_ADMIN_TOKEN` por segredo longo mantido fora do repositório.
2. Mantenha `NETUNO_ADMIN_UPDATES_ENABLED=false` até configurar backup e procedimento de revisão tarifária.
3. Restrinja a rota administrativa no proxy da UFSC além do token da aplicação.
4. Agende diariamente `python -m netuno_web.worker.cleanup` no container do worker.
5. Ajuste CPU, memória e quantidade de workers após um teste de carga no servidor real.

## Testes

```powershell
python -m pytest netuno_web/tests tests
cd netuno_web/frontend
npm run build
```

Os testes web verificam a API, o ciclo de tarefas e o uso do motor compartilhado. A suíte original deve continuar passando para proteger o aplicativo desktop.

Os critérios de convergência, auditabilidade e capacidade estão documentados em
`additional_material/documentation/auditoria_web_desktop.md`.

## Download do desktop

A interface contém o link `/downloads/Netuno-Setup.exe`. O proxy ou site institucional deve servir nesse caminho o instalador produzido pelo fluxo existente em `build_exe.py`/Inno Setup.
