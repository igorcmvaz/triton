"""Edição web do Netuno 5, isolada da interface desktop."""

