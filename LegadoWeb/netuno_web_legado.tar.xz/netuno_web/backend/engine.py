from __future__ import annotations

import json
import math
import tempfile
from datetime import datetime, timedelta
from dataclasses import asdict, fields
from pathlib import Path
from typing import Any

import numpy as np

from netuno.cli import _validate_analysis_config, _validate_config, run_analysis
from netuno.core.parser import NetunoConfig, load_netuno_project


CONFIG_FIELDS = {item.name for item in fields(NetunoConfig)}
FLAT_ALIASES = {
    "runoff": "runoff_coeff",
    "residents": "residents_count",
    "demand": "demand_value",
    "share": "rainwater_share",
    "upper_vol": "upper_tank_vol",
    "upper_used": "upper_tank_used",
    "sweep_max": "lower_tank_max",
    "sweep_step": "lower_tank_step",
}


def rainfall_statistics(rainfall: np.ndarray, start_date: str) -> dict[str, Any]:
    """Return calendar-aware, auditable rainfall summary statistics."""
    try:
        first_day = datetime.strptime(start_date, "%d/%m/%Y").date()
    except (TypeError, ValueError):
        first_day = datetime(1980, 1, 1).date()

    monthly_totals: dict[tuple[int, int], float] = {}
    for offset, value in enumerate(rainfall):
        day = first_day + timedelta(days=offset)
        key = (day.year, day.month)
        monthly_totals[key] = monthly_totals.get(key, 0.0) + float(value)

    by_month: list[list[float]] = [[] for _ in range(12)]
    for (_, month), total in monthly_totals.items():
        by_month[month - 1].append(total)
    month_names = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
    monthly = [
        {
            "month": index + 1,
            "name": name,
            "mm": float(np.mean(by_month[index])) if by_month[index] else 0.0,
            "observations": len(by_month[index]),
        }
        for index, name in enumerate(month_names)
    ]
    total_days = len(rainfall)
    rainy_days = int(np.count_nonzero(rainfall > 0.1))
    return {
        "total_days": total_days,
        "start_date": first_day.strftime("%d/%m/%Y"),
        "end_date": (first_day + timedelta(days=total_days - 1)).strftime("%d/%m/%Y"),
        "annual_average_mm": float(np.sum(rainfall) * 365.25 / total_days),
        "max_daily_mm": float(np.max(rainfall)),
        "rainy_days_count": rainy_days,
        "dry_days_count": total_days - rainy_days,
        "rainy_days_pct": float(rainy_days * 100.0 / total_days),
        "monthly_averages_mm": monthly,
        "methodology": "Totais por mês-calendário, promediados entre os anos disponíveis.",
    }


def config_from_mapping(raw: dict[str, Any]) -> NetunoConfig:
    cfg = NetunoConfig()
    for key, value in raw.items():
        target = FLAT_ALIASES.get(key, key)
        if target not in CONFIG_FIELDS or value is None:
            continue
        if target == "rainwater_share" and float(value) > 1:
            value = float(value) / 100.0
        if target == "pipes_list":
            value = [tuple(item) for item in value]
        if target in {"water_tariffs", "op_costs"}:
            value = [tuple(item) for item in value]
        setattr(cfg, target, value)
    if "pump_thresh_pct" in raw and "pumping_threshold" not in raw:
        cfg.pumping_threshold = cfg.upper_tank_vol * float(raw["pump_thresh_pct"]) / 100.0
    if "tma_annual" in raw and "tma" not in raw:
        cfg.tma = (math.pow(1 + float(raw["tma_annual"]) / 100.0, 1 / 12) - 1) * 100
    if "inflation_annual" in raw and "inflation" not in raw:
        cfg.inflation = (math.pow(1 + float(raw["inflation_annual"]) / 100.0, 1 / 12) - 1) * 100
    return cfg


def parse_project_document(document: dict[str, Any]) -> dict[str, Any]:
    schema_name = document.get("schema", {}).get("name")
    if schema_name == "netuno-project":
        with tempfile.TemporaryDirectory(prefix="netuno-web-import-") as folder:
            path = Path(folder) / "project.netuno"
            path.write_text(json.dumps(document, ensure_ascii=False), encoding="utf-8")
            bundle = load_netuno_project(str(path))
        cfg = bundle["config"]
        # Projetos salvos pela edição web mantêm o schema interoperável e um
        # bloco explícito com campos que ainda não existem no schema 2.
        if isinstance(document.get("web_config"), dict):
            cfg = config_from_mapping({**asdict(cfg), **document["web_config"]})
        rainfall = bundle.get("precip_data")
        return {
            "config": asdict(cfg),
            "rainfall_mm": rainfall.tolist() if rainfall is not None else [],
            "metadata": document.get("metadata", {}),
            "analysis": bundle.get("analysis", {}),
            "ui_state": bundle.get("ui_state", {}),
        }

    # Compatibilidade com os estudos de caso planos usados no repositório.
    cfg = config_from_mapping(document)
    rainfall_file = document.get("rain_file") or document.get("precip_file")
    rainfall: list[float] = []
    if rainfall_file:
        candidates = [Path("data/rainfall") / Path(str(rainfall_file)).name, Path(str(rainfall_file))]
        for candidate in candidates:
            if candidate.is_file():
                from netuno.core.parser import load_precipitation

                rainfall = load_precipitation(str(candidate)).tolist()
                break
    return {"config": asdict(cfg), "rainfall_mm": rainfall, "metadata": document, "analysis": {}}


def parse_uploaded_project(data: bytes, filename: str) -> dict[str, Any]:
    suffix = Path(filename).suffix.lower()
    if suffix in {".netuno", ".json"}:
        try:
            return parse_project_document(json.loads(data.decode("utf-8-sig")))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("O arquivo não contém um projeto JSON válido.") from exc
    if suffix not in {".csv", ".txt"}:
        raise ValueError("Formato de projeto não aceito. Use .netuno, .json ou CSV legado.")
    with tempfile.TemporaryDirectory(prefix="netuno-web-import-") as folder:
        path = Path(folder) / f"project{suffix}"
        path.write_bytes(data)
        bundle = load_netuno_project(str(path))
    cfg = bundle["config"]
    rainfall = bundle.get("precip_data")
    return {
        "config": asdict(cfg),
        "rainfall_mm": rainfall.tolist() if rainfall is not None else [],
        "metadata": {"source_file": Path(filename).name, "legacy": True},
        "analysis": bundle.get("analysis", {}),
        "ui_state": bundle.get("ui_state", {}),
    }


def execute_analysis(payload: dict[str, Any]) -> dict[str, Any]:
    cfg = config_from_mapping(payload.get("config", {}))
    rainfall = np.asarray(payload.get("rainfall_mm", []), dtype=np.float64)
    analysis = payload.get("analysis", "all")
    environmental = payload.get("environmental", {}) or {}
    errors = _validate_config(cfg, rainfall) + _validate_analysis_config({"environmental": environmental})
    if errors:
        raise ValueError("; ".join(errors))
    result = run_analysis(
        cfg,
        rainfall,
        analysis_type="all" if analysis == "topsis" else analysis,
        weights=tuple(payload.get("weights", (0.33, 0.33, 0.34))),
        environmental=environmental,
        source=str(payload.get("source", "Netuno Web")),
        weight_sensitivity=int(payload.get("weight_sensitivity", 0)),
        seed=int(payload.get("seed", 42)),
    )

    # Estatísticas seguem o calendário real do projeto; dividir a série em 12
    # blocos iguais mistura meses e anos quando há mais de um ano de dados.
    if len(rainfall) > 0:
        result["rainfall_stats"] = rainfall_statistics(rainfall, cfg.start_date)

    # Determine optimal or designated volume
    opt_vol = 0.0
    if "topsis" in result and result["topsis"].get("best_volume_l") is not None:
        opt_vol = float(result["topsis"]["best_volume_l"])
    elif "technical" in result and result["technical"].get("summary", {}).get("optimal_volume_l") is not None:
        opt_vol = float(result["technical"]["summary"]["optimal_volume_l"])
    elif result.get("technical", {}).get("alternatives"):
        opt_vol = float(result["technical"]["alternatives"][-1]["lower_tank_volume_l"])

    # Run single detailed simulation for optimal volume
    if len(rainfall) > 0 and opt_vol >= 0:
        from netuno.core.simulation import run_single_simulation
        from netuno.core.economic import run_economic_analysis
        import copy

        total_demand = cfg.demand_value * (cfg.residents_count if cfg.residents_count > 0 else 1)
        single_res = run_single_simulation(
            precip_data=rainfall,
            lower_tank_vol=opt_vol,
            area=cfg.area,
            runoff_coeff=cfg.runoff_coeff,
            discard_mm=cfg.discard,
            discard_mode=cfg.discard_mode,
            discard_days_interval=cfg.discard_days_interval,
            total_demand_per_day=total_demand,
            rainwater_share=cfg.rainwater_share,
            upper_tank_vol=cfg.upper_tank_vol,
            upper_tank_used=bool(cfg.upper_tank_used),
            pumping_threshold=cfg.pumping_threshold,
            monthly_demands=cfg.demand_monthly or None,
            monthly_residents=cfg.residents_monthly or None,
            start_date_str=cfg.start_date,
        )
        result["single_sim"] = {
            "lower_tank_vol_l": opt_vol,
            "potential_savings_pct": single_res.potential_potable_savings_pct,
            "annual_pluvial_m3": single_res.annual_pluvial_consumed_m3,
            "annual_potable_consumed_m3": single_res.annual_potable_consumed_m3,
            "annual_spill_m3": single_res.annual_spill_m3,
            "pct_days_full_satisfaction": single_res.pct_days_full_satisfaction,
            "pct_days_partial_satisfaction": single_res.pct_days_partial_satisfaction,
            "pct_days_null_satisfaction": single_res.pct_days_null_satisfaction,
            "total_pumped_m3": single_res.total_pumped_liters / 1000.0,
            "total_pump_cycles": single_res.total_pump_cycles,
            "monthly_results": single_res.monthly_results,
        }

        # Run detailed economic analysis for optimal volume
        candidate_cfg = copy.copy(cfg)
        candidate_cfg.econ_lower_tank_vol = opt_vol
        econ_analysis = run_economic_analysis(candidate_cfg, single_res)
        
        # Aggregate 20-year annual cash flows
        annual_cfs = []
        cfs = econ_analysis.monthly_cash_flows or []
        n_years = int(cfg.analysis_period_years or 20)
        
        for yr in range(1, n_years + 1):
            start_m = (yr - 1) * 12
            end_m = min(yr * 12, len(cfs))
            year_slice = cfs[start_m:end_m]
            if year_slice:
                gross_sav = sum(m.water_savings for m in year_slice)
                pump_cost = sum(m.pump_cost for m in year_slice)
                om_cost = sum(m.om_cost for m in year_slice)
                chlorine_cost = sum(m.chlorine_cost for m in year_slice)
                net_sav = sum(m.net_savings for m in year_slice)
                disc_net_sav = sum(m.discounted_net_savings for m in year_slice)
                cum_disc = year_slice[-1].cumulative_discounted
                annual_cfs.append({
                    "year": yr,
                    "gross_savings_brl": gross_sav,
                    "pump_cost_brl": pump_cost,
                    "om_cost_brl": om_cost,
                    "chlorine_cost_brl": chlorine_cost,
                    "net_savings_brl": net_sav,
                    "discounted_net_savings_brl": disc_net_sav,
                    "cumulative_npv_brl": cum_disc,
                })
        
        # Calculate LCOW (Levelized Cost of Water) & B/C Ratio
        monthly_discount_rate = cfg.tma / 100.0
        pv_opex = sum(
            (item.pump_cost + item.om_cost + item.chlorine_cost)
            / ((1.0 + monthly_discount_rate) ** item.month)
            for item in cfs
        )
        pv_water_vol_m3 = sum(
            single_res.annual_pluvial_consumed_m3 / ((1.0 + monthly_discount_rate) ** (12 * yr))
            for yr in range(1, n_years + 1)
        ) if n_years > 0 else 1.0
        pv_gross_savings = sum(
            (item.water_savings + item.iptu_savings)
            / ((1.0 + monthly_discount_rate) ** item.month)
            for item in cfs
        )

        lcow = (econ_analysis.capex_total + pv_opex) / max(0.001, pv_water_vol_m3)
        bc_ratio = pv_gross_savings / max(1.0, econ_analysis.capex_total + pv_opex)

        result["economic_details"] = {
            "capex_total_brl": econ_analysis.capex_total,
            "vpl_brl": econ_analysis.vpl,
            "tir_annual_pct": econ_analysis.tir_annual_pct,
            "payback_months": econ_analysis.payback_months,
            "payback_years": econ_analysis.payback_years,
            "annual_water_savings_brl": econ_analysis.annual_water_savings_brl,
            "annual_opex_brl": econ_analysis.annual_opex_brl,
            "annual_pump_kwh": econ_analysis.annual_pump_kwh,
            "annual_pump_cost_brl": econ_analysis.annual_pump_cost_brl,
            "lcow_brl_m3": lcow,
            "benefit_cost_ratio": bc_ratio,
            "discount_rate_monthly_pct": cfg.tma,
            "discount_rate_annual_effective_pct": ((1.0 + monthly_discount_rate) ** 12 - 1.0) * 100.0,
            "annual_cash_flows": annual_cfs,
            "capex_breakdown": {
                "lower_tank": float(cfg.cost_lower_tank or 0),
                "upper_tank": float(cfg.cost_upper_tank or 0) if cfg.upper_tank_used else 0,
                "pump": float(cfg.pump_unit_cost or 650) * int(cfg.pump_count or 1),
                "piping": float(cfg.cost_piping or 0),
                "accessories": float(cfg.cost_accessories or 0),
                "labor": float(cfg.cost_labor or 0),
            },
        }

    return result


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value
