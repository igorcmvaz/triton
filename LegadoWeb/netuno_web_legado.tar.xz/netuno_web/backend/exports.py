from __future__ import annotations

import csv
import io
import json
from html import escape
from typing import Any

from netuno import get_auditable_filename
from netuno.core.report_service import generate_report_html


def flatten_rows(report: dict[str, Any]) -> list[dict[str, Any]]:
    rows = {
        row["lower_tank_volume_l"]: dict(row)
        for row in report.get("technical", {}).get("alternatives", [])
    }
    for section in ("economic", "environmental"):
        for row in report.get(section, {}).get("alternatives", []):
            rows.setdefault(row["lower_tank_volume_l"], {}).update(row)
    ranks = {row["lower_tank_volume_l"]: row for row in report.get("topsis", {}).get("ranking", [])}
    for volume, row in rows.items():
        rank = ranks.get(volume, {})
        row.update({f"topsis_{key}": value for key, value in rank.items() if not isinstance(value, dict)})
    return list(rows.values())


def build_project_data(report: dict[str, Any], volume: float | None = None) -> dict[str, Any]:
    technical = report.get("technical", {})
    summary = technical.get("summary", {})
    alternatives = technical.get("alternatives", [])
    config = report.get("config", {}) or summary.get("config", {})
    optimum_vol = volume if volume is not None else (summary.get("optimal_volume_l") or (alternatives[-1].get("lower_tank_volume_l") if alternatives else 2000.0))

    opt_tech = next((r for r in alternatives if abs(r.get("lower_tank_volume_l", 0) - optimum_vol) < 0.1), alternatives[-1] if alternatives else {})
    econ_alt = report.get("economic", {}).get("alternatives", [])
    opt_econ = next((r for r in econ_alt if abs(r.get("lower_tank_volume_l", 0) - optimum_vol) < 0.1), econ_alt[-1] if econ_alt else {})
    env_alt = report.get("environmental", {}).get("alternatives", [])
    opt_env = next((r for r in env_alt if abs(r.get("lower_tank_volume_l", 0) - optimum_vol) < 0.1), env_alt[-1] if env_alt else {})

    pluv_day = opt_tech.get("annual_rainwater_m3", 0) * 1000.0 / 365.0
    potable_day = opt_tech.get("potable_consumed_m3_yr", 0) * 1000.0 / 365.0 if "potable_consumed_m3_yr" in opt_tech else 0.0
    spill_day = opt_tech.get("annual_overflow_m3", 0) * 1000.0 / 365.0

    topsis_candidates = []
    if "topsis" in report and report["topsis"].get("ranking"):
        for rank_item in report["topsis"]["ranking"]:
            vol = rank_item.get("lower_tank_volume_l", 0)
            t_row = next((r for r in alternatives if r.get("lower_tank_volume_l") == vol), {})
            e_row = next((r for r in econ_alt if r.get("lower_tank_volume_l") == vol), {})
            v_row = next((r for r in env_alt if r.get("lower_tank_volume_l") == vol), {})
            topsis_candidates.append({
                "volume": vol,
                "saving": t_row.get("potable_savings_pct", 0),
                "water_m3": t_row.get("annual_rainwater_m3", 0),
                "capex": e_row.get("capex_total_brl", opt_econ.get("capex_total_brl", 0)),
                "vpl": e_row.get("npv_brl", 0),
                "co2": v_row.get("lifetime_net_co2_saved_kg", 0),
                "score": rank_item.get("score", 0),
                "rank": rank_item.get("rank", 0),
                "is_best": vol == report["topsis"].get("best_volume_l"),
            })

    metadata = report.get("metadata", {})
    project_name = metadata.get("name") or config.get("project_name") or "Projeto Netuno Web"
    return {
        "project_name": project_name,
        "ref_code": metadata.get("project_id") or config.get("project_id") or project_name,
        "rain_file": report.get("metadata", {}).get("rain_file") or "Série Climatológica",
        "area": config.get("area", 100.0),
        "runoff": config.get("runoff_coeff", 0.85),
        "discard": config.get("discard", 1.0),
        "residents": config.get("residents_count", 4),
        "demand": config.get("demand_value", 120.0),
        "share": config.get("rainwater_share", 0.40),
        "lower_vol": optimum_vol,
        "potential_pct": opt_tech.get("potable_savings_pct", 0.0),
        "pluv_day": pluv_day,
        "potable_day": potable_day,
        "spill_day": spill_day,
        "sat_full": opt_tech.get("satisfaction_full_days_pct", opt_tech.get("potable_savings_pct", 0.0)),
        "sat_null": opt_tech.get("satisfaction_zero_days_pct", 0.0),
        "capex": opt_econ.get("capex_total_brl", 8500.0),
        "annual_gross": opt_econ.get("annual_gross_savings_first_year_brl", 2500.0),
        "vpl": opt_econ.get("npv_brl", 15000.0),
        "tir": opt_econ.get("tir_annual_pct", 25.0),
        "payback_s": opt_econ.get("simple_payback_years", "--"),
        "payback_d": (opt_econ.get("discounted_payback_months", 0) / 12.0) if opt_econ.get("discounted_payback_months") else "--",
        "topsis_candidates": topsis_candidates,
        "audit_context": {
            "climate_location": " / ".join(filter(None, [
                str(config.get("climate_city_name", "") or ""),
                str(config.get("climate_city_uf", "") or ""),
            ])) or "-",
            "climate_basis": " · ".join(filter(None, [
                str(config.get("climate_model", "") or ""),
                str(config.get("climate_scenario", "") or ""),
            ])) or "Série observada",
            "climate_period": " a ".join(filter(None, [
                str(config.get("climate_start_date", "") or ""),
                str(config.get("climate_end_date", "") or ""),
            ])) or "-",
            "analysis_period_years": config.get("analysis_period_years", 20),
            "tariff_location": " / ".join(filter(None, [
                str(config.get("tariff_city_name", "") or ""),
                str(config.get("tariff_city_uf", "") or ""),
            ])) or "-",
        },
    }


def render_html(report: dict[str, Any], report_type: str = "summary", lang: str = "pt", volume: float | None = None) -> str:
    project_data = build_project_data(report, volume=volume)
    if report_type != "summary":
        return generate_report_html(report_type, project_data, lang=lang)

    rows = flatten_rows(report)
    columns = list(dict.fromkeys(key for row in rows for key in row))
    head = "".join(f"<th>{escape(str(column))}</th>" for column in columns)
    body = "".join(
        "<tr>" + "".join(f"<td>{escape(str(row.get(column, '')))}</td>" for column in columns) + "</tr>"
        for row in rows
    )
    return f"""<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><title>Relatório Netuno</title>
<style>@page{{size:A4 landscape;margin:12mm}}body{{font:12px Arial;color:#16322b}}h1{{color:#075e54}}table{{border-collapse:collapse;width:100%}}th{{background:#075e54;color:#fff}}td,th{{border:1px solid #bad0ca;padding:6px;text-align:right}}td:first-child,th:first-child{{text-align:left}}</style>
</head><body><h1>Netuno 5 — Relatório de análise</h1><p>Gerado em {escape(str(report.get('generated_at_utc', '')))}</p><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></body></html>"""


def export_bytes(report: dict[str, Any], fmt: str, report_type: str = "summary", lang: str = "pt", volume: float | None = None) -> tuple[bytes, str, str]:
    rows = flatten_rows(report)
    project_data = build_project_data(report, volume=volume)
    project_name = project_data["project_name"]
    project_ref = project_data["ref_code"]

    def filename(artifact: str, extension: str) -> str:
        return get_auditable_filename(project_name, project_ref, artifact, extension)

    if fmt == "json":
        return json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8"), "application/json", filename("dados", "json")
    if fmt == "html":
        output_name = filename(f"relatorio-{report_type}", "html")
        return render_html(report, report_type=report_type, lang=lang, volume=volume).encode("utf-8"), "text/html; charset=utf-8", output_name
    if fmt == "csv":
        output = io.StringIO()
        columns = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(output, fieldnames=columns, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
        return output.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8", filename("resultados", "csv")
    if fmt == "xlsx":
        import pandas as pd

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            pd.DataFrame(rows).to_excel(writer, sheet_name="Resultados", index=False)
            pd.DataFrame([report.get("technical", {}).get("summary", {})]).to_excel(writer, sheet_name="Resumo", index=False)
        return output.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename("resultados", "xlsx")
    if fmt == "pdf":
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

        output = io.BytesIO()
        columns = list(dict.fromkeys(key for row in rows for key in row))
        data = [columns] + [[str(row.get(column, "")) for column in columns] for row in rows]
        document = SimpleDocTemplate(output, pagesize=landscape(A4), leftMargin=20, rightMargin=20, topMargin=20, bottomMargin=20)
        styles = getSampleStyleSheet()
        table = Table(data, repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#075e54")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 6),
            ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#9dbbb3")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        document.build([Paragraph("Netuno 5 — Relatório de análise", styles["Title"]), Spacer(1, 8), table])
        return output.getvalue(), "application/pdf", filename(f"relatorio-{report_type}", "pdf")
    if fmt == "dxf":
        import os
        import tempfile
        from netuno.core.cad_exporter import generate_project_dxf
        mode = "block_library" if report_type in {"blocks", "block_library"} else "simple" if report_type == "simple" else "technical_a3"
        mode_slug = {"simple": "esquematico", "technical_a3": "prancha-a3", "block_library": "biblioteca-blocos"}[mode]
        with tempfile.NamedTemporaryFile(suffix=".dxf", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            generate_project_dxf(project_data, tmp_path, mode=mode)
            with open(tmp_path, "rb") as f:
                content = f.read()
        finally:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        return content, "application/dxf", filename(f"desenho-cad-{mode_slug}", "dxf")
    if fmt == "svg":
        from netuno.core.cad_exporter import generate_project_svg_diagram
        mode = "simple" if report_type == "simple" else "technical_a3"
        mode_slug = "esquematico" if mode == "simple" else "prancha-a3"
        svg_content = generate_project_svg_diagram(project_data, mode=mode)
        return svg_content.encode("utf-8"), "image/svg+xml; charset=utf-8", filename(f"diagrama-tecnico-{mode_slug}", "svg")
    raise ValueError("Formato de exportação inválido.")
