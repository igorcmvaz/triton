from __future__ import annotations

import json
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from .engine import execute_analysis, json_safe
from .settings import settings


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def record_path(job_id: str) -> Path:
    safe_id = "".join(char for char in job_id if char.isalnum() or char in "-_")
    return settings.result_dir / f"{safe_id}.json"


def save_record(job_id: str, record: dict[str, Any]) -> None:
    settings.prepare()
    target = record_path(job_id)
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(json_safe(record), ensure_ascii=False), encoding="utf-8")
    temporary.replace(target)


def run_analysis_job(payload: dict[str, Any], job_id: str | None = None) -> dict[str, Any]:
    job_id = job_id or uuid4().hex
    created_at = _now()
    try:
        from rq import get_current_job

        rq_job = get_current_job()
        if rq_job:
            job_id = rq_job.id
            created_at = rq_job.created_at.isoformat() if rq_job.created_at else created_at
            rq_job.meta.update({"progress": 10, "message": "Validando entradas", "started_at": _now()})
            rq_job.save_meta()
    except Exception:
        rq_job = None

    started_at = _now()
    save_record(job_id, {"job_id": job_id, "status": "started", "progress": 10, "message": "Executando análise", "created_at": created_at, "started_at": started_at})
    try:
        result = execute_analysis(payload)
        record = {
            "job_id": job_id,
            "status": "finished",
            "progress": 100,
            "message": "Análise concluída",
            "created_at": created_at,
            "started_at": started_at,
            "finished_at": _now(),
            "result": result,
        }
        save_record(job_id, record)
        if rq_job:
            rq_job.meta.update({"progress": 100, "message": "Análise concluída", "finished_at": record["finished_at"]})
            rq_job.save_meta()
        return result
    except Exception as exc:
        record = {
            "job_id": job_id,
            "status": "failed",
            "progress": 100,
            "message": "Não foi possível concluir a análise",
            "created_at": created_at,
            "started_at": started_at,
            "finished_at": _now(),
            "error": str(exc),
            "traceback": traceback.format_exc(limit=8),
        }
        save_record(job_id, record)
        raise


def run_tariff_update_job(payload: dict[str, Any], job_id: str | None = None) -> dict[str, Any]:
    from netuno.core.tariff_updater.updater_engine import TariffUpdateEngine

    job_id = job_id or uuid4().hex
    started_at = _now()
    save_record(job_id, {"job_id": job_id, "status": "started", "progress": 5, "message": "Atualizando tarifas", "created_at": started_at, "started_at": started_at})
    try:
        result = TariffUpdateEngine().run_update(**payload)
        save_record(job_id, {"job_id": job_id, "status": "finished", "progress": 100, "message": "Atualização tarifária concluída", "created_at": started_at, "started_at": started_at, "finished_at": _now(), "result": result})
        return result
    except Exception as exc:
        save_record(job_id, {"job_id": job_id, "status": "failed", "progress": 100, "message": "Falha na atualização tarifária", "created_at": started_at, "started_at": started_at, "finished_at": _now(), "error": str(exc)})
        raise


def load_record(job_id: str) -> dict[str, Any] | None:
    path = record_path(job_id)
    if not path.is_file():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def cleanup_expired() -> int:
    settings.prepare()
    cutoff = datetime.now(timezone.utc).timestamp() - settings.result_ttl_seconds
    removed = 0
    for path in settings.result_dir.glob("*.json"):
        if path.stat().st_mtime < cutoff:
            path.unlink(missing_ok=True)
            removed += 1
    return removed
