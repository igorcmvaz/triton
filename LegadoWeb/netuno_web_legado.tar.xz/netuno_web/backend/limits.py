from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request

from .queueing import redis_connection
from .settings import settings


_local: dict[str, deque[float]] = defaultdict(deque)


def client_ip(request: Request) -> str:
    # Só considera o primeiro X-Forwarded-For quando o proxy da UFSC sobrescreve o header.
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return forwarded or (request.client.host if request.client else "unknown")


def enforce_job_rate(request: Request) -> None:
    key = client_ip(request)
    epoch_hour = int(time.time() // 3600)
    try:
        connection = redis_connection()
        redis_key = f"netuno:rate:{key}:{epoch_hour}"
        count = connection.incr(redis_key)
        if count == 1:
            connection.expire(redis_key, 3700)
        if count > settings.jobs_per_hour:
            raise HTTPException(status_code=429, detail="Limite de tarefas por hora atingido.")
        return
    except HTTPException:
        raise
    except Exception:
        now = time.time()
        bucket = _local[key]
        while bucket and bucket[0] < now - 3600:
            bucket.popleft()
        if len(bucket) >= settings.jobs_per_hour:
            raise HTTPException(status_code=429, detail="Limite de tarefas por hora atingido.")
        bucket.append(now)

