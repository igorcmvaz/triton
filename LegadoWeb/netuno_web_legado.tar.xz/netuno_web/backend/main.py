from __future__ import annotations

import json
from contextlib import asynccontextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response

from netuno import __version__
from netuno.core.climate_database import CLIMATE_MODELS, CLIMATE_SCENARIOS, load_national_climate_series
from netuno.core.parser import NetunoConfig
from netuno.core.tariffs_database import get_available_ufs, get_cities_by_uf, get_city_data, search_cities

from .engine import parse_project_document, parse_uploaded_project
from .exports import export_bytes
from .jobs import cleanup_expired, load_record
from .limits import enforce_job_rate
from .queueing import cancel, submit, submit_tariff_update
from .schemas import AnalysisRequest, ExportProjectRequest, JobCreated, JobStatus, ProjectDocument, TariffUpdateRequest
from .settings import settings


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.prepare()
    cleanup_expired()
    yield


app = FastAPI(
    title="Netuno 5 Web API",
    version=__version__,
    docs_url=f"{settings.api_prefix}/docs",
    openapi_url=f"{settings.api_prefix}/openapi.json",
    lifespan=lifespan,
)
if settings.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_credentials=False,
        allow_methods=["GET", "POST", "DELETE"],
        allow_headers=["Content-Type", "Authorization", "X-Netuno-Admin-Token"],
    )

api = settings.api_prefix


@app.get(f"{api}/health")
def health() -> dict:
    return {"status": "ok", "app": "Netuno Web", "version": __version__}


@app.get(f"{api}/defaults")
def defaults() -> dict:
    return {"config": asdict(NetunoConfig()), "limits": {"max_upload_mb": settings.max_upload_mb, "max_rainfall_days": settings.max_rainfall_days}}


@app.post(f"{api}/projects/import")
def import_document(payload: ProjectDocument) -> dict:
    return parse_project_document(payload.document)


@app.post(f"{api}/projects/upload")
async def upload_project(file: Annotated[UploadFile, File(...)]) -> dict:
    data = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Arquivo maior que o limite permitido.")
    try:
        return parse_uploaded_project(data, file.filename or "project.netuno")
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post(f"{api}/rainfall/parse")
async def parse_rainfall(file: Annotated[UploadFile, File(...)]) -> dict:
    data = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Arquivo maior que o limite permitido.")
    values = []
    for line in data.decode("utf-8-sig", errors="ignore").splitlines():
        text = line.strip().replace(",", ".")
        if not text:
            values.append(0.0)
            continue
        try:
            value = float(text)
        except ValueError:
            continue
        if value < 0:
            raise HTTPException(status_code=422, detail="A precipitação não pode ser negativa.")
        values.append(value)
        if len(values) > settings.max_rainfall_days:
            raise HTTPException(status_code=413, detail="Série de chuva maior que o limite permitido.")
    if not values:
        raise HTTPException(status_code=422, detail="Nenhum valor de precipitação foi encontrado.")
    return {"file_name": Path(file.filename or "chuva.csv").name, "rainfall_mm": values, "days": len(values)}


@app.get(f"{api}/climate/catalog")
def climate_catalog() -> dict:
    from netuno.core.climate_database import get_available_climate_cities

    return {
        "models": CLIMATE_MODELS,
        "scenarios": [{"key": key, **value} for key, value in CLIMATE_SCENARIOS.items()],
        "cities": get_available_climate_cities(),
    }


@app.get(f"{api}/climate/cities")
def climate_cities(q: str = Query(default="", max_length=120)) -> dict:
    from netuno.core.climate_database import get_available_climate_cities

    cities = get_available_climate_cities()
    if q.strip():
        term = q.strip().lower()
        cities = [c for c in cities if term in c.lower()]
    return {"items": cities}


@app.get(f"{api}/climate/series")
def climate_series(
    city: str = Query(min_length=2, max_length=120),
    model: str = Query(default="INM-CM4"),
    scenario: str = Query(default="HIST"),
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict:
    if model not in CLIMATE_MODELS or scenario not in CLIMATE_SCENARIOS:
        raise HTTPException(status_code=422, detail="Modelo ou cenário climático inválido.")
    try:
        rainfall, effective_start, effective_end, total_days, selected_days, source = load_national_climate_series(
            city, model, scenario, start_date, end_date
        )
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if selected_days > settings.max_rainfall_days:
        raise HTTPException(status_code=413, detail="O recorte climático excede o limite público.")
    return {
        "city": city,
        "model": model,
        "scenario": scenario,
        "start_date": effective_start,
        "end_date": effective_end,
        "total_days_file": total_days,
        "selected_days": selected_days,
        "source_file": Path(source).name,
        "rainfall_mm": rainfall.tolist(),
    }


@app.post(f"{api}/analyses", response_model=JobCreated, status_code=202)
def create_analysis(payload: AnalysisRequest, request: Request) -> JobCreated:
    if len(payload.rainfall_mm) > settings.max_rainfall_days:
        raise HTTPException(status_code=413, detail="Série de chuva maior que o limite permitido.")
    enforce_job_rate(request)
    try:
        job_id, status = submit(payload.model_dump())
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return JobCreated(job_id=job_id, status=status, status_url=f"{api}/jobs/{job_id}", expires_in_seconds=settings.result_ttl_seconds)


@app.get(f"{api}/jobs/{{job_id}}", response_model=JobStatus)
def job_status(job_id: str) -> JobStatus:
    record = load_record(job_id)
    if record:
        return JobStatus(**record)
    try:
        from rq.job import Job

        from .queueing import redis_connection

        job = Job.fetch(job_id, connection=redis_connection())
        return JobStatus(
            job_id=job_id,
            status=job.get_status(refresh=True),
            progress=int(job.meta.get("progress", 0)),
            message=str(job.meta.get("message", "Aguardando processamento")),
            created_at=job.created_at.isoformat() if job.created_at else None,
            started_at=job.started_at.isoformat() if job.started_at else None,
            finished_at=job.ended_at.isoformat() if job.ended_at else None,
        )
    except Exception as exc:
        raise HTTPException(status_code=404, detail="Tarefa não encontrada ou expirada.") from exc


@app.delete(f"{api}/jobs/{{job_id}}", status_code=202)
def cancel_job(job_id: str) -> dict:
    return {"job_id": job_id, "cancelled": cancel(job_id)}


@app.get(f"{api}/jobs/{{job_id}}/export/{{fmt}}")
def export_result(job_id: str, fmt: str, report_type: str = Query(default="summary"), lang: str = Query(default="pt"), volume: float | None = Query(default=None)) -> Response:
    record = load_record(job_id)
    if not record or record.get("status") != "finished" or not record.get("result"):
        raise HTTPException(status_code=409, detail="O resultado ainda não está disponível.")
    try:
        content, media_type, filename = export_bytes(record["result"], fmt.lower(), report_type=report_type, lang=lang, volume=volume)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return Response(content, media_type=media_type, headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post(f"{api}/projects/export")
def export_project(payload: ExportProjectRequest) -> Response:
    document = {
        "schema": {"name": "netuno-project", "version": 2},
        "version": __version__,
        "metadata": payload.metadata,
        "rainfall": {"file_name": "chuva-incorporada.csv", "start_date": payload.config.get("start_date", "01/01/1980"), "total_days": len(payload.rainfall_mm), "precipitation_mm": payload.rainfall_mm},
        "inputs": {},
        "web_config": payload.config,
        "analysis": payload.analysis,
    }
    from netuno import get_project_filename
    project_name = payload.metadata.get("name") or payload.config.get("project_name") or "Projeto Netuno Web"
    project_ref = payload.metadata.get("project_id") or payload.config.get("project_id") or project_name
    filename = get_project_filename(str(project_name), str(project_ref), "netuno")
    return Response(
        json.dumps(document, ensure_ascii=False, indent=2),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get(f"{api}/tariffs/ufs")
def tariff_ufs() -> dict:
    return {"items": [{"code": code, "name": name} for code, name in get_available_ufs()]}


@app.get(f"{api}/tariffs/cities")
def tariff_cities(uf: str = Query(min_length=2, max_length=2)) -> dict:
    return {"items": get_cities_by_uf(uf)}


@app.get(f"{api}/tariffs/search")
def tariff_search(q: str = Query(min_length=2, max_length=120)) -> dict:
    return {"items": search_cities(q, limit=30)}


@app.get(f"{api}/tariffs/{{uf}}/{{city}}")
def tariff_city(uf: str, city: str) -> dict:
    data = get_city_data(uf, city)
    if not data:
        raise HTTPException(status_code=404, detail="Município não encontrado.")
    return data


def require_admin(x_netuno_admin_token: Annotated[str | None, Header()] = None) -> None:
    if not settings.admin_token or x_netuno_admin_token != settings.admin_token:
        raise HTTPException(status_code=403, detail="Acesso administrativo negado.")


@app.post(f"{api}/admin/tariffs/update", response_model=JobCreated, status_code=202, dependencies=[Depends(require_admin)])
def update_tariffs(payload: TariffUpdateRequest) -> JobCreated:
    if not settings.admin_updates_enabled:
        raise HTTPException(status_code=503, detail="Atualizações administrativas estão desabilitadas neste ambiente.")
    job_id, status = submit_tariff_update(payload.model_dump())
    return JobCreated(job_id=job_id, status=status, status_url=f"{api}/jobs/{job_id}", expires_in_seconds=settings.result_ttl_seconds)


# ── SERVIÇO DO FRONTEND ESTÁTICO (SPA REACT/VITE) ──
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, RedirectResponse

FRONTEND_DIST = Path(__file__).resolve().parent.parent / "frontend" / "dist"

if FRONTEND_DIST.is_dir():
    assets_dir = FRONTEND_DIST / "assets"
    if assets_dir.is_dir():
        app.mount("/netuno/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/favicon.ico")
    def favicon():
        return Response(status_code=204)

    @app.get("/")
    def root_redirect():
        return RedirectResponse(url="/netuno/")

    @app.get("/netuno")
    @app.get("/netuno/")
    @app.get("/netuno/{full_path:path}")
    def serve_netuno_frontend(full_path: str = ""):
        # Se for um arquivo estático existente na raiz do dist
        target_file = FRONTEND_DIST / full_path
        if full_path and target_file.is_file():
            return FileResponse(target_file)
        # Fallback SPA para index.html
        return FileResponse(FRONTEND_DIST / "index.html")
