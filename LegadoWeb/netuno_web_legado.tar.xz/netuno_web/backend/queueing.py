from __future__ import annotations

from uuid import uuid4

from .jobs import run_analysis_job, run_tariff_update_job
from .settings import settings


def redis_connection():
    from redis import Redis

    return Redis.from_url(settings.redis_url)


def submit(payload: dict) -> tuple[str, str]:
    try:
        from rq import Queue

        connection = redis_connection()
        connection.ping()
        queue = Queue("netuno", connection=connection, default_timeout=settings.job_timeout_seconds)
        if queue.count >= settings.queue_max_jobs:
            raise RuntimeError("A fila pública está cheia. Tente novamente em alguns minutos.")
        job = queue.enqueue(
            run_analysis_job,
            payload,
            job_timeout=settings.job_timeout_seconds,
            result_ttl=settings.result_ttl_seconds,
            failure_ttl=settings.result_ttl_seconds,
        )
        return job.id, "queued"
    except RuntimeError:
        raise
    except Exception:
        if not settings.allow_inline:
            raise RuntimeError("O serviço de processamento está temporariamente indisponível.")
        job_id = uuid4().hex
        run_analysis_job(payload, job_id=job_id)
        return job_id, "finished"


def cancel(job_id: str) -> bool:
    try:
        from rq.job import Job

        job = Job.fetch(job_id, connection=redis_connection())
        job.cancel()
        return True
    except Exception:
        return False


def submit_tariff_update(payload: dict) -> tuple[str, str]:
    try:
        from rq import Queue

        connection = redis_connection()
        connection.ping()
        queue = Queue("netuno", connection=connection, default_timeout=settings.batch_timeout_seconds)
        job = queue.enqueue(run_tariff_update_job, payload, job_timeout=settings.batch_timeout_seconds, result_ttl=settings.result_ttl_seconds, failure_ttl=settings.result_ttl_seconds)
        return job.id, "queued"
    except Exception:
        if not settings.allow_inline:
            raise RuntimeError("O serviço administrativo está temporariamente indisponível.")
        job_id = uuid4().hex
        run_tariff_update_job(payload, job_id=job_id)
        return job_id, "finished"
