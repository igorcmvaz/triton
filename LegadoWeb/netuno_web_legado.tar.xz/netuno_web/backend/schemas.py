from __future__ import annotations

import math
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


AnalysisKind = Literal["technical", "economic", "environmental", "topsis", "all"]


class AnalysisRequest(BaseModel):
    config: dict[str, Any] = Field(default_factory=dict)
    rainfall_mm: list[float] = Field(min_length=1)
    analysis: AnalysisKind = "all"
    weights: tuple[float, float, float] = (0.33, 0.33, 0.34)
    environmental: dict[str, Any] = Field(default_factory=dict)
    weight_sensitivity: int = Field(default=0, ge=0, le=5000)
    seed: int = 42
    source: str = Field(default="Netuno Web", max_length=200)

    @field_validator("rainfall_mm")
    @classmethod
    def validate_rainfall(cls, values: list[float]) -> list[float]:
        if any(not math.isfinite(value) or value < 0 for value in values):
            raise ValueError("A precipitação deve conter apenas valores finitos e não negativos.")
        return values

    @field_validator("weights")
    @classmethod
    def validate_weights(cls, values: tuple[float, float, float]) -> tuple[float, float, float]:
        if any(not math.isfinite(value) or value < 0 for value in values) or not math.isfinite(sum(values)) or sum(values) <= 0:
            raise ValueError("Os pesos devem ser não negativos e possuir soma positiva.")
        total = sum(values)
        return tuple(value / total for value in values)  # type: ignore[return-value]


class JobCreated(BaseModel):
    job_id: str
    status: str
    status_url: str
    expires_in_seconds: int


class JobStatus(BaseModel):
    job_id: str
    status: str
    progress: int = Field(ge=0, le=100)
    message: str = ""
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    result: dict[str, Any] | None = None
    error: str | None = None


class ProjectDocument(BaseModel):
    document: dict[str, Any]


class ExportProjectRequest(BaseModel):
    config: dict[str, Any]
    rainfall_mm: list[float]
    metadata: dict[str, Any] = Field(default_factory=dict)
    analysis: dict[str, Any] = Field(default_factory=dict)


class TariffUpdateRequest(BaseModel):
    mode: Literal["all", "aneel", "sanitation"] = "all"
    target_uf: str | None = Field(default=None, min_length=2, max_length=2)
    target_city: str | None = Field(default=None, max_length=120)
    force_download: bool = False
    dry_run: bool = True
