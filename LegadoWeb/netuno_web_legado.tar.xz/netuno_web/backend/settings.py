from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[2]
WEB_DIR = Path(__file__).resolve().parents[1]


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "sim"}


@dataclass(frozen=True)
class Settings:
    api_prefix: str = os.getenv("NETUNO_API_PREFIX", "/netuno/api/v1").rstrip("/")
    redis_url: str = os.getenv("NETUNO_REDIS_URL", "redis://redis:6379/0")
    result_dir: Path = Path(os.getenv("NETUNO_RESULT_DIR", str(WEB_DIR / ".runtime"))).resolve()
    result_ttl_seconds: int = int(os.getenv("NETUNO_RESULT_TTL_SECONDS", "86400"))
    job_timeout_seconds: int = int(os.getenv("NETUNO_JOB_TIMEOUT_SECONDS", "600"))
    batch_timeout_seconds: int = int(os.getenv("NETUNO_BATCH_TIMEOUT_SECONDS", "1800"))
    max_upload_mb: int = int(os.getenv("NETUNO_MAX_UPLOAD_MB", "20"))
    max_rainfall_days: int = int(os.getenv("NETUNO_MAX_RAINFALL_DAYS", "40000"))
    jobs_per_hour: int = int(os.getenv("NETUNO_JOBS_PER_HOUR", "10"))
    queue_max_jobs: int = int(os.getenv("NETUNO_QUEUE_MAX_JOBS", "50"))
    admin_token: str = os.getenv("NETUNO_ADMIN_TOKEN", "")
    admin_updates_enabled: bool = _bool("NETUNO_ADMIN_UPDATES_ENABLED", False)
    allow_inline: bool = _bool("NETUNO_ALLOW_INLINE", True)
    cors_origins: tuple[str, ...] = tuple(
        item.strip() for item in os.getenv("NETUNO_CORS_ORIGINS", "").split(",") if item.strip()
    )

    def prepare(self) -> None:
        self.result_dir.mkdir(parents=True, exist_ok=True)


settings = Settings()

