FROM python:3.13-slim

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PYTHONPATH=/app

WORKDIR /app
COPY netuno_web/requirements.txt /tmp/requirements.txt
RUN pip install --no-cache-dir -r /tmp/requirements.txt

COPY netuno /app/netuno
COPY data /app/data
COPY netuno_web /app/netuno_web

RUN addgroup --system netuno && adduser --system --ingroup netuno netuno \
    && mkdir -p /var/lib/netuno/results && chown -R netuno:netuno /var/lib/netuno
USER netuno

EXPOSE 8000
CMD ["uvicorn", "netuno_web.backend.main:app", "--host", "0.0.0.0", "--port", "8000", "--proxy-headers", "--forwarded-allow-ips", "*"]
