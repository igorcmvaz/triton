FROM node:22-alpine AS build
WORKDIR /app
COPY netuno_web/frontend/package.json netuno_web/frontend/pnpm-lock.yaml ./
RUN corepack enable && pnpm install --frozen-lockfile
COPY netuno_web/frontend ./
RUN pnpm run build

FROM nginx:1.27-alpine
COPY netuno_web/docker/nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/dist /usr/share/nginx/html/netuno
EXPOSE 80
