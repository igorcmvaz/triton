import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import {
  BarChart3,
  BookOpen,
  Building2,
  Calculator,
  CheckCircle2,
  CloudRain,
  Download,
  Droplets,
  Eye,
  FileDown,
  FileSpreadsheet,
  FileText,
  FileUp,
  FlaskConical,
  Globe2,
  Leaf,
  Menu,
  Play,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TableProperties,
  WalletCards,
  X,
  Layers,
  TrendingUp,
  Award,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  ComposedChart,
  Area,
} from "recharts";
import {
  API_BASE,
  createAnalysis,
  getDefaults,
  getExportUrl,
  getJob,
  importProject,
  loadClimateCatalog,
  loadClimateCities,
  loadClimateSeries,
  loadTariff,
  loadTariffCities,
  loadTariffUfs,
  parseRainfall,
} from "./api";
import type {
  AnalysisResult,
  AnalysisRow,
  ClimateCatalog,
  Config,
  TariffCityData,
} from "./types";
import { localizeDom, type Locale, t } from "./i18n";
const HydraulicDiagram = lazy(() => import("./HydraulicDiagram").then((module) => ({ default: module.HydraulicDiagram })));
const BuildingCalculator = lazy(() => import("./BuildingCalculator").then((module) => ({ default: module.BuildingCalculator })));
const ScenarioComparator = lazy(() => import("./ScenarioComparator").then((module) => ({ default: module.ScenarioComparator })));
const DocumentationViewer = lazy(() => import("./DocumentationViewer").then((module) => ({ default: module.DocumentationViewer })));

const fallback: Config = {
  project_name: "Novo Projeto Netuno",
  start_date: "01/01/1980",
  area: 100,
  runoff_coeff: 0.85,
  discard: 1,
  discard_mode: 1,
  discard_days_interval: 7,
  demand_value: 120,
  residents_count: 4,
  rainwater_share: 0.4,
  potable_indoor_share: 0.65,
  non_potable_indoor_share: 0.35,
  irrigation_liters_per_day: 0,
  lower_tank_mode: 1,
  lower_tank_max: 10000,
  lower_tank_step: 500,
  lower_tank_fixed: 2000,
  delta_ideal: 5,
  upper_tank_used: true,
  upper_tank_vol: 500,
  pumping_threshold: 50,
  water_quality_target_class: "classe_1",
  water_quality_disinfection: "cloro",
  chlorine_treatment_enabled: true,
  chlorine_dose_mg_l: 2,
  analysis_period_years: 20,
  tma: 0.8,
  inflation: 0.3,
  sewage_rate: 100,
  elec_tariff: 0.95,
  cost_lower_tank: 2500,
  cost_upper_tank: 380,
  cost_labor: 1500,
  cost_piping: 950,
  cost_accessories: 500,
  pump_count: 1,
  pump_power_kw: 0.368,
  pump_efficiency: 55,
  pump_unit_cost: 650,
  lower_tank_material: "PEAD",
  upper_tank_material: "PEAD",
};

const steps = [
  ["Projeto e chuva", CloudRain],
  ["Edificação", Building2],
  ["Qualidade da água", FlaskConical],
  ["Reservatórios", Droplets],
  ["Resultados técnicos", BarChart3],
  ["Economia", WalletCards],
  ["Ambiental e ESG", Leaf],
  ["Otimização & Cenários", SlidersHorizontal],
  ["Relatórios", FileDown],
  ["Documentação", BookOpen],
  ["Tarifas", TableProperties],
] as const;

const QUICK_CAPITALS = [
  "Florianópolis",
  "São Paulo",
  "Rio de Janeiro",
  "Brasília",
  "Belo Horizonte",
  "Curitiba",
  "Porto Alegre",
  "Salvador",
  "Recife",
  "Fortaleza",
  "Manaus",
  "Belém",
  "Goiânia",
  "Cuiabá",
  "Campo Grande",
  "Vitória",
  "Natal",
  "João Pessoa",
  "Maceió",
  "Aracaju",
  "Teresina",
  "São Luís",
  "Palmas",
  "Porto Velho",
  "Boa Vista",
  "Rio Branco",
  "Macapá",
];

function fmt(value: unknown, digits = 2) {
  const number = Number(value);
  return Number.isFinite(number)
    ? number.toLocaleString("pt-BR", {
        maximumFractionDigits: digits,
        minimumFractionDigits: digits,
      })
    : "—";
}

function money(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number)
    ? number.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
    : "—";
}

const Field = ({
  label,
  value,
  onChange,
  type = "number",
  suffix,
  min,
  max,
  step,
  placeholder,
}: {
  label: string;
  value: unknown;
  onChange: (value: string | number | boolean) => void;
  type?: string;
  suffix?: string;
  min?: number;
  max?: number;
  step?: number;
  placeholder?: string;
}) => (
  <label className="field">
    <span>{label}</span>
    <div className="input-wrap">
      <input
        type={type}
        placeholder={placeholder}
        value={String(value ?? "")}
        min={min}
        max={max}
        step={step ?? (type === "number" ? "any" : undefined)}
        onChange={(event) =>
          onChange(
            type === "number" ? Number(event.target.value) : event.target.value
          )
        }
      />
      {suffix && <em>{suffix}</em>}
    </div>
  </label>
);

const Toggle = ({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) => (
  <label className="toggle-row">
    <span>{label}</span>
    <input
      type="checkbox"
      checked={checked}
      onChange={(event) => onChange(event.target.checked)}
    />
  </label>
);

const Metric = ({
  label,
  value,
  detail,
}: {
  label: string;
  value: string;
  detail?: string;
}) => (
  <article className="metric">
    <span>{label}</span>
    <strong>{value}</strong>
    {detail && <small>{detail}</small>}
  </article>
);

const DesktopHint = ({
  title,
  description,
}: {
  title: string;
  description: string;
}) => (
  <aside className="desktop-hint">
    <Sparkles />
    <div className="hint-content">
      <strong>{title}</strong>
      <p>{description}</p>
      <a className="hint-link" href="/downloads/Netuno-Setup.exe">
        <Download size={13} /> Mais detalhes e recursos avançados na versão Desktop
      </a>
    </div>
  </aside>
);

function EmptyState() {
  return (
    <div className="empty">
      <Settings2 />
      <strong>Resultado ainda não disponível</strong>
      <span>Conclua as etapas de entrada e execute uma análise para visualizar.</span>
    </div>
  );
}

function App() {
  const appRef = useRef<HTMLDivElement>(null);
  const [locale, setLocale] = useState<Locale>(
    () => (localStorage.getItem("netuno-web-language") as Locale) || "pt"
  );
  const [active, setActive] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [config, setConfig] = useState<Config>(() => {
    try {
      return {
        ...fallback,
        ...JSON.parse(localStorage.getItem("netuno-web-config") || "{}"),
      };
    } catch {
      return fallback;
    }
  });

  const [rainfall, setRainfall] = useState<number[]>([]);
  const [rainName, setRainName] = useState("Nenhuma série carregada");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [jobId, setJobId] = useState("");
  const [status, setStatus] = useState(
    "Configure o projeto e carregue uma série de chuva."
  );
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [weights, setWeights] = useState([33, 33, 34]);
  const [sensitivity, setSensitivity] = useState(0);

  // Subtab for Step 8 (TOPSIS vs Scenarios)
  const [step8Tab, setStep8Tab] = useState<"topsis" | "scenarios">("topsis");

  // Climate Database State
  const [climateCatalog, setClimateCatalog] = useState<ClimateCatalog | null>(null);
  const [climateCitiesList, setClimateCitiesList] = useState<string[]>([]);
  const [selectedClimateCity, setSelectedClimateCity] = useState("Florianópolis");
  const [selectedClimateModel, setSelectedClimateModel] = useState("INM-CM4");
  const [selectedClimateScenario, setSelectedClimateScenario] = useState("HIST");
  const [climateSearch, setClimateSearch] = useState("");
  const [rainInputMode, setRainInputMode] = useState<"climate" | "file" | "project">("climate");

  // Report Preview State
  const [previewModel, setPreviewModel] = useState<"executive" | "environmental" | "research">("executive");
  const [previewHtml, setPreviewHtml] = useState<string | null>(null);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [selectedReportVolume, setSelectedReportVolume] = useState<number | null>(null);

  useEffect(() => {
    getDefaults()
      .then((defaults) => setConfig((current) => ({ ...defaults, ...current })))
      .catch(() => undefined);

    loadClimateCatalog()
      .then(async (cat) => {
        setClimateCatalog(cat);
        const cities = cat.cities || [];
        if (cities.length) {
          setClimateCitiesList(cities);
          const initialCity = cities.includes("Florianópolis") ? "Florianópolis" : cities[0];
          setSelectedClimateCity(initialCity);
          try {
            const series = await loadClimateSeries(initialCity, "INM-CM4", "HIST");
            setRainfall(series.rainfall_mm);
            setRainName(`${series.city} (INM-CM4 - Histórico)`);
            update("start_date", series.start_date);
            setStatus(
              `Base Climática: ${series.city} carregada com ${series.selected_days.toLocaleString("pt-BR")} dias (${series.start_date} a ${series.end_date}).`
            );
          } catch {
            // Carregamento silencioso
          }
        }
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    localStorage.setItem("netuno-web-config", JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem("netuno-web-language", locale);
    return localizeDom(appRef.current, locale);
  }, [locale]);

  const update = (key: string, value: string | number | boolean) =>
    setConfig((current) => ({ ...current, [key]: value }));

  const technical = result?.technical?.alternatives || [];
  const economic = result?.economic?.alternatives || [];
  const environmental = result?.environmental?.alternatives || [];
  const optimum = Number(
    result?.topsis?.best_volume_l ||
      result?.technical?.summary?.optimal_volume_l ||
      technical.at(-1)?.lower_tank_volume_l ||
      0
  );
  const optimumRow =
    technical.find((row) => row.lower_tank_volume_l === optimum) ||
    technical.at(-1);

  const filteredClimateCities = useMemo(() => {
    if (!climateSearch.trim()) return climateCitiesList;
    const q = climateSearch.toLowerCase();
    return climateCitiesList.filter((c) => c.toLowerCase().includes(q));
  }, [climateCitiesList, climateSearch]);

  useEffect(() => {
    if (filteredClimateCities.length > 0 && !filteredClimateCities.includes(selectedClimateCity)) {
      setSelectedClimateCity(filteredClimateCities[0]);
    }
  }, [filteredClimateCities, selectedClimateCity]);

  const poll = async (id: string) => {
    for (;;) {
      const job = await getJob(id);
      setProgress(job.progress || 0);
      setStatus(job.message || job.status);
      if (job.status === "finished" && job.result) {
        setResult(job.result);
        setRunning(false);
        setActive(4);
        return;
      }
      if (["failed", "stopped", "canceled", "cancelled"].includes(job.status)) {
        setRunning(false);
        throw new Error(job.error || "A análise não foi concluída.");
      }
      await new Promise((resolve) => setTimeout(resolve, 800));
    }
  };

  const fetchClimateSeries = async (
    targetCity = selectedClimateCity,
    targetModel = selectedClimateModel,
    targetScenario = selectedClimateScenario
  ) => {
    const city = targetCity || "Florianópolis";
    setStatus("Carregando série da base climática nacional (CMIP6)...");
    try {
      const data = await loadClimateSeries(city, targetModel, targetScenario);
      setRainfall(data.rainfall_mm);
      setRainName(`${data.city} (${data.model} - ${data.scenario})`);
      update("start_date", data.start_date);
      setStatus(
        `Série de ${data.city} carregada: ${data.selected_days.toLocaleString("pt-BR")} dias (${data.start_date} a ${data.end_date}).`
      );
      return data.rainfall_mm;
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Falha ao carregar clima.";
      setStatus(msg);
      return [];
    }
  };

  const run = async () => {
    let rain = rainfall;
    if (!rain.length) {
      setStatus("Carregando série climática padrão para simulação...");
      rain = await fetchClimateSeries(selectedClimateCity || "Florianópolis", selectedClimateModel, selectedClimateScenario);
      if (!rain.length) {
        setStatus("Não foi possível carregar a série de chuva. Selecione um município ou envie um arquivo.");
        setActive(0);
        return;
      }
    }
    setRunning(true);
    setProgress(5);
    setStatus("Enviando tarefa para processamento…");
    try {
      const created = await createAnalysis(
        config,
        rain,
        weights,
        sensitivity
      );
      setJobId(created.job_id);
      await poll(created.job_id);
    } catch (error) {
      setRunning(false);
      setStatus(error instanceof Error ? error.message : "Falha na análise.");
    }
  };

  const onRain = async (file?: File) => {
    if (!file) return;
    try {
      const parsed = await parseRainfall(file);
      setRainfall(parsed.rainfall_mm);
      setRainName(parsed.file_name);
      setStatus(
        `${parsed.rainfall_mm.length.toLocaleString("pt-BR")} dias de chuva carregados.`
      );
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Falha ao ler a chuva.");
    }
  };

  const onProject = async (file?: File) => {
    if (!file) return;
    try {
      const loaded = await importProject(file);
      setConfig((current) => ({ ...current, ...loaded.config }));
      if (loaded.rainfall_mm && loaded.rainfall_mm.length) {
        setRainfall(loaded.rainfall_mm);
        setRainName(file.name);
      }
      setStatus(`Projeto ${file.name} importado com sucesso.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Falha ao importar o projeto.");
    }
  };

  const saveProject = () => {
    const projectDoc = {
      schema: { name: "netuno-project", version: 2 },
      version: "5.0.6",
      metadata: {
        name: String(config.project_name || "Projeto Netuno Web"),
        saved_at: new Date().toISOString(),
      },
      rainfall: {
        file_name: rainName,
        start_date: config.start_date,
        total_days: rainfall.length,
        precipitation_mm: rainfall,
      },
      inputs: {},
      web_config: config,
      analysis: result || {},
    };
    const link = window.document.createElement("a");
    link.href = URL.createObjectURL(
      new Blob([JSON.stringify(projectDoc, null, 2)], {
        type: "application/json",
      })
    );
    link.download = "projeto-netuno.netuno";
    link.click();
  };

  const loadReportPreview = async (model: "executive" | "environmental" | "research", vol?: number) => {
    if (!jobId) return;
    setLoadingPreview(true);
    setPreviewModel(model);
    try {
      const targetVol = vol !== undefined ? vol : (selectedReportVolume ?? undefined);
      const url = getExportUrl(jobId, "html", model, locale, targetVol);
      const res = await fetch(url);
      const html = await res.text();
      setPreviewHtml(html);
    } catch {
      setPreviewHtml("<p>Erro ao carregar pré-visualização do relatório.</p>");
    } finally {
      setLoadingPreview(false);
    }
  };

  // Target non-potable daily demand calculation
  const totalDailyNonPotableLiters = useMemo(() => {
    const residents = Number(config.residents_count || 4);
    const demand = Number(config.demand_value || 120);
    const share = Number(config.rainwater_share || 0.4);
    const irrigation = Number(config.irrigation_liters_per_day || 0);
    return residents * demand * share + irrigation;
  }, [config.residents_count, config.demand_value, config.rainwater_share, config.irrigation_liters_per_day]);

  // Monthly breakdown data for Chart in Step 5
  const monthlyBalanceData = useMemo(() => {
    if (result?.single_sim?.monthly_results?.length) {
      return result.single_sim.monthly_results.map((m) => ({
        name: m.name,
        "Chuva (mm)": m.precip_mm || 0,
        "Água Pluvial Usada (m³)": (m.pluvial_consumed_m3 || 0),
        "Rede Pública (m³)": (m.potable_consumed_m3 || 0),
        "Extravasamento (m³)": (m.spill_m3 || 0),
      }));
    }
    return [];
  }, [result]);

  // Computed 9 ETCCDI Climate Indices from loaded rainfall series
  const climateStats = useMemo(() => {
    if (!rainfall.length) return null;
    const totalDays = rainfall.length;
    const years = Math.max(1, totalDays / 365.25);
    const sumTotal = rainfall.reduce((a, b) => a + b, 0);
    const prcptot = sumTotal / years;
    const wetDays = rainfall.filter((v) => v >= 1);
    const sdii = wetDays.length ? wetDays.reduce((a, b) => a + b, 0) / wetDays.length : 0;
    const r20mm = rainfall.filter((v) => v >= 20).length / years;
    const rx1day = Math.max(0, ...rainfall);

    let rx5day = 0;
    for (let i = 0; i <= rainfall.length - 5; i++) {
      const sum5 = rainfall[i] + rainfall[i + 1] + rainfall[i + 2] + rainfall[i + 3] + rainfall[i + 4];
      if (sum5 > rx5day) rx5day = sum5;
    }

    let r95p = 0;
    if (wetDays.length > 0) {
      const sortedWet = [...wetDays].sort((a, b) => a - b);
      const p95Index = Math.floor(0.95 * sortedWet.length);
      const p95Value = sortedWet[p95Index] || 0;
      const veryWetSum = wetDays.filter((v) => v > p95Value).reduce((a, b) => a + b, 0);
      r95p = veryWetSum / years;
    }

    let maxCdd = 0;
    let maxCwd = 0;
    let currentCdd = 0;
    let currentCwd = 0;
    for (const v of rainfall) {
      if (v < 1) {
        currentCdd++;
        if (currentCdd > maxCdd) maxCdd = currentCdd;
        currentCwd = 0;
      } else {
        currentCwd++;
        if (currentCwd > maxCwd) maxCwd = currentCwd;
        currentCdd = 0;
      }
    }

    return {
      prcptot: Math.round(prcptot),
      r95p: Math.round(r95p),
      rx1day: Math.round(rx1day * 10) / 10,
      rx5day: Math.round(rx5day * 10) / 10,
      sdii: Math.round(sdii * 10) / 10,
      r20mm: Math.round(r20mm * 10) / 10,
      cdd: maxCdd,
      cwd: maxCwd,
      years: Math.round(years * 10) / 10,
      totalDays,
    };
  }, [rainfall]);

  // Sections of the 11-step web application
  const sections = useMemo(
    () => [
      // ETAPA 1: PROJETO E CHUVA
      <section className="panel" key="project">
        <header>
          <span className="eyebrow">Etapa 1</span>
          <h2>Projeto e série de precipitação</h2>
          <p>
            Selecione uma série da base climática nacional (652 cidades), faça
            upload de um arquivo diário ou importe um projeto .netuno.
          </p>
        </header>

        <div className="subtabs-bar">
          <button
            className={`subtab-btn ${rainInputMode === "climate" ? "active" : ""}`}
            onClick={() => setRainInputMode("climate")}
          >
            <Globe2 size={16} /> Base Nacional (652 cidades)
          </button>
          <button
            className={`subtab-btn ${rainInputMode === "file" ? "active" : ""}`}
            onClick={() => setRainInputMode("file")}
          >
            <CloudRain size={16} /> Carregar Chuva CSV/TXT
          </button>
          <button
            className={`subtab-btn ${rainInputMode === "project" ? "active" : ""}`}
            onClick={() => setRainInputMode("project")}
          >
            <FileUp size={16} /> Importar Projeto .netuno
          </button>
        </div>

        {rainInputMode === "climate" && (
          <div className="section-card">
            <div className="section-heading">
              <div>
                <h3>Base Climatológica Nacional CMIP6 (UFSC / CLIMBra)</h3>
                <p>
                  86.716 séries temporais diárias indexadas para 652 municípios
                  brasileiros em 19 modelos climáticos.
                </p>
              </div>
            </div>
            <div className="quick-chips-wrap">
              <span>Capitais e Centros Regionais (Acesso Rápido):</span>
              <div className="quick-chips">
                {QUICK_CAPITALS.map((cap) => (
                  <button
                    key={cap}
                    type="button"
                    className={`chip-btn ${selectedClimateCity === cap ? "active" : ""}`}
                    onClick={async () => {
                      setSelectedClimateCity(cap);
                      try {
                        const series = await loadClimateSeries(cap, selectedClimateModel, selectedClimateScenario);
                        setRainfall(series.rainfall_mm);
                        setRainName(`${series.city} (${series.model} - ${series.scenario})`);
                        update("start_date", series.start_date);
                        setStatus(`Base Climática: ${series.city} carregada com ${series.selected_days.toLocaleString("pt-BR")} dias.`);
                      } catch {
                        // ignore
                      }
                    }}
                  >
                    {cap}
                  </button>
                ))}
              </div>
            </div>

            <div className="form-grid">
              <label className="field">
                <span>Buscar dentre os 652 Municípios</span>
                <input
                  type="text"
                  placeholder="Digite para filtrar (ex: Joinville, Campinas, Niterói...)"
                  value={climateSearch}
                  onChange={(e) => setClimateSearch(e.target.value)}
                />
              </label>

              <label className="field">
                <span>Município Selecionado ({filteredClimateCities.length} encontrados)</span>
                <select
                  value={selectedClimateCity}
                  onChange={(e) => setSelectedClimateCity(e.target.value)}
                >
                  {filteredClimateCities.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </label>

              <label className="field">
                <span>Modelo Climático GCM</span>
                <select
                  value={selectedClimateModel}
                  onChange={(e) => setSelectedClimateModel(e.target.value)}
                >
                  {climateCatalog?.models?.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  )) || <option value="INM-CM4">INM-CM4</option>}
                </select>
              </label>

              <label className="field">
                <span>Cenário de Emissões</span>
                <select
                  value={selectedClimateScenario}
                  onChange={(e) => setSelectedClimateScenario(e.target.value)}
                >
                  {climateCatalog?.scenarios?.map((s) => (
                    <option key={s.key} value={s.key}>
                      {s.label}
                    </option>
                  )) || (
                    <>
                      <option value="HIST">Série Histórica (1980–2013)</option>
                      <option value="SSP245">SSP2-4.5 (Intermediário)</option>
                      <option value="SSP585">SSP5-8.5 (Extremo)</option>
                    </>
                  )}
                </select>
              </label>
            </div>
            <button
              className="primary wide"
              onClick={() => fetchClimateSeries(selectedClimateCity, selectedClimateModel, selectedClimateScenario)}
              style={{ marginTop: 14 }}
            >
              <CloudRain size={16} /> Carregar Série Climática Selecionada
            </button>
          </div>
        )}

        {rainInputMode === "file" && (
          <div className="upload-grid">
            <label className="drop">
              <CloudRain />
              <strong>Carregar arquivo de chuva (CSV / TXT / DAT)</strong>
              <span>Um valor diário em mm por linha</span>
              <input
                type="file"
                accept=".csv,.txt,.dat"
                onChange={(e) => onRain(e.target.files?.[0])}
              />
            </label>
          </div>
        )}

        {rainInputMode === "project" && (
          <div className="upload-grid">
            <label className="drop">
              <FileUp />
              <strong>Importar projeto .netuno / JSON</strong>
              <span>Restaura todos os parâmetros, custos e série de chuva</span>
              <input
                type="file"
                accept=".netuno,.json,.csv"
                onChange={(e) => onProject(e.target.files?.[0])}
              />
            </label>
          </div>
        )}

        {/* 9 ÍNDICES PLUVIOMÉTRICOS ETCCDI DA SÉRIE ATUAL */}
        {climateStats && (
          <div className="section-card">
            <div className="section-heading">
              <div>
                <h3>9 Índices Climatológicos da Série (ETCCDI)</h3>
                <p>
                  Calculados para {climateStats.totalDays.toLocaleString("pt-BR")} dias de medição (~{climateStats.years} anos de registros diários).
                </p>
              </div>
              <span className="diagram-badge">
                <CloudRain size={14} /> Climatologia Ativa
              </span>
            </div>
            <div className="metric-grid-4">
              <Metric
                label="PRCPTOT (Chuva Anual)"
                value={`${climateStats.prcptot.toLocaleString("pt-BR")} mm/ano`}
                detail="Precipitação anual média"
              />
              <Metric
                label="R95p (Dias Extremos)"
                value={`${climateStats.r95p.toLocaleString("pt-BR")} mm/ano`}
                detail="Chuva acima do percentil 95"
              />
              <Metric
                label="Rx1day (Máx 24h)"
                value={`${fmt(climateStats.rx1day, 1)} mm`}
                detail="Maior evento em 1 dia"
              />
              <Metric
                label="Rx5day (Máx 5 dias)"
                value={`${fmt(climateStats.rx5day, 1)} mm`}
                detail="Maior acúmulo em 5 dias"
              />
              <Metric
                label="SDII (Intensidade Diária)"
                value={`${fmt(climateStats.sdii, 1)} mm/dia`}
                detail="Volume médio por dia chuvoso"
              />
              <Metric
                label="R20mm (Chuva Forte)"
                value={`${fmt(climateStats.r20mm, 1)} dias/ano`}
                detail="Frequência de chuvas ≥ 20mm"
              />
              <Metric
                label="CDD (Estiagem Máxima)"
                value={`${climateStats.cdd} dias`}
                detail="Dias secos consecutivos"
              />
              <Metric
                label="CWD (Período Chuvoso)"
                value={`${climateStats.cwd} dias`}
                detail="Dias úmidos consecutivos"
              />
            </div>
          </div>
        )}


        <div className="section-card">
          <div className="section-heading">
            <div>
              <h3>Identificação do Projeto</h3>
              <p>
                {rainName} · {rainfall.length.toLocaleString("pt-BR")} dias de chuva
              </p>
            </div>
            <button className="ghost" onClick={saveProject}>
              <Download size={17} /> Salvar projeto .netuno
            </button>
          </div>
          <div className="form-grid">
            <Field
              label="Nome do projeto"
              type="text"
              value={config.project_name}
              onChange={(v) => update("project_name", v)}
            />
            <Field
              label="Data inicial"
              type="text"
              value={config.start_date}
              onChange={(v) => update("start_date", v)}
            />
          </div>
        </div>

        <DesktopHint
          title="Séries Climáticas e Importação Rápida (Web)"
          description="A versão web acessa diretamente as séries diárias CMIP6 dos 652 municípios brasileiros e arquivos CSV/TXT. Na versão Desktop do Netuno, você conta com editor visual de dados hidrológicos diários, interpolação estatística de falhas, gerador estocástico de séries sintéticas e integração com as estações ANA / INMET."
        />
      </section>,

      // ETAPA 2: EDIFICAÇÃO E CONSUMO (COM CALCULADORA COMPLETA)
      <section className="panel" key="building">
        <header>
          <span className="eyebrow">Etapa 2</span>
          <h2>Edificação, ocupantes e demanda de água</h2>
          <p>
            Caracterize a captação de água pluvial e a demanda detalhada da
            edificação por tipologias e aparelhos sanitários.
          </p>
        </header>

        <div className="calc-banner">
          <div>
            <strong>Demanda Pluvial Diária Alvo Calculada:</strong>
            <span>
              Baseado na população, consumo per capita e fração não potável
            </span>
          </div>
          <div className="calc-val">{fmt(totalDailyNonPotableLiters, 1)} L/dia</div>
        </div>

        {/* CALCULADORA DE EDIFICAÇÃO & APARELHOS */}
        <Suspense fallback={<div className="section-card">Carregando calculadora da edificação…</div>}>
          <BuildingCalculator config={config} updateConfig={update} />
        </Suspense>

        <div className="section-card">
          <h3>Área de Captação & Descarte Inicial (First Flush)</h3>
          <div className="form-grid">
            <Field
              label="Área de captação (telhado)"
              value={config.area}
              suffix="m²"
              min={1}
              onChange={(v) => update("area", v)}
            />
            <Field
              label="Coeficiente de escoamento (C)"
              value={config.runoff_coeff}
              min={0}
              max={1}
              step={0.05}
              onChange={(v) => update("runoff_coeff", v)}
            />
            <Field
              label="Descarte inicial (First Flush)"
              value={config.discard}
              suffix="mm"
              min={0}
              step={0.5}
              onChange={(v) => update("discard", v)}
            />
          </div>
        </div>
      </section>,

      // ETAPA 3: QUALIDADE DA ÁGUA E TRATAMENTO
      <section className="panel" key="quality">
        <header>
          <span className="eyebrow">Etapa 3</span>
          <h2>Qualidade da água, tratamento e dosagem</h2>
          <p>
            Defina a classe de qualidade pretendida e a rota de desinfecção
            conforme ABNT NBR 15527:2019 e NBR 16783.
          </p>
        </header>

        <div className="section-card">
          <div className="form-grid">
            <label className="field">
              <span>Classe-alvo de Qualidade</span>
              <select
                value={String(config.water_quality_target_class)}
                onChange={(e) => update("water_quality_target_class", e.target.value)}
              >
                <option value="classe_1">Classe 1 — usos nobres / recarga / lavagem nobre</option>
                <option value="classe_2">Classe 2 — bacias sanitárias e lavagem de pisos/veículos</option>
                <option value="classe_3">Classe 3 — irrigação de áreas verdes e paisagismo</option>
                <option value="classe_4">Classe 4 — combate a incêndio e usos industriais</option>
              </select>
            </label>

            <label className="field">
              <span>Tecnologia de Desinfecção</span>
              <select
                value={String(config.water_quality_disinfection)}
                onChange={(e) => update("water_quality_disinfection", e.target.value)}
              >
                <option value="cloro">Cloração (Hipoclorito de Sódio)</option>
                <option value="uv">Radiação Ultravioleta (UV)</option>
                <option value="ozonio">Ozônio</option>
                <option value="nenhum">Nenhuma</option>
              </select>
            </label>

            <Field
              label="Dosagem de cloro ativo"
              value={config.chlorine_dose_mg_l}
              suffix="mg/L"
              min={0}
              step={0.5}
              onChange={(v) => update("chlorine_dose_mg_l", v)}
            />
          </div>

          <Toggle
            label="Considerar emissões de tratamento químico na Análise do Ciclo de Vida (ACV)"
            checked={Boolean(config.chlorine_treatment_enabled)}
            onChange={(v) => update("chlorine_treatment_enabled", v)}
          />
        </div>

        {/* MEMÓRIA DE CÁLCULO DA DOSAGEM DE CLORO */}
        {config.water_quality_disinfection === "cloro" && (
          <div className="section-card" style={{ borderLeft: "4px solid #087f6b", background: "var(--surface-sunken, #f0fdf4)" }}>
            <div className="section-heading">
              <div>
                <h3 style={{ color: "#065f46" }}>🧪 Memória de Cálculo da Dosagem de Cloro</h3>
                <p>
                  Dimensionamento estequiométrico e consumo de pastilhas de Hipoclorito de Cálcio Ca(ClO)₂ (65% cloro ativo)
                </p>
              </div>
            </div>

            <div className="metric-grid">
              <Metric
                label="Demanda Anual de Projeto"
                value={`${fmt((totalDailyNonPotableLiters * 365.25) / 1000, 1)} m³/ano`}
                detail={`${fmt(totalDailyNonPotableLiters, 0)} L/dia a tratar`}
              />
              <Metric
                label="Massa de Cl₂ Ativo Puro"
                value={`${fmt(((totalDailyNonPotableLiters * 365.25 / 1000) * Number(config.chlorine_dose_mg_l || 1.5)) / 1000, 3)} kg/ano`}
                detail={`${fmt((totalDailyNonPotableLiters * Number(config.chlorine_dose_mg_l || 1.5)) / 1000, 2)} g Cl₂/dia`}
              />
              <Metric
                label="Consumo de Pastilhas (65%)"
                value={`${fmt((((totalDailyNonPotableLiters * 365.25 / 1000) * Number(config.chlorine_dose_mg_l || 1.5)) / 1000) / 0.65, 2)} kg/ano`}
                detail={`${fmt(((((totalDailyNonPotableLiters * 365.25 / 1000) * Number(config.chlorine_dose_mg_l || 1.5)) / 1000) / 0.65) * 1000 / 12, 0)} g/mês`}
              />
              <Metric
                label="Custo Operacional de Cloro"
                value={money(((((totalDailyNonPotableLiters * 365.25 / 1000) * Number(config.chlorine_dose_mg_l || 1.5)) / 1000) / 0.65) * 38.0)}
                detail="R$ 38,00/kg de produto comercial"
              />
            </div>

            <div style={{ marginTop: 12, padding: "10px 14px", borderRadius: 6, background: "var(--surface, #ffffff)", border: "1px solid #d1fae5", fontSize: "12.5px" }}>
              <strong>📋 Parecer Normativo (ABNT NBR 15527 / NBR 16783):</strong>{" "}
              {Number(config.chlorine_dose_mg_l || 1.5) < 0.5 ? (
                <span style={{ color: "#ea580c" }}>⚠️ Dosagem abaixo de 0,5 mg/L. Risco de residual livre insuficiente nos pontos de consumo prediais.</span>
              ) : Number(config.chlorine_dose_mg_l || 1.5) <= 2.0 ? (
                <span style={{ color: "#065f46" }}>✅ Dosagem recomendada (0,5 a 2,0 mg/L). Garante residual livre protetivo sem odor excessivo.</span>
              ) : (
                <span style={{ color: "#0284c7" }}>ℹ️ Hipercloração (&gt; 2,0 mg/L). Indicado para desinfecção de choque ou reservatórios expostos.</span>
              )}
            </div>
          </div>
        )}

        {/* TABELA DE PARÂMETROS NORMATIVOS NBR 15527 */}
        <div className="section-card">
          <h3>Tabela de Conformidade Normativa (ABNT NBR 15527:2019)</h3>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Parâmetro</th>
                  <th>Classe 1</th>
                  <th>Classe 2</th>
                  <th>Classe 3</th>
                  <th>Classe 4</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>Turbidez (NTU)</b></td>
                  <td>≤ 2,0 NTU</td>
                  <td>≤ 5,0 NTU</td>
                  <td>≤ 10,0 NTU</td>
                  <td>Livre de sólidos grosseiros</td>
                </tr>
                <tr>
                  <td><b>Cor Aparente (uH)</b></td>
                  <td>≤ 5 uH</td>
                  <td>≤ 15 uH</td>
                  <td>≤ 75 uH</td>
                  <td>—</td>
                </tr>
                <tr>
                  <td><b>Escherichia coli (NMP/100mL)</b></td>
                  <td>Ausente em 100 mL</td>
                  <td>&lt; 200 NMP/100 mL</td>
                  <td>&lt; 1.000 NMP/100 mL</td>
                  <td>—</td>
                </tr>
                <tr>
                  <td><b>Cloro Residual Livre (mg/L)</b></td>
                  <td>0,5 a 2,0 mg/L</td>
                  <td>0,2 a 2,0 mg/L</td>
                  <td>0,2 a 2,0 mg/L</td>
                  <td>—</td>
                </tr>
                <tr>
                  <td><b>pH</b></td>
                  <td>6,0 a 9,0</td>
                  <td>6,0 a 9,0</td>
                  <td>6,0 a 9,0</td>
                  <td>6,0 a 9,0</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <aside className="note">
          <ShieldCheck />
          <div>
            <strong>Diretriz de Segurança Hídrica ABNT NBR 15527:2019</strong>
            <p>
              A água de chuva coletada deve passar por dispositivo de descarte dos primeiros milímetros (First Flush) e desinfecção antes do recalque para o reservatório superior, assegurando padrão bacteriológico adequado aos usos finais.
            </p>
          </div>
        </aside>
      </section>,

      // ETAPA 4: RESERVATÓRIOS, BOMBEAMENTO E DIAGRAMA 2D
      <section className="panel" key="tanks">
        <header>
          <span className="eyebrow">Etapa 4</span>
          <h2>Reservatórios, conjunto elevatório e diagrama 2D</h2>
          <p>
            Configure a faixa de varredura de volumes, motobomba de recalque e visualize o esquema funcional interativo.
          </p>
        </header>

        {/* DIAGRAMA HIDRÁULICO 2D INTERATIVO */}
        <Suspense fallback={<div className="section-card">Carregando diagrama hidráulico…</div>}>
        <HydraulicDiagram
          area={Number(config.area || 100)}
          runoffCoeff={Number(config.runoff_coeff || 0.85)}
          discardMm={Number(config.discard || 1)}
          lowerVolL={optimum || Number(config.lower_tank_fixed || 2000)}
          upperVolL={Number(config.upper_tank_vol || 500)}
          upperUsed={Boolean(config.upper_tank_used)}
          pumpingThresholdL={Number(config.pumping_threshold || 50)}
          pumpPowerKw={Number(config.pump_power_kw || 0.368)}
          pumpEfficiency={Number(config.pump_efficiency || 55)}
          potableSavingsPct={Number(optimumRow?.potable_savings_pct || 0)}
          dailyPluvialDemandL={totalDailyNonPotableLiters}
          annualRainwaterM3={Number(optimumRow?.annual_rainwater_m3 || 0)}
          annualOverflowM3={Number(optimumRow?.annual_overflow_m3 || 0)}
        />
        </Suspense>

        <div className="section-card">
          <h3>Reservatório Inferior (Cisterna)</h3>
          <div className="form-grid">
            <Field
              label="Volume máximo da varredura"
              value={config.lower_tank_max}
              suffix="L"
              min={500}
              onChange={(v) => update("lower_tank_max", v)}
            />
            <Field
              label="Passo de incremento"
              value={config.lower_tank_step}
              suffix="L"
              min={100}
              onChange={(v) => update("lower_tank_step", v)}
            />
            <Field
              label="Ganho marginal limite (Delta Ideal)"
              value={config.delta_ideal}
              suffix="%/m³"
              min={0}
              step={0.5}
              onChange={(v) => update("delta_ideal", v)}
            />
            <label className="field">
              <span>Material da Cisterna</span>
              <select
                value={String(config.lower_tank_material || "PEAD")}
                onChange={(e) => update("lower_tank_material", e.target.value)}
              >
                <option value="PEAD">Polietileno de Alta Densidade (PEAD)</option>
                <option value="Concreto">Concreto Armado</option>
                <option value="Fibra">Fibra de Vidro (PRFV)</option>
                <option value="Aço">Aço Inoxidável</option>
              </select>
            </label>
          </div>
        </div>

        <div className="section-card">
          <h3>Reservatório Superior & Elevatória</h3>
          <Toggle
            label="Usar reservatório superior (sistema com bombeamento)"
            checked={Boolean(config.upper_tank_used)}
            onChange={(v) => update("upper_tank_used", v)}
          />
          <div className="form-grid">
            <Field
              label="Volume superior"
              value={config.upper_tank_vol}
              suffix="L"
              min={0}
              onChange={(v) => update("upper_tank_vol", v)}
            />
            <Field
              label="Limiar de recalque"
              value={config.pumping_threshold}
              suffix="L"
              min={0}
              onChange={(v) => update("pumping_threshold", v)}
            />
            <Field
              label="Potência da motobomba"
              value={config.pump_power_kw}
              suffix="kW"
              min={0}
              step={0.1}
              onChange={(v) => update("pump_power_kw", v)}
            />
            <Field
              label="Rendimento global"
              value={config.pump_efficiency}
              suffix="%"
              min={1}
              max={100}
              onChange={(v) => update("pump_efficiency", v)}
            />
          </div>
        </div>

        <div className="section-card">
          <h3>Orçamento de Implantação (CAPEX)</h3>
          <div className="form-grid">
            <Field
              label="Custo Cisterna Inferior"
              value={config.cost_lower_tank}
              suffix="R$"
              min={0}
              onChange={(v) => update("cost_lower_tank", v)}
            />
            <Field
              label="Custo Reservatório Superior"
              value={config.cost_upper_tank}
              suffix="R$"
              min={0}
              onChange={(v) => update("cost_upper_tank", v)}
            />
            <Field
              label="Custo Tubulações & Conexões"
              value={config.cost_piping}
              suffix="R$"
              min={0}
              onChange={(v) => update("cost_piping", v)}
            />
            <Field
              label="Custo Filtros & Acessórios"
              value={config.cost_accessories}
              suffix="R$"
              min={0}
              onChange={(v) => update("cost_accessories", v)}
            />
            <Field
              label="Custo Mão de Obra & Instalação"
              value={config.cost_labor}
              suffix="R$"
              min={0}
              onChange={(v) => update("cost_labor", v)}
            />
          </div>
        </div>

        <button
          className="primary wide"
          onClick={run}
          disabled={running}
          style={{ height: 50, fontSize: 13 }}
        >
          <Play size={18} />
          {running ? "Simulação em andamento..." : "Executar análise completa"}
        </button>
      </section>,

      // ETAPA 5: RESULTADOS TÉCNICOS & BALANÇO MENSAL
      <section className="panel" key="technical">
        <header>
          <span className="eyebrow">Etapa 5</span>
          <h2>Resultados técnicos e balanço hidrológico</h2>
          <p>
            Desempenho hídrico, balanço de massa diário pelo modelo YAS e confiabilidade no tempo.
          </p>
        </header>

        {technical.length ? (
          <>
            <div className="metric-grid-4">
              <Metric
                label="Volume indicado"
                value={`${fmt(optimum, 0)} L`}
                detail="Melhor custo-benefício"
              />
              <Metric
                label="Economia de Água"
                value={`${fmt(optimumRow?.potable_savings_pct, 1)}%`}
                detail="Potencial de substituição"
              />
              <Metric
                label="Água Pluvial Consumida"
                value={`${fmt(optimumRow?.annual_rainwater_m3, 1)} m³/ano`}
                detail="Consumo médio anual"
              />
              <Metric
                label="Extravasamento"
                value={`${fmt(optimumRow?.annual_overflow_m3, 1)} m³/ano`}
                detail="Ladrão / Vertedouro"
              />
            </div>

            {/* GRÁFICO DE BALANÇO MENSAL (JAN A DEZ) */}
            {monthlyBalanceData.length > 0 && (
              <div className="chart-card">
                <h4>Balanço Hídrico Mensal Sazonal (Jan a Dez)</h4>
                <ResponsiveContainer width="100%" height={320}>
                  <BarChart data={monthlyBalanceData} margin={{ top: 16, right: 20, left: 8, bottom: 8 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(v) => `${fmt(Number(v), 1)} m³`} />
                    <Legend />
                    <Bar dataKey="Água Pluvial Usada (m³)" fill="#087f6b" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Rede Pública (m³)" fill="#64748b" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Extravasamento (m³)" fill="#e9a23b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* CURVA DE VARREDURA DE VOLUMES */}
            <div className="chart-card">
              <h4>Curva de Desempenho e Ganho Marginal por Volume</h4>
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={technical} margin={{ top: 16, right: 22, left: 8, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                  <XAxis dataKey="lower_tank_volume_l" tickFormatter={(v) => `${Number(v) / 1000}k`} />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => fmt(Number(value), 2)}
                    labelFormatter={(value) => `Reservatório: ${fmt(Number(value), 0)} L`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="potable_savings_pct"
                    name="Economia de Água (%)"
                    stroke="#087f6b"
                    strokeWidth={3}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="annual_overflow_m3"
                    name="Extravasamento (m³/ano)"
                    stroke="#e9a23b"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="section-card">
              <h3>Tabela de Desempenho Hidrológico Completa</h3>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Volume (L)</th>
                      <th>Economia (%)</th>
                      <th>Uso Pluvial (m³/ano)</th>
                      <th>Extravasamento (m³/ano)</th>
                      <th>Ganho Marginal (%/m³)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {technical.map((row) => (
                      <tr
                        key={row.lower_tank_volume_l}
                        className={row.lower_tank_volume_l === optimum ? "best-row" : ""}
                      >
                        <td><b>{fmt(row.lower_tank_volume_l, 0)} L</b></td>
                        <td>{fmt(row.potable_savings_pct, 1)}%</td>
                        <td>{fmt(row.annual_rainwater_m3, 1)} m³</td>
                        <td>{fmt(row.annual_overflow_m3, 1)} m³</td>
                        <td>{fmt(row.delta_potential_per_m3 || row.marginal_gain_pct_per_m3, 2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          <EmptyState />
        )}
      </section>,

      // ETAPA 6: RESULTADOS ECONÔMICOS & FLUXO DE CAIXA 20 ANOS
      <section className="panel" key="economic">
        <header>
          <span className="eyebrow">Etapa 6</span>
          <h2>Análise econômico-financeira e fluxo de caixa</h2>
          <p>
            Viabilidade pelo Fluxo de Caixa Descontado (FCD) em 20 anos, Custo Nivelado da Água (LCOW) e Payback.
          </p>
        </header>

        {economic.length ? (
          <>
            <div className="metric-grid-4">
              <Metric
                label="Melhor VPL (20 Anos)"
                value={money(result?.economic_details?.vpl_brl || economic.find((r) => r.lower_tank_volume_l === optimum)?.npv_brl)}
                detail="Retorno financeiro líquido"
              />
              <Metric
                label="Custo Nivelado (LCOW)"
                value={result?.economic_details ? `${money(result.economic_details.lcow_brl_m3)}/m³` : "—"}
                detail="Custo por m³ de água pluvial"
              />
              <Metric
                label="Relação Benefício-Custo (B/C)"
                value={result?.economic_details ? `${fmt(result.economic_details.benefit_cost_ratio, 2)}` : "—"}
                detail={result?.economic_details && result.economic_details.benefit_cost_ratio > 1 ? "Projeto Viável (B/C > 1)" : "B/C"}
              />
              <Metric
                label="Payback Descontado"
                value={
                  optimumRow?.discounted_payback_months
                    ? `${fmt(Number(optimumRow.discounted_payback_months) / 12, 1)} anos`
                    : "—"
                }
                detail={optimumRow?.simple_payback_years ? `Simples: ${fmt(optimumRow.simple_payback_years, 1)} anos` : undefined}
              />
            </div>

            {/* GRÁFICO DE FLUXO DE CAIXA ANUAL EM 20 ANOS */}
            {result?.economic_details?.annual_cash_flows?.length ? (
              <div className="chart-card">
                <h4>Projeção Anual de Fluxo de Caixa e VPL Acumulado (20 Anos)</h4>
                <ResponsiveContainer width="100%" height={340}>
                  <ComposedChart data={result.economic_details.annual_cash_flows} margin={{ top: 16, right: 20, left: 10, bottom: 8 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                    <XAxis dataKey="year" tickFormatter={(v) => `Ano ${v}`} />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip formatter={(v) => money(Number(v))} />
                    <Legend />
                    <Bar yAxisId="left" dataKey="gross_savings_brl" name="Economia Bruta (R$)" fill="#087f6b" />
                    <Bar yAxisId="left" dataKey="pump_cost_brl" name="Custo Energia (R$)" fill="#e9a23b" />
                    <Bar yAxisId="left" dataKey="om_cost_brl" name="Manutenção & O&M (R$)" fill="#ef4444" />
                    <Line yAxisId="right" type="monotone" dataKey="cumulative_npv_brl" name="VPL Acumulado (R$)" stroke="#0284c7" strokeWidth={3} dot />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="chart-card">
                <ResponsiveContainer width="100%" height={320}>
                  <LineChart data={economic} margin={{ top: 16, right: 22, left: 8, bottom: 8 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                    <XAxis dataKey="lower_tank_volume_l" tickFormatter={(v) => `${Number(v) / 1000}k`} />
                    <YAxis />
                    <Tooltip formatter={(value) => money(Number(value))} />
                    <Legend />
                    <Line type="monotone" dataKey="npv_brl" name="VPL Acumulado (R$)" stroke="#087f6b" strokeWidth={3} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="section-card">
              <h3>Tabela de Viabilidade Financeira Completa</h3>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Volume (L)</th>
                      <th>CAPEX Total (R$)</th>
                      <th>Economia 1º Ano (R$)</th>
                      <th>VPL 20 Anos (R$)</th>
                      <th>TIR (% a.a.)</th>
                      <th>Payback Desc.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {economic.map((row) => (
                      <tr
                        key={row.lower_tank_volume_l}
                        className={row.lower_tank_volume_l === optimum ? "best-row" : ""}
                      >
                        <td><b>{fmt(row.lower_tank_volume_l, 0)} L</b></td>
                        <td>{money(row.capex_total_brl || row.capex_brl)}</td>
                        <td>{money(row.annual_gross_savings_first_year_brl || row.annual_water_savings_brl)}</td>
                        <td><b>{money(row.npv_brl)}</b></td>
                        <td>{fmt(row.tir_annual_pct || row.irr_annual_pct, 1)}%</td>
                        <td>
                          {row.discounted_payback_months
                            ? `${fmt(Number(row.discounted_payback_months) / 12, 1)} anos`
                            : "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          <EmptyState />
        )}
      </section>,

      // ETAPA 7: RESULTADOS AMBIENTAIS E ESG
      <section className="panel" key="environmental">
        <header>
          <span className="eyebrow">Etapa 7</span>
          <h2>Desempenho ambiental e certificações ESG</h2>
          <p>
            Inventário de Ciclo de Vida (ISO 14040/14044), balanço de carbono e classificação em selos verdes.
          </p>
        </header>

        {environmental.length ? (
          <>
            <div className="metric-grid">
              <Metric
                label="Melhor balanço de carbono"
                value={`${fmt(environmental.find((r) => r.lower_tank_volume_l === optimum)?.lifetime_net_co2_saved_kg, 0)} kg CO₂e`}
                detail="Saldo líquido em 20 anos"
              />
              <Metric
                label="Volume ambiental ótimo"
                value={`${fmt(optimum, 0)} L`}
                detail="Maior mitigação de emissões"
              />
              <Metric
                label="Payback ecológico"
                value={
                  environmental.find((r) => r.lower_tank_volume_l === optimum)?.environmental_payback_years
                    ? `${fmt(environmental.find((r) => r.lower_tank_volume_l === optimum)?.environmental_payback_years, 1)} anos`
                    : "—"
                }
                detail="Tempo de retorno de carbono"
              />
            </div>

            <div className="esg-grid">
              <div className="esg-card leed">
                <h4>
                  <span>LEED v4 / v4.1 BD+C & O+M</span>
                  <ShieldCheck size={18} color="#10b981" />
                </h4>
                <p>
                  Créditos de Eficiência Hídrica (WEc1 Uso Externo / Irrigação e
                  WEc2 Uso Interno). Redução de consumo potável nos pontos de uso não nobres.
                </p>
                <span className="esg-badge">Até 4 Pontos LEED WE</span>
              </div>

              <div className="esg-card aqua">
                <h4>
                  <span>Processo AQUA-HQE</span>
                  <ShieldCheck size={18} color="#0284c7" />
                </h4>
                <p>
                  Avaliação da Categoria 4 (Gestão da Água). Redução da pegada
                  hídrica da edificação e retenção de picos de escoamento.
                </p>
                <span className="esg-badge">Nível Excelente (⭐⭐⭐)</span>
              </div>

              <div className="esg-card caixa">
                <h4>
                  <span>Selo Casa Azul CAIXA</span>
                  <ShieldCheck size={18} color="#f59e0b" />
                </h4>
                <p>
                  Critério 2.1 — Dispositivos Economizadores e Aproveitamento de
                  Água Pluvial. Pontuação direta para habitações sustentáveis.
                </p>
                <span className="esg-badge">+6 Pontos · Categoria Diamante</span>
              </div>

              <div className="esg-card gri">
                <h4>
                  <span>GRI Standard 303 (Água & Efluentes)</span>
                  <ShieldCheck size={18} color="#8b5cf6" />
                </h4>
                <p>
                  Divulgação 303-3 (Retirada de Água) e 303-5 (Consumo). Rastreabilidade
                  de descarbonização e Water Positive Ratio corporativo.
                </p>
                <span className="esg-badge">GRI 303-3 / 303-5 Conforme</span>
              </div>
            </div>

            <div className="chart-card">
              <ResponsiveContainer width="100%" height={330}>
                <LineChart data={environmental} margin={{ top: 16, right: 22, left: 8, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                  <XAxis dataKey="lower_tank_volume_l" tickFormatter={(v) => `${Number(v) / 1000}k`} />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => `${fmt(Number(value), 1)} kg CO2e`}
                    labelFormatter={(value) => `Reservatório: ${fmt(Number(value), 0)} L`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="lifetime_net_co2_saved_kg"
                    name="Saldo Líquido de CO₂e em 20 Anos (kg)"
                    stroke="#087f6b"
                    strokeWidth={3}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="embodied_co2_kg"
                    name="Carbono Incorporado Inicial (kg)"
                    stroke="#dc2626"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </>
        ) : (
          <EmptyState />
        )}
      </section>,

      // ETAPA 8: OTIMIZAÇÃO TOPSIS & COMPARADOR MULTICENÁRIOS
      <section className="panel" key="optimization">
        <header>
          <span className="eyebrow">Etapa 8</span>
          <h2>Otimização multicritério e comparador multicenários</h2>
          <p>
            Pondere o desempenho hídrico, viabilidade financeira e mitigação de carbono, ou compare hipóteses de projeto lado a lado.
          </p>
        </header>

        <div className="subtabs-bar">
          <button
            type="button"
            className={`subtab-btn ${step8Tab === "topsis" ? "active" : ""}`}
            onClick={() => setStep8Tab("topsis")}
          >
            <SlidersHorizontal size={16} /> Decisão Multicritério TOPSIS
          </button>
          <button
            type="button"
            className={`subtab-btn ${step8Tab === "scenarios" ? "active" : ""}`}
            onClick={() => setStep8Tab("scenarios")}
          >
            <Layers size={16} /> Comparador Multicenários & Sensibilidade
          </button>
        </div>

        {step8Tab === "topsis" ? (
          <>
            <div className="section-card">
              <h3>Ponderação de Critérios de Decisão</h3>
              <div className="form-grid">
                <Field
                  label="Peso Técnico (Economia de Água)"
                  value={weights[0]}
                  suffix="%"
                  min={0}
                  onChange={(v) => setWeights([Number(v), weights[1], weights[2]])}
                />
                <Field
                  label="Peso Econômico (VPL / Retorno)"
                  value={weights[1]}
                  suffix="%"
                  min={0}
                  onChange={(v) => setWeights([weights[0], Number(v), weights[2]])}
                />
                <Field
                  label="Peso Ambiental (Saldo CO2e)"
                  value={weights[2]}
                  suffix="%"
                  min={0}
                  onChange={(v) => setWeights([weights[0], weights[1], Number(v)])}
                />
                <Field
                  label="Amostras de sensibilidade"
                  value={sensitivity}
                  min={0}
                  max={5000}
                  onChange={(v) => setSensitivity(Number(v))}
                />
              </div>
              <button
                className="secondary"
                onClick={run}
                disabled={running}
                style={{ marginTop: 12 }}
              >
                <Calculator size={17} /> Recalcular TOPSIS
              </button>
            </div>

            {result?.topsis ? (
              <>
                <div className="metric-grid">
                  <Metric
                    label="Volume recomendado"
                    value={`${fmt(result.topsis.best_volume_l, 0)} L`}
                    detail="Melhor compromisso TOPSIS"
                  />
                  <Metric
                    label="Índice de proximidade (Ci*)"
                    value={fmt(result.topsis.best_score, 3)}
                    detail="Distância relativa ao ponto ideal"
                  />
                  <Metric
                    label="Alternativas avaliadas"
                    value={String(result.topsis.ranking.length)}
                    detail="Varredura completa"
                  />
                </div>

                <div className="chart-card">
                  <h4>Ranking das Alternativas (Score de Decisão Multicritério vs Volume)</h4>
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart
                      data={result.topsis.ranking.map((r) => ({
                        volume: `${fmt(r.lower_tank_volume_l, 0)} L`,
                        score: Number((r.score ?? 0).toFixed(4)),
                        rank: r.rank,
                      }))}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                      <XAxis dataKey="volume" />
                      <YAxis domain={[0, 1]} />
                      <Tooltip formatter={(v) => `${Number(v).toFixed(4)} (Score)`} />
                      <Bar dataKey="score" name="Score TOPSIS (Ci*)" fill="#087f6b" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="section-card">
                  <h3>Matriz de Ranking TOPSIS</h3>
                  <div className="table-wrap">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Volume (L)</th>
                          <th>Score (Ci*)</th>
                          <th>Rank</th>
                          <th>Dist. Ideal (d+)</th>
                          <th>Dist. Anti-ideal (d-)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {result.topsis.ranking.map((row) => (
                          <tr
                            key={row.lower_tank_volume_l}
                            className={
                              row.lower_tank_volume_l === result.topsis?.best_volume_l
                                ? "best-row"
                                : ""
                            }
                          >
                            <td><b>{fmt(row.lower_tank_volume_l, 0)} L</b></td>
                            <td>{fmt(row.score, 4)}</td>
                            <td><b>#{row.rank}</b></td>
                            <td>{fmt(row.distance_to_ideal, 4)}</td>
                            <td>{fmt(row.distance_from_anti_ideal, 4)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            ) : (
              <EmptyState />
            )}
          </>
        ) : (
          <Suspense fallback={<div className="section-card">Carregando comparador de cenários…</div>}>
          <ScenarioComparator
            currentResult={result}
            currentConfig={config}
            currentRainName={rainName}
          />
          </Suspense>
        )}
      </section>,

      // ETAPA 9: RELATÓRIOS E EXPORTAÇÕES
      <section className="panel" key="reports">
        <header>
          <span className="eyebrow">Etapa 9</span>
          <h2>Relatórios e exportações oficiais</h2>
          <p>
            Gere laudos técnicos profissionais diagramados em A4, relatórios
            ambientais de ACV/ESG e planilhas auditáveis.
          </p>
        </header>

        {jobId && result ? (
          <>
            {result.technical?.alternatives && result.technical.alternatives.length > 0 && (
              <div
                className="report-volume-selector-bar"
                style={{
                  display: "flex",
                  alignItems: "center",
                  flexWrap: "wrap",
                  gap: "12px",
                  marginBottom: "20px",
                  padding: "14px 18px",
                  background: "var(--surface-color, #ffffff)",
                  border: "1px solid var(--border-color, #e2e8f0)",
                  borderRadius: "8px",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
                }}
              >
                <label
                  htmlFor="report-volume-select"
                  style={{
                    fontWeight: 600,
                    fontSize: "0.92rem",
                    color: "var(--text-primary, #1e293b)",
                  }}
                >
                  💧 Volume do Reservatório para os Relatórios:
                </label>
                <select
                  id="report-volume-select"
                  value={
                    selectedReportVolume ??
                    (result?.topsis?.best_volume_l ??
                      result?.technical?.summary?.optimal_volume_l ??
                      "")
                  }
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    const newVol = isNaN(val) ? null : val;
                    setSelectedReportVolume(newVol);
                    if (previewHtml) {
                      loadReportPreview(previewModel, newVol ?? undefined);
                    }
                  }}
                  style={{
                    padding: "7px 14px",
                    borderRadius: "6px",
                    border: "1px solid #cbd5e1",
                    fontSize: "0.9rem",
                    fontWeight: 500,
                    minWidth: "260px",
                    cursor: "pointer",
                  }}
                >
                  {result.technical.alternatives.map((alt) => {
                    const vol = alt.lower_tank_volume_l;
                    const isEconOpt =
                      vol ===
                      (result.economic?.summary?.optimal_volume_l ??
                        result.topsis?.best_volume_l);
                    const isEnvOpt =
                      vol ===
                      (result.environmental?.summary?.optimal_volume_l ??
                        result.topsis?.best_volume_l);
                    const isTopsisOpt = vol === result.topsis?.best_volume_l;
                    const tags: string[] = [];
                    if (isEconOpt) tags.push("Ótimo Econômico");
                    if (isEnvOpt) tags.push("Ótimo Ambiental");
                    if (isTopsisOpt && !isEconOpt && !isEnvOpt)
                      tags.push("Recomendado TOPSIS");
                    const tagStr = tags.length ? ` (${tags.join(" & ")})` : "";
                    return (
                      <option key={vol} value={vol}>
                        {vol.toLocaleString("pt-BR")} L{tagStr}
                      </option>
                    );
                  })}
                </select>
                <span
                  style={{
                    fontSize: "0.82rem",
                    color: "var(--text-muted, #64748b)",
                  }}
                >
                  (Permite gerar laudos econômicos ou ambientais para qualquer capacidade simulada)
                </span>
              </div>
            )}

            <div className="report-models-grid">
              <div className="report-model-card">
                <div className="card-head">
                  <FileText />
                  <div>
                    <h4>Laudo Técnico Executivo</h4>
                  </div>
                </div>
                <p>
                  Dashboard de 1 página A4 com KPIs gerenciais, balanço hídrico,
                  indicadores de VPL/TIR/Payback e assinatura técnica. Ideal
                  para clientes e aprovação rápida.
                </p>
                <div className="actions">
                  <button
                    className="secondary"
                    onClick={() => loadReportPreview("executive")}
                  >
                    <Eye size={15} /> Ver Relatório
                  </button>
                  <a
                    className="primary"
                    href={getExportUrl(
                      jobId,
                      "html",
                      "executive",
                      locale,
                      selectedReportVolume ?? undefined
                    )}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <FileDown size={15} /> Baixar HTML
                  </a>
                </div>
              </div>

              <div className="report-model-card">
                <div className="card-head">
                  <Leaf />
                  <div>
                    <h4>Relatório Ambiental & ESG</h4>
                  </div>
                </div>
                <p>
                  Laudo completo de Análise do Ciclo de Vida (ISO 14040/14044),
                  pegada de carbono, payback ecológico e matriz de certificações
                  verdes (LEED v4, AQUA-HQE, Selo Casa Azul, GRI 303).
                </p>
                <div className="actions">
                  <button
                    className="secondary"
                    onClick={() => loadReportPreview("environmental")}
                  >
                    <Eye size={15} /> Ver Relatório
                  </button>
                  <a
                    className="primary"
                    href={getExportUrl(
                      jobId,
                      "html",
                      "environmental",
                      locale,
                      selectedReportVolume ?? undefined
                    )}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <FileDown size={15} /> Baixar HTML
                  </a>
                </div>
              </div>

              <div className="report-model-card">
                <div className="card-head">
                  <BookOpen />
                  <div>
                    <h4>Relatório de Pesquisa & TCC</h4>
                  </div>
                </div>
                <p>
                  Relatório técnico-científico exaustivo com capa institucional
                  UFSC, memorial de cálculo, tabelas de varredura, análise
                  multicritério TOPSIS e equações.
                </p>
                <div className="actions">
                  <button
                    className="secondary"
                    onClick={() => loadReportPreview("research")}
                  >
                    <Eye size={15} /> Ver Relatório
                  </button>
                  <a
                    className="primary"
                    href={getExportUrl(
                      jobId,
                      "html",
                      "research",
                      locale,
                      selectedReportVolume ?? undefined
                    )}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <FileDown size={15} /> Baixar HTML
                  </a>
                </div>
              </div>
            </div>

            {previewHtml && (
              <div className="report-preview-box">
                <div className="report-preview-header">
                  <strong>
                    Visualização Prévia:{" "}
                    {previewModel === "executive"
                      ? "Laudo Técnico Executivo"
                      : previewModel === "environmental"
                      ? "Relatório Ambiental & ESG"
                      : "Relatório de Pesquisa Científica"}
                  </strong>
                  <div style={{ display: "flex", gap: 8 }}>
                    <a
                      className="secondary"
                      href={getExportUrl(
                        jobId,
                        "html",
                        previewModel,
                        locale,
                        selectedReportVolume ?? undefined
                      )}
                      target="_blank"
                      rel="noreferrer"
                    >
                      Abrir em nova aba
                    </a>
                    <button
                      className="ghost"
                      onClick={() => setPreviewHtml(null)}
                    >
                      <X size={16} /> Fechar
                    </button>
                  </div>
                </div>
                {loadingPreview ? (
                  <div style={{ padding: 40, textAlign: "center" }}>
                    Carregando relatório...
                  </div>
                ) : (
                  <iframe
                    className="report-preview-iframe"
                    srcDoc={previewHtml}
                    title="Pré-visualização do Relatório"
                  />
                )}
              </div>
            )}

            <div className="section-card">
              <h3>Exportação de Planilhas e Dados Brutos</h3>
              <div className="export-grid">
                <a
                  className="export"
                  href={getExportUrl(jobId, "xlsx", "data", locale)}
                >
                  <FileSpreadsheet />
                  <strong>EXCEL (.xlsx)</strong>
                  <span>Planilha Completa</span>
                </a>
                <a
                  className="export"
                  href={getExportUrl(jobId, "csv", "data", locale)}
                >
                  <TableProperties />
                  <strong>CSV (.csv)</strong>
                  <span>Separado por ponto-e-vírgula</span>
                </a>
                <a
                  className="export"
                  href={getExportUrl(jobId, "json", "data", locale)}
                >
                  <FileText />
                  <strong>JSON (.json)</strong>
                  <span>Dados Estruturados</span>
                </a>
                <a
                  className="export"
                  href={getExportUrl(jobId, "pdf", "summary", locale)}
                >
                  <FileDown />
                  <strong>PDF Resumo</strong>
                  <span>Documento em Tabela</span>
                </a>
                <button
                  className="export"
                  onClick={saveProject}
                  style={{ cursor: "pointer" }}
                >
                  <Download />
                  <strong>PROJETO (.netuno)</strong>
                  <span>Compatível com Desktop</span>
                </button>
              </div>
            </div>
          </>
        ) : (
          <EmptyState />
        )}
      </section>,

      // ETAPA 10: DOCUMENTAÇÃO METODOLÓGICA & NORMAS
      <section className="panel" key="docs">
        <header>
          <span className="eyebrow">Etapa 10</span>
          <h2>Documentação Metodológica, Normas e Base Teórica</h2>
          <p>
            Rastreabilidade completa de todas as equações, métodos científicos de dimensionamento,
            ACV, diretrizes da ABNT NBR 15527 e referências bibliográficas do Netuno 5.
          </p>
        </header>
        <Suspense fallback={<div className="section-card" style={{ padding: 40, textAlign: "center" }}>Carregando base de documentação técnica...</div>}>
          <DocumentationViewer />
        </Suspense>
      </section>,

      // ETAPA 11: TARIFAS MUNICIPAIS
      <Tariffs
        key="tariffs"
        onApplyTariff={(data) => {
          if (data.tarifa_fixa_mensal !== undefined) {
            update("water_tax_fixed", Number(data.tarifa_fixa_mensal));
          }
          if (data.energia_r_kwh !== undefined) {
            update("elec_tariff", Number(data.energia_r_kwh));
          }
          if (data.taxa_esgoto_pct !== undefined) {
            update("sewage_rate", Number(data.taxa_esgoto_pct));
          }
          setStatus(
            `Tarifas de ${data.municipio || "município"} aplicadas ao projeto atual.`
          );
        }}
      />,
    ],
    [
      config,
      rainfall,
      rainName,
      result,
      running,
      jobId,
      status,
      weights,
      sensitivity,
      technical,
      economic,
      environmental,
      optimum,
      optimumRow,
      rainInputMode,
      climateCatalog,
      selectedClimateCity,
      selectedClimateModel,
      selectedClimateScenario,
      climateSearch,
      filteredClimateCities,
      previewHtml,
      previewModel,
      loadingPreview,
      locale,
      totalDailyNonPotableLiters,
      step8Tab,
      monthlyBalanceData,
    ]
  );

  return (
    <div
      className="app-shell"
      key={locale}
      ref={appRef}
      lang={locale === "zh" ? "zh-CN" : locale}
    >
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <Droplets />
          </div>
          <div>
            <strong>NETUNO 5</strong>
            <span>UFSC · Web</span>
          </div>
          <button
            className="icon-button close-menu"
            onClick={() => setMobileOpen(false)}
          >
            <X />
          </button>
        </div>
        <nav aria-label="Etapas da análise">
          {steps.map(([label, Icon], index) => (
            <button
              key={label}
              className={active === index ? "active" : ""}
              onClick={() => {
                setActive(index);
                setMobileOpen(false);
              }}
            >
              <span>{String(index + 1).padStart(2, "0")}</span>
              <Icon />
              <em>{label}</em>
              {index < 4 && rainfall.length > 0 && (
                <CheckCircle2 className="done" />
              )}
            </button>
          ))}
        </nav>
        <footer>
          <a href="/downloads/Netuno-Setup.exe">
            <Download /> Baixar versão desktop
          </a>
          <span>Motor científico compartilhado · ABNT NBR 15527</span>
        </footer>
      </aside>

      <main>
        <div className="topbar">
          <button
            className="icon-button menu-button"
            onClick={() => setMobileOpen(true)}
          >
            <Menu />
          </button>
          <div className="crumb">
            <span>Projeto atual</span>
            <strong>{String(config.project_name || "Novo projeto")}</strong>
          </div>
          <div className="status-pill">
            <span className={running ? "pulse" : ""} />
            {running ? `${progress}%` : status}
          </div>
          <select
            className="language-select"
            aria-label="Idioma"
            value={locale}
            onChange={(e) => setLocale(e.target.value as Locale)}
          >
            <option value="pt">PT</option>
            <option value="en">EN</option>
            <option value="es">ES</option>
            <option value="zh">中文</option>
          </select>
          <button className="primary run-top" onClick={run} disabled={running}>
            <Play size={16} /> Simular
          </button>
        </div>
        <div className="content">{sections[active]}</div>
      </main>
    </div>
  );
}

function Tariffs({
  onApplyTariff,
}: {
  onApplyTariff: (data: TariffCityData) => void;
}) {
  const [ufs, setUfs] = useState<{ code: string; name: string }[]>([]);
  const [uf, setUf] = useState("SC");
  const [cities, setCities] = useState<string[]>([]);
  const [city, setCity] = useState("Florianópolis");
  const [data, setData] = useState<TariffCityData | null>(null);

  useEffect(() => {
    loadTariffUfs()
      .then((items) => setUfs(items))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    loadTariffCities(uf)
      .then((items) => {
        setCities(items);
        const targetCity = items.includes("Florianópolis")
          ? "Florianópolis"
          : items.includes("São Paulo")
          ? "São Paulo"
          : items[0] || "";
        setCity(targetCity);
        if (targetCity) {
          loadTariff(uf, targetCity).then(setData).catch(() => setData(null));
        }
      })
      .catch(() => setCities([]));
  }, [uf]);

  const consult = (targetCity = city) => {
    if (targetCity) {
      loadTariff(uf, targetCity)
        .then(setData)
        .catch(() => setData(null));
    }
  };

  const QUICK_UFS = ["SC", "SP", "RJ", "MG", "PR", "RS", "BA", "DF", "PE", "CE", "AM", "GO"];

  return (
    <section className="panel">
      <header>
        <span className="eyebrow">Etapa 11</span>
        <h2>Catálogo nacional de tarifas municipais</h2>
        <p>
          Consulta pública às tabelas de água, esgoto e energia elétrica de
          concessionárias em todo o Brasil (652 municípios indexados).
        </p>
      </header>

      <div className="section-card">
        <div className="quick-chips-wrap">
          <span>Estados / UFs de Acesso Rápido:</span>
          <div className="quick-chips">
            {QUICK_UFS.map((u) => (
              <button
                key={u}
                type="button"
                className={`chip-btn ${uf === u ? "active" : ""}`}
                onClick={() => setUf(u)}
              >
                {u}
              </button>
            ))}
          </div>
        </div>

        <div className="form-grid">
          <label className="field">
            <span>UF / Estado</span>
            <select value={uf} onChange={(e) => setUf(e.target.value)}>
              {ufs.length > 0
                ? ufs.map((item) => (
                    <option key={item.code} value={item.code}>
                      {item.code} — {item.name}
                    </option>
                  ))
                : UF_CODES.map((code) => <option key={code}>{code}</option>)}
            </select>
          </label>

          <label className="field">
            <span>Município ({cities.length} cadastrados)</span>
            <select
              value={city}
              onChange={(e) => {
                const c = e.target.value;
                setCity(c);
                consult(c);
              }}
            >
              {cities.map((name) => (
                <option key={name} value={name}>{name}</option>
              ))}
            </select>
          </label>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button className="primary" onClick={() => consult(city)}>
            <Search size={16} /> Consultar tarifas
          </button>
          {data && (
            <button className="secondary" onClick={() => onApplyTariff(data)}>
              <RefreshCw size={16} /> Aplicar tarifas no projeto atual
            </button>
          )}
        </div>
      </div>

      {data && (
        <>
          <div className="metric-grid">
            <Metric
              label="Município / Concessionária"
              value={String(data.municipio || city)}
              detail={data.concessionaria || "Tarifa Residencial"}
            />
            <Metric
              label="Taxa Fixa Mensal"
              value={money(Number(data.tarifa_fixa_mensal || 0))}
              detail="Parcela básica fixa"
            />
            <Metric
              label="Tarifa de Energia"
              value={`${money(Number(data.energia_r_kwh || 0.95))}/kWh`}
              detail="Custo elétrico de bombeamento"
            />
          </div>

          {(data.faixas || data.faixas_agua) && (
            <div className="section-card">
              <h3>Estrutura Tarifária por Faixa de Consumo (R$/m³)</h3>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Faixa de Consumo</th>
                      <th>Tarifa Água (R$/m³)</th>
                      <th>Tarifa Esgoto (R$/m³)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(data.faixas_agua || data.faixas || []).map((tier, idx) => (
                      <tr key={idx}>
                        <td>
                          Até {tier.limite_m3 || tier.faixa_fim || "Acima"} m³
                        </td>
                        <td>
                          {money(
                            tier.tarifa_agua_r_m3 || tier.tarifa_unitaria || 0
                          )}
                        </td>
                        <td>
                          {money(tier.tarifa_esgoto_r_m3 || 0)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </section>
  );
}

const UF_CODES = [
  "AC",
  "AL",
  "AP",
  "AM",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MT",
  "MS",
  "MG",
  "PA",
  "PB",
  "PR",
  "PE",
  "PI",
  "RJ",
  "RN",
  "RS",
  "RO",
  "RR",
  "SC",
  "SP",
  "SE",
  "TO",
];

export default App;
