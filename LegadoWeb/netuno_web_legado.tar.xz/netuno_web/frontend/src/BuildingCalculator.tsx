import React, { useState, useMemo } from "react";
import {
  Building2,
  Home,
  Briefcase,
  GraduationCap,
  Factory,
  Hotel,
  Hospital,
  ShoppingBag,
  Car,
  Check,
  Layers,
  Sparkles,
  Calculator,
  Droplets,
  HelpCircle,
} from "lucide-react";
import type { BuildingTemplate, Config } from "./types";

export const BUILDING_TEMPLATES: BuildingTemplate[] = [
  {
    id: "res_medio",
    name: "Residencial Médio",
    icon: "🏠",
    description: "Unifamiliar padrão médio (150 L/hab/dia, 40% pluvial)",
    occupantLabel: "Moradores",
    defaultResidents: 4,
    defaultPerCapita: 150,
    defaultShare: 0.4,
    potableIndoorShare: 0.65,
    nonPotableIndoorShare: 0.35,
    gardenArea: 15,
    gardenRate: 3.0,
    toiletFlushes: 4,
    toiletVolume: 6,
    washingCyclesWeekly: 3,
    washingVolumePerCycle: 100,
    washFloorsWeeklyLiters: 35,
  },
  {
    id: "res_popular",
    name: "Residencial Popular",
    icon: "🏡",
    description: "Unifamiliar econômico / popular (120 L/hab/dia, 35% pluvial)",
    occupantLabel: "Moradores",
    defaultResidents: 4,
    defaultPerCapita: 120,
    defaultShare: 0.35,
    potableIndoorShare: 0.68,
    nonPotableIndoorShare: 0.32,
    gardenArea: 10,
    gardenRate: 2.0,
    toiletFlushes: 4,
    toiletVolume: 6,
    washingCyclesWeekly: 2,
    washingVolumePerCycle: 80,
    washFloorsWeeklyLiters: 25,
  },
  {
    id: "res_alto",
    name: "Residencial Alto Padrão",
    icon: "🏰",
    description: "Unifamiliar alto padrão com jardim amplo (220 L/hab/dia, 45% pluvial)",
    occupantLabel: "Moradores",
    defaultResidents: 4,
    defaultPerCapita: 220,
    defaultShare: 0.45,
    potableIndoorShare: 0.6,
    nonPotableIndoorShare: 0.4,
    gardenArea: 40,
    gardenRate: 3.5,
    toiletFlushes: 5,
    toiletVolume: 6,
    washingCyclesWeekly: 4,
    washingVolumePerCycle: 120,
    washFloorsWeeklyLiters: 70,
  },
  {
    id: "res_multi",
    name: "Edifício Residencial",
    icon: "🏢",
    description: "Edifício multifamiliar / apartamentos (140 L/hab/dia)",
    occupantLabel: "Total de Moradores",
    defaultResidents: 48,
    defaultPerCapita: 140,
    defaultShare: 0.38,
    potableIndoorShare: 0.65,
    nonPotableIndoorShare: 0.35,
    gardenArea: 30,
    gardenRate: 2.5,
    toiletFlushes: 4,
    toiletVolume: 6,
    washingCyclesWeekly: 36,
    washingVolumePerCycle: 90,
    washFloorsWeeklyLiters: 150,
  },
  {
    id: "comercial",
    name: "Comercial / Escritórios",
    icon: "🏬",
    description: "Edifício de escritórios e serviços (50 L/pessoa/dia, 65% pluvial)",
    occupantLabel: "Funcionários / Ocupantes",
    defaultResidents: 60,
    defaultPerCapita: 50,
    defaultShare: 0.65,
    potableIndoorShare: 0.35,
    nonPotableIndoorShare: 0.65,
    gardenArea: 20,
    gardenRate: 2.0,
    toiletFlushes: 3,
    toiletVolume: 6,
    washingCyclesWeekly: 0,
    washingVolumePerCycle: 0,
    washFloorsWeeklyLiters: 100,
  },
  {
    id: "escola",
    name: "Escola / Universidade",
    icon: "🏫",
    description: "Instituição de ensino diurna (30 L/aluno/dia, 70% pluvial)",
    occupantLabel: "Alunos + Professores",
    defaultResidents: 250,
    defaultPerCapita: 30,
    defaultShare: 0.7,
    potableIndoorShare: 0.3,
    nonPotableIndoorShare: 0.7,
    gardenArea: 50,
    gardenRate: 2.5,
    toiletFlushes: 2,
    toiletVolume: 6,
    washingCyclesWeekly: 0,
    washingVolumePerCycle: 0,
    washFloorsWeeklyLiters: 200,
  },
  {
    id: "industria",
    name: "Indústria / Galpão",
    icon: "🏭",
    description: "Galpão logístico e manufatura (70 L/func/dia, 60% pluvial)",
    occupantLabel: "Trabalhadores",
    defaultResidents: 80,
    defaultPerCapita: 70,
    defaultShare: 0.6,
    potableIndoorShare: 0.4,
    nonPotableIndoorShare: 0.6,
    gardenArea: 40,
    gardenRate: 2.0,
    toiletFlushes: 3,
    toiletVolume: 6,
    washingCyclesWeekly: 5,
    washingVolumePerCycle: 100,
    washFloorsWeeklyLiters: 300,
  },
  {
    id: "hotel",
    name: "Hotel / Pousada",
    icon: "🏨",
    description: "Hotelaria e hospedagem (250 L/hóspede/dia, 35% pluvial)",
    occupantLabel: "Hóspedes / Ocupação média",
    defaultResidents: 40,
    defaultPerCapita: 250,
    defaultShare: 0.35,
    potableIndoorShare: 0.65,
    nonPotableIndoorShare: 0.35,
    gardenArea: 60,
    gardenRate: 3.0,
    toiletFlushes: 4,
    toiletVolume: 6,
    washingCyclesWeekly: 28,
    washingVolumePerCycle: 150,
    washFloorsWeeklyLiters: 120,
  },
  {
    id: "hospital",
    name: "Hospital / Clínica",
    icon: "🏥",
    description: "Saúde e internação (300 L/leito/dia, 30% pluvial)",
    occupantLabel: "Leitos / Ocupantes",
    defaultResidents: 50,
    defaultPerCapita: 300,
    defaultShare: 0.3,
    potableIndoorShare: 0.7,
    nonPotableIndoorShare: 0.3,
    gardenArea: 30,
    gardenRate: 2.0,
    toiletFlushes: 4,
    toiletVolume: 6,
    washingCyclesWeekly: 35,
    washingVolumePerCycle: 120,
    washFloorsWeeklyLiters: 400,
  },
  {
    id: "shopping",
    name: "Shopping Center",
    icon: "🛒",
    description: "Centro comercial e varejo (15 L/visitante/dia, 80% pluvial)",
    occupantLabel: "Visitantes diários",
    defaultResidents: 1200,
    defaultPerCapita: 15,
    defaultShare: 0.8,
    potableIndoorShare: 0.2,
    nonPotableIndoorShare: 0.8,
    gardenArea: 80,
    gardenRate: 2.5,
    toiletFlushes: 1,
    toiletVolume: 6,
    washingCyclesWeekly: 0,
    washingVolumePerCycle: 0,
    washFloorsWeeklyLiters: 500,
  },
  {
    id: "lavajato",
    name: "Posto / Lava-jato",
    icon: "🚗",
    description: "Lavagem automotiva (150 L/veículo, 90% pluvial)",
    occupantLabel: "Veículos lavados/dia",
    defaultResidents: 25,
    defaultPerCapita: 150,
    defaultShare: 0.9,
    potableIndoorShare: 0.1,
    nonPotableIndoorShare: 0.9,
    gardenArea: 10,
    gardenRate: 1.5,
    toiletFlushes: 2,
    toiletVolume: 6,
    washingCyclesWeekly: 0,
    washingVolumePerCycle: 0,
    washFloorsWeeklyLiters: 200,
  },
];

export const ROOF_MATERIALS = [
  { name: "Telha Cerâmica (Barro)", c: 0.85, desc: "Padrão residencial tradicional" },
  { name: "Telha Metálica / Aluzinco", c: 0.95, desc: "Alta eficiência e menor retenção" },
  { name: "Fibrocimento", c: 0.80, desc: "Leve rugosidade superficial" },
  { name: "Laje Impermeabilizada", c: 0.80, desc: "Concreto com manta asfáltica" },
  { name: "Telhado Verde / Extensivo", c: 0.40, desc: "Retenção e evapotranspiração" },
  { name: "Vidro / Policarbonato", c: 0.95, desc: "Superfície totalmente lisa" },
];

interface BuildingCalculatorProps {
  config: Config;
  updateConfig: (key: string, value: string | number | boolean) => void;
}

export const BuildingCalculator: React.FC<BuildingCalculatorProps> = ({
  config,
  updateConfig,
}) => {
  const [activeTab, setActiveTab] = useState<"templates" | "fixtures">("templates");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("res_medio");

  // Fixture states
  const [toiletFlushes, setToiletFlushes] = useState(4);
  const [toiletVolume, setToiletVolume] = useState(6);
  const [washCyclesWeekly, setWashCyclesWeekly] = useState(3);
  const [washVolPerCycle, setWashVolPerCycle] = useState(100);
  const [gardenArea, setGardenArea] = useState(15);
  const [gardenRate, setGardenRate] = useState(3.0);
  const [floorWashWeekly, setFloorWashWeekly] = useState(35);

  const residents = Number(config.residents_count || 4);
  const demandPerCapita = Number(config.demand_value || 120);
  const rainwaterShare = Number(config.rainwater_share || 0.4);
  const irrigationLiters = Number(config.irrigation_liters_per_day || 0);

  // Detailed fixture calculations
  const fixtureDailyPluvial = useMemo(() => {
    const dailyToilet = residents * toiletFlushes * toiletVolume;
    const dailyWashing = (washCyclesWeekly * washVolPerCycle) / 7.0;
    const dailyGarden = gardenArea * gardenRate;
    const dailyFloors = floorWashWeekly / 7.0;
    return dailyToilet + dailyWashing + dailyGarden + dailyFloors;
  }, [residents, toiletFlushes, toiletVolume, washCyclesWeekly, washVolPerCycle, gardenArea, gardenRate, floorWashWeekly]);

  const applyTemplate = (tmpl: BuildingTemplate) => {
    setSelectedTemplateId(tmpl.id);
    updateConfig("residents_count", tmpl.defaultResidents);
    updateConfig("demand_value", tmpl.defaultPerCapita);
    updateConfig("rainwater_share", tmpl.defaultShare);
    updateConfig("potable_indoor_share", tmpl.potableIndoorShare);
    updateConfig("non_potable_indoor_share", tmpl.nonPotableIndoorShare);
    
    const dailyGarden = tmpl.gardenArea * tmpl.gardenRate;
    updateConfig("irrigation_liters_per_day", Math.round(dailyGarden));

    setToiletFlushes(tmpl.toiletFlushes);
    setToiletVolume(tmpl.toiletVolume);
    setWashCyclesWeekly(tmpl.washingCyclesWeekly);
    setWashVolPerCycle(tmpl.washingVolumePerCycle);
    setGardenArea(tmpl.gardenArea);
    setGardenRate(tmpl.gardenRate);
    setFloorWashWeekly(tmpl.washFloorsWeeklyLiters);
  };

  const applyFixtureCalculations = () => {
    const totalDailyIndoor = residents * demandPerCapita;
    const calculatedShare = totalDailyIndoor > 0 ? Math.min(1.0, fixtureDailyPluvial / totalDailyIndoor) : rainwaterShare;
    updateConfig("rainwater_share", calculatedShare);
    updateConfig("irrigation_liters_per_day", Math.round(gardenArea * gardenRate));
  };

  const currentTmpl = BUILDING_TEMPLATES.find((t) => t.id === selectedTemplateId) || BUILDING_TEMPLATES[0];

  return (
    <div className="building-calculator-root">
      {/* Subtabs de Alternância de Modo */}
      <div className="subtabs-bar">
        <button
          type="button"
          className={`subtab-btn ${activeTab === "templates" ? "active" : ""}`}
          onClick={() => setActiveTab("templates")}
        >
          <Building2 size={16} /> Catálogo de Tipologias Prediais (11 Modelos)
        </button>
        <button
          type="button"
          className={`subtab-btn ${activeTab === "fixtures" ? "active" : ""}`}
          onClick={() => setActiveTab("fixtures")}
        >
          <Calculator size={16} /> Detalhamento Avançado por Aparelhos Sanitários
        </button>
      </div>

      {activeTab === "templates" && (
        <div className="templates-section">
          <div className="section-heading">
            <div>
              <h3>Selecione a Tipologia da Edificação</h3>
              <p>Carrega premissas recomendadas de consumo per capita e fração não potável conforme NBR 5626 e NBR 15527.</p>
            </div>
          </div>

          <div className="templates-grid">
            {BUILDING_TEMPLATES.map((tmpl) => {
              const isSelected = selectedTemplateId === tmpl.id;
              return (
                <button
                  key={tmpl.id}
                  type="button"
                  className={`template-card ${isSelected ? "selected" : ""}`}
                  onClick={() => applyTemplate(tmpl)}
                >
                  <div className="tmpl-icon">{tmpl.icon}</div>
                  <div className="tmpl-info">
                    <strong>{tmpl.name}</strong>
                    <span>{tmpl.description}</span>
                  </div>
                  {isSelected && (
                    <div className="tmpl-check">
                      <Check size={14} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className="section-card" style={{ marginTop: 18 }}>
            <h3>Premissas da Tipologia: {currentTmpl.name}</h3>
            <div className="form-grid">
              <label className="field">
                <span>{currentTmpl.occupantLabel}</span>
                <input
                  type="number"
                  min={1}
                  value={Number(config.residents_count || 4)}
                  onChange={(e) => updateConfig("residents_count", Number(e.target.value))}
                />
              </label>

              <label className="field">
                <span>Consumo Per Capita (L/pessoa/dia)</span>
                <input
                  type="number"
                  min={10}
                  value={Number(config.demand_value || 120)}
                  onChange={(e) => updateConfig("demand_value", Number(e.target.value))}
                />
              </label>

              <label className="field">
                <span>Fração Destinada a Água Pluvial (%)</span>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={Math.round(Number(config.rainwater_share || 0.4) * 100)}
                  onChange={(e) => updateConfig("rainwater_share", Number(e.target.value) / 100)}
                />
              </label>

              <label className="field">
                <span>Irrigação de Áreas Verdes (L/dia)</span>
                <input
                  type="number"
                  min={0}
                  value={Number(config.irrigation_liters_per_day || 0)}
                  onChange={(e) => updateConfig("irrigation_liters_per_day", Number(e.target.value))}
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {activeTab === "fixtures" && (
        <div className="fixtures-section">
          <div className="section-heading">
            <div>
              <h3>Dimensionamento por Pontos de Consumo & Aparelhos</h3>
              <p>Discrimine bacias sanitárias, lavanderia, rega de jardins e lavagem de pisos para cálculo automático.</p>
            </div>
          </div>

          <div className="fixtures-grid">
            <div className="fixture-card">
              <h4>🚽 Bacias Sanitárias</h4>
              <div className="form-grid-single">
                <label className="field">
                  <span>Descargas por pessoa / dia</span>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={toiletFlushes}
                    onChange={(e) => setToiletFlushes(Number(e.target.value))}
                  />
                </label>
                <label className="field">
                  <span>Tipo de Bacia / Volume</span>
                  <select
                    value={toiletVolume}
                    onChange={(e) => setToiletVolume(Number(e.target.value))}
                  >
                    <option value={6}>Caixa Acoplada (6 Litros / descarga)</option>
                    <option value={9}>Válvula de Descarga (9 Litros / descarga)</option>
                    <option value={12}>Válvula Antiga (12 Litros / descarga)</option>
                  </select>
                </label>
                <span className="fixture-subtotal">
                  Subtotal: {(residents * toiletFlushes * toiletVolume).toFixed(0)} L/dia
                </span>
              </div>
            </div>

            <div className="fixture-card">
              <h4>🧺 Lavanderia / Máquinas</h4>
              <div className="form-grid-single">
                <label className="field">
                  <span>Ciclos de lavagem por semana</span>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={washCyclesWeekly}
                    onChange={(e) => setWashCyclesWeekly(Number(e.target.value))}
                  />
                </label>
                <label className="field">
                  <span>Consumo por ciclo (Litros)</span>
                  <input
                    type="number"
                    min={30}
                    max={300}
                    value={washVolPerCycle}
                    onChange={(e) => setWashVolPerCycle(Number(e.target.value))}
                  />
                </label>
                <span className="fixture-subtotal">
                  Subtotal: {((washCyclesWeekly * washVolPerCycle) / 7.0).toFixed(0)} L/dia
                </span>
              </div>
            </div>

            <div className="fixture-card">
              <h4>🌿 Jardim & Irrigação</h4>
              <div className="form-grid-single">
                <label className="field">
                  <span>Área de jardim / verde (m²)</span>
                  <input
                    type="number"
                    min={0}
                    value={gardenArea}
                    onChange={(e) => setGardenArea(Number(e.target.value))}
                  />
                </label>
                <label className="field">
                  <span>Taxa de rega (L/m²/dia)</span>
                  <input
                    type="number"
                    step={0.5}
                    min={0}
                    value={gardenRate}
                    onChange={(e) => setGardenRate(Number(e.target.value))}
                  />
                </label>
                <span className="fixture-subtotal">
                  Subtotal: {(gardenArea * gardenRate).toFixed(0)} L/dia
                </span>
              </div>
            </div>

            <div className="fixture-card">
              <h4>🚗 Pisos & Lavagens Externas</h4>
              <div className="form-grid-single">
                <label className="field">
                  <span>Consumo semanal para lavagens (L/sem)</span>
                  <input
                    type="number"
                    min={0}
                    value={floorWashWeekly}
                    onChange={(e) => setFloorWashWeekly(Number(e.target.value))}
                  />
                </label>
                <span className="fixture-subtotal" style={{ marginTop: 28 }}>
                  Subtotal: {(floorWashWeekly / 7.0).toFixed(0)} L/dia
                </span>
              </div>
            </div>
          </div>

          <div className="calc-sync-bar">
            <div>
              <strong>Demanda Não Potável Total Calculada:</strong>
              <div className="calc-val-large">{fixtureDailyPluvial.toFixed(0)} L/dia</div>
            </div>
            <button
              type="button"
              className="primary"
              onClick={applyFixtureCalculations}
            >
              <Check size={16} /> Aplicar Cálculo de Aparelhos ao Projeto
            </button>
          </div>
        </div>
      )}

      {/* SELETOR DE MATERIAL DE COBERTURA & COEFICIENTE DE ESCOAMENTO (C) */}
      <div className="section-card" style={{ marginTop: 20 }}>
        <h3>Material da Cobertura & Coeficiente de Escoamento (C)</h3>
        <p className="field-desc">
          Selecione o material da superfície de captação para preenchimento automático do coeficiente de runoff conforme ABNT NBR 15527.
        </p>

        <div className="roof-materials-grid">
          {ROOF_MATERIALS.map((mat) => {
            const isMatch = Math.abs(Number(config.runoff_coeff || 0.85) - mat.c) < 0.02;
            return (
              <button
                key={mat.name}
                type="button"
                className={`roof-mat-card ${isMatch ? "active" : ""}`}
                onClick={() => updateConfig("runoff_coeff", mat.c)}
              >
                <div className="roof-mat-top">
                  <strong>{mat.name}</strong>
                  <span className="c-badge">C = {mat.c.toFixed(2)}</span>
                </div>
                <span>{mat.desc}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
