import { useState, type ReactElement } from "react";
import {
  BookOpen,
  Calculator,
  Award,
  Layers,
  CloudRain,
  Building2,
  Droplets,
  FlaskConical,
  TrendingUp,
  WalletCards,
  Lightbulb,
  Receipt,
  Leaf,
  Library,
  Terminal,
  ChevronRight,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
} from "lucide-react";

interface DocTopic {
  id: string;
  icon: typeof BookOpen;
  title: string;
  category: "Métodos & Modelagem" | "Engenharia & Dimensionamento" | "Economia & Sustentabilidade" | "Referências & CLI";
  render: () => ReactElement;
}


export function DocumentationViewer() {
  const [activeTopicId, setActiveTopicId] = useState("methodology");

  const topics: DocTopic[] = [
    {
      id: "methodology",
      icon: Calculator,
      title: "1. Metodologia de Cálculo por Etapa",
      category: "Métodos & Modelagem",
      render: () => (
        <div>
          <h3>1. Metodologia do Balanço Hídrico Contínuo Diário (Algoritmo YAS)</h3>
          <p>
            O Netuno 5 implementa o algoritmo <b>Yield-After-Spillage (YAS)</b> com simulação em passo diário contínuo, em total conformidade com a <b>ABNT NBR 15527:2019</b> (Aproveitamento de água de chuva de coberturas para fins não potáveis).
          </p>
          <div className="math-box">
            <code>V<sub>cap,t</sub> = max(0, (P<sub>t</sub> − d<sub>f</sub>) × A × C)</code>
            <p>Onde: <i>V<sub>cap,t</sub></i> é o volume captado no dia <i>t</i> (L); <i>P<sub>t</sub></i> é a precipitação diária (mm); <i>d<sub>f</sub></i> é a lâmina de descarte de primeiras águas (mm); <i>A</i> é a área de captação (m²); e <i>C</i> é o coeficiente de escoamento superficial (runoff).</p>
          </div>
          <div className="math-box">
            <code>V<sub>inf,t</sub> = min(V<sub>inf,max</sub>, V<sub>inf,t−1</sub> + V<sub>cap,t</sub> − V<sub>bomba,t</sub>)</code>
            <p>Onde: <i>V<sub>inf,t</sub></i> é o volume útil armazenado no reservatório inferior no final do dia <i>t</i> (L); <i>V<sub>bomba,t</sub></i> é o volume transferido para o reservatório superior; e o excesso gera <i>V<sub>ext,t</sub></i> (extravasamento).</p>
          </div>
          <div className="math-box">
            <code>P<sub>pot</sub> (%) = 100 × (Σ V<sub>aprov,t</sub> / Σ D<sub>total,t</sub>)</code>
            <p>Onde: <i>P<sub>pot</sub></i> é o <b>Potencial de Economia de Água Potável (%)</b> ao longo de todo o período da série simulada.</p>
          </div>
        </div>
      ),
    },
    {
      id: "topsis",
      icon: Award,
      title: "2. TOPSIS & SMAA-VIKOR (MCDA)",
      category: "Métodos & Modelagem",
      render: () => (
        <div>
          <h3>2. Tomada de Decisão Multicritério para Seleção do Reservatório Ótimo</h3>
          <p>
            Para superar o dilema entre custo de investimento (CAPEX), economia hídrica e impactos ambientais, o Netuno 5 oferece dois fluxos de decisão: TOPSIS com um perfil de pesos declarado e SMAA-VIKOR com milhares de perfis estocásticos.
          </p>
          <div className="doc-card-highlight">
            <h4>A. TOPSIS (Hwang & Yoon, 1981)</h4>
            <p>
              Calcula a proximidade relativa de cada capacidade de reservatório ao Ponto Ideal Positivo (<i>A⁺</i>) e ao Ponto Anti-Ideal Negativo (<i>A⁻</i>), utilizando distância euclidiana normalizada.
            </p>
          </div>
          <div className="doc-card-highlight">
            <h4>B. VIKOR — motor de compromisso do SMAA (Opricovic & Tzeng, 2004)</h4>
            <p>
              Determina uma solução de compromisso calculando a medida de utilidade coletiva da maioria (<i>S<sub>i</sub></i>) e o arrependimento individual máximo (<i>R<sub>i</sub></i>). O índice final <i>Q<sub>i</sub></i> pondera ambas as grandezas pelo parâmetro de consenso <i>v</i> (padrão <i>v = 0,5</i>).
            </p>
          </div>
          <div className="doc-card-highlight">
            <h4>C. SMAA-VIKOR (Lahdelma & Salminen, 2001; crispyn)</h4>
            <p>
              Abordagem estocástica que elimina a necessidade de um perfil único de pesos. Em cada simulação, amostra um vetor no <i>simplex</i> Dirichlet e executa um novo ranking VIKOR para fornecer:
            </p>
            <ul>
              <li><b>Índice de Aceitabilidade de 1º Lugar (b<sub>i</sub>¹):</b> Probabilidade estatística (%) do reservatório <i>i</i> ser o melhor rankeado sob quaisquer preferências aleatórias.</li>
              <li><b>Vetor Central de Pesos (w<sub>i</sub>ᶜ):</b> O perfil de preferências típico que justifica a escolha do reservatório.</li>
              <li><b>Fator de Confiança (p<sub>i</sub>ᶜ):</b> Robustez da recomendação quando os pesos reais estão próximos do vetor central.</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      id: "roofs",
      icon: Layers,
      title: "3. Coeficientes de Telhados (Runoff)",
      category: "Engenharia & Dimensionamento",
      render: () => (
        <div>
          <h3>3. Coeficientes de Escoamento Superficial (C) e Descarte Recomendado</h3>
          <p>
            O coeficiente de escoamento superficial (<i>Runoff C</i>) representa a fração de chuva convertida em volume afluente após perdas por molhamento, evaporação e retenção em depressões:
          </p>
          <table className="doc-table">
            <thead>
              <tr>
                <th>Tipo de Material da Cobertura</th>
                <th>Coeficiente C Típico</th>
                <th>Descarte Inicial Mínimo (mm)</th>
                <th>Observações Técnicas</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Telha Cerâmica Esmaltada / Vitrificada</b></td>
                <td>0,85 – 0,90</td>
                <td>1,0 – 1,5 mm</td>
                <td>Excelente qualidade bacteriológica; baixa retenção.</td>
              </tr>
              <tr>
                <td><b>Telha Cerâmica Porosa Natural</b></td>
                <td>0,75 – 0,82</td>
                <td>1,5 – 2,0 mm</td>
                <td>Maior absorção inicial e acúmulo de poeira.</td>
              </tr>
              <tr>
                <td><b>Chapas Metálicas (Aluzinco / Galvanizada)</b></td>
                <td>0,90 – 0,95</td>
                <td>1,0 mm</td>
                <td>Superfície lisa com alto rendimento e rápida lavagem.</td>
              </tr>
              <tr>
                <td><b>Laje Plana de Concreto Impermeabilizada</b></td>
                <td>0,80 – 0,85</td>
                <td>1,5 – 2,0 mm</td>
                <td>Atenção à declividade mínima para evitar empoçamento.</td>
              </tr>
              <tr>
                <td><b>Telhado Verde Intensivo / Extensivo</b></td>
                <td>0,40 – 0,60</td>
                <td>2,0 mm</td>
                <td>Alta retenção de água e liberação gradual de matéria orgânica.</td>
              </tr>
            </tbody>
          </table>
        </div>
      ),
    },
    {
      id: "indices",
      icon: CloudRain,
      title: "4. 9 Índices Pluviométricos (ETCCDI)",
      category: "Métodos & Modelagem",
      render: () => (
        <div>
          <h3>4. Índices de Extremos Climáticos Pluviométricos (ETCCDI)</h3>
          <p>
            O Netuno 5 processa automaticamente 9 indicadores climáticos internacionais definidos pelo <i>Expert Team on Climate Change Detection and Indices</i> (WMO/CLIVAR):
          </p>
          <ul className="doc-list">
            <li><b>PRCPTOT (mm/ano):</b> Precipitação anual total acumulada em dias úmidos (P ≥ 1 mm).</li>
            <li><b>R95p (mm/ano):</b> Precipitação acumulada em dias extremamente chuvosos (&gt; percentil 95 histórico).</li>
            <li><b>Rx1day (mm):</b> Precipitação máxima acumulada em 1 único dia (evento extremo).</li>
            <li><b>Rx5day (mm):</b> Precipitação máxima acumulada em 5 dias consecutivos (risco de saturação).</li>
            <li><b>SDII (mm/dia):</b> Índice de Intensidade Diária Simples (PRCPTOT / dias úmidos).</li>
            <li><b>R20mm (dias/ano):</b> Número de dias no ano com precipitação forte (P ≥ 20 mm).</li>
            <li><b>CDD (dias):</b> Duração máxima do período seco consecutivo (dias com P &lt; 1 mm).</li>
            <li><b>CWD (dias):</b> Duração máxima do período chuvoso consecutivo (dias com P ≥ 1 mm).</li>
            <li><b>Sazonalidade (%):</b> Variação sazonal relativa entre os trimestres mais úmido e mais seco.</li>
          </ul>
        </div>
      ),
    },
    {
      id: "climate_db",
      icon: CloudRain,
      title: "5. Base Climatológica Nacional (CMIP6 / 652 Cidades)",
      category: "Métodos & Modelagem",
      render: () => (
        <div>
          <h3>5. Base de Dados Climatológicos de 652 Municípios Brasileiros</h3>
          <p>
            A base nacional de séries temporais do Netuno 5 contempla <b>86.716 séries diárias</b>, cobrindo todos os municípios brasileiros com mais de 50.000 habitantes em 19 Modelos de Circulação Global (GCMs) do consórcio CMIP6:
          </p>
          <div className="doc-card-highlight">
            <h4>Cenários Climáticos e Horizontes de Projeção</h4>
            <ul>
              <li><b>Histórico de Referência (1980–2014):</b> 34 anos de registros diários observados e corrigidos para validação de projetos existentes.</li>
              <li><b>SSP2-4.5 (Cenário Intermediário / Otimista 2015–2100):</b> Trajetória de emissões estabilizadas com investimentos globais em sustentabilidade.</li>
              <li><b>SSP5-8.5 (Cenário Extremo / Pessimista 2015–2100):</b> Trajetória de altas emissões e aumento severo na frequência de secas e cheias.</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      id: "building",
      icon: Building2,
      title: "6. Edificação & Modulação de Demanda",
      category: "Engenharia & Dimensionamento",
      render: () => (
        <div>
          <h3>6. Tipologias Prediais e Modulação da Demanda Diária</h3>
          <p>
            A demanda diária de água pode ser calculada por per capita fixo ou estimada através da calculadora paramétrica de tipologias prediais:
          </p>
          <table className="doc-table">
            <thead>
              <tr>
                <th>Tipologia Predial</th>
                <th>Consumo Per Capita Recomendado</th>
                <th>Fração Típica Não Potável (%)</th>
                <th>Usos Pluviais Principais</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Residencial Unifamiliar / Multifamiliar</b></td>
                <td>120 a 180 L/hab.dia</td>
                <td>30% a 45%</td>
                <td>Bacias sanitárias, lavagem de roupas, irrigação e pisos.</td>
              </tr>
              <tr>
                <td><b>Edifícios Comerciais / Escritórios</b></td>
                <td>40 a 60 L/pessoa.dia</td>
                <td>50% a 70%</td>
                <td>Descargas de vasos/mictórios, torres de resfriamento e limpeza.</td>
              </tr>
              <tr>
                <td><b>Escolas e Universidades</b></td>
                <td>30 a 50 L/aluno.dia</td>
                <td>40% a 60%</td>
                <td>Bacias sanitárias, limpeza de quadras e rega de áreas verdes.</td>
              </tr>
              <tr>
                <td><b>Hotéis e Pousadas</b></td>
                <td>200 a 350 L/hóspede.dia</td>
                <td>35% a 50%</td>
                <td>Descargas sanitárias, lavanderia e jardins.</td>
              </tr>
            </tbody>
          </table>
        </div>
      ),
    },
    {
      id: "quality_etap",
      icon: FlaskConical,
      title: "7. Qualidade da Água, ETAP & Dosagem de Cloro",
      category: "Engenharia & Dimensionamento",
      render: () => (
        <div>
          <h3>7. Qualidade da Água, Descarte Inicial e Estação de Tratamento (ETAP)</h3>
          <p>
            A modelagem de remoção de poluentes por descarte inicial fundamenta-se nos trabalhos seminais de <b>Yaziz et al. (1989)</b> e <b>Martinson & Thomas (2005)</b>, e no artigo científico de referência do grupo: <b>Maykot, Vaz & Ghisi (2025)</b> (<i>Water</i>, 17(12), 1772, DOI: 10.3390/w17121772).
          </p>
          <div className="math-box">
            <code>E(d) = 100% × ( 1 − e<sup>−k · d</sup> )</code>
            <p>Onde <i>E(d)</i> é a eficiência de retenção de impurezas acumuladas e <i>d</i> é a lâmina descartada (mm).</p>
          </div>
          <div className="doc-card-highlight">
            <h4>Memória de Cálculo Estequiométrica da Dosagem de Cloro (ABNT NBR 15527:2019/2024)</h4>
            <p>
              Para desinfecção contínua com pastilhas de hipoclorito de cálcio comercial [Ca(ClO)₂ com 65% de Cl₂ ativo]:
            </p>
            <div className="math-box">
              <code>Massa Cl₂ (kg/ano) = [ V<sub>aprov</sub> (m³/ano) × Dosagem (mg/L) ] / 1.000</code><br />
              <code>Massa Pastilhas 65% (kg/ano) = Massa Cl₂ / 0,65</code><br />
              <code>Custo Químico Anual (R$/ano) = Massa Pastilhas × R$ 38,00/kg</code>
            </div>
            <p><b>Faixa de Conformidade Normativa:</b> Cloro Residual Livre entre <b>0,5 mg/L e 2,0 mg/L</b> após 30 min de tempo de contato.</p>
          </div>
        </div>
      ),
    },
    {
      id: "tanks_pumps",
      icon: Droplets,
      title: "8. Reservatórios & Dimensionamento de Bombeamento",
      category: "Engenharia & Dimensionamento",
      render: () => (
        <div>
          <h3>8. Dimensionamento Hidráulico e Elétrico de Motobombas</h3>
          <p>
            O consumo de energia elétrica para elevação da água pluvial do reservatório inferior para o superior é dimensionado com base na equação clássica da potência hidráulica:
          </p>
          <div className="math-box">
            <code>P<sub>bomba</sub> (kW) = (γ × Q × H<sub>man</sub>) / (102 × η<sub>global</sub>)</code>
            <p>Onde: <i>γ</i> é o peso específico da água (1.000 kgf/m³); <i>Q</i> é a vazão de recalque (m³/s); <i>H<sub>man</sub></i> é a altura manométrica total (m); e <i>η<sub>global</sub></i> é o rendimento combinado motor-bomba (típico 50% a 65%).</p>
          </div>
          <div className="math-box">
            <code>E<sub>anual</sub> (kWh/ano) = P<sub>bomba</sub> (kW) × Horas de Operação Anual (h/ano)</code>
          </div>
        </div>
      ),
    },
    {
      id: "economics",
      icon: WalletCards,
      title: "9. Análise Econômico-Financeira (VPL, TIR, Payback & LCOW)",
      category: "Economia & Sustentabilidade",
      render: () => (
        <div>
          <h3>9. Métricas de Viabilidade Econômico-Financeira (FCD em 20 Anos)</h3>
          <p>
            A avaliação financeira adota a metodologia do <b>Fluxo de Caixa Descontado (FCD)</b> com as seguintes formulações canônicas:
          </p>
          <div className="math-box">
            <code>VPL (R$) = −CAPEX + Σ [ FC<sub>t</sub> / (1 + TMA)<sup>t</sup> ]</code>
            <p>Onde <i>FC<sub>t</sub></i> é a economia líquida anual (Economia de Água + Esgoto − OPEX Químico − Energia Elétrica).</p>
          </div>
          <div className="math-box">
            <code>LCOW (R$/m³) = [ CAPEX + Σ (OPEX<sub>t</sub> / (1 + TMA)<sup>t</sup>) ] / [ Σ (V<sub>aprov,t</sub> / (1 + TMA)<sup>t</sup>) ]</code>
            <p>Representa o custo nivelado por metro cúbico de água da chuva tratada e entregue no ponto de consumo.</p>
          </div>
        </div>
      ),
    },
    {
      id: "acv_lca",
      icon: Leaf,
      title: "10. Análise do Ciclo de Vida (ACV) & Fatores de Emissão",
      category: "Economia & Sustentabilidade",
      render: () => (
        <div>
          <h3>10. Fatores de Emissão de Carbono Incorporado e Operacional (ISO 14040/14044)</h3>
          <p>
            Os fatores de emissão berço-ao-portão foram extraídos do banco de dados <b>Ecoinvent v3.8</b> adaptados à matriz elétrica brasileira (SIN):
          </p>
          <table className="doc-table">
            <thead>
              <tr>
                <th>Componente do Sistema</th>
                <th>Fator de Emissão de Carbono</th>
                <th>Fonte e Justificativa Técnica</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Reservatório em Polietileno (PEAD)</b></td>
                <td>2,10 kg CO₂e / kg polímero</td>
                <td>Rotomoldagem de resina virgem PEAD (Ecoinvent).</td>
              </tr>
              <tr>
                <td><b>Reservatório em Concreto Armado</b></td>
                <td>0,18 kg CO₂e / kg concreto</td>
                <td>Concreto usinado fck 25 MPa + aço CA-50 (100 kg/m³).</td>
              </tr>
              <tr>
                <td><b>Reservatório em Fibra de Vidro (PRFV)</b></td>
                <td>3,20 kg CO₂e / kg compósito</td>
                <td>Resina poliéster insaturada + tecido roving de vidro.</td>
              </tr>
              <tr>
                <td><b>Tubulações e Conexões em PVC Rígido</b></td>
                <td>2,70 kg CO₂e / kg PVC</td>
                <td>Extrusão de tubos de PVC predial.</td>
              </tr>
              <tr>
                <td><b>Motobomba Centrífuga</b></td>
                <td>6,50 kg CO₂e / kg equipamento</td>
                <td>Fundição de ferro/alumínio + bobinagem de cobre.</td>
              </tr>
              <tr>
                <td><b>Tratamento da Água da Rede Pública</b></td>
                <td>0,35 kg CO₂e / m³ água</td>
                <td>Captação, coagulação, cloração e bombeamento da concessionária.</td>
              </tr>
            </tbody>
          </table>
        </div>
      ),
    },
    {
      id: "tariffs_method",
      icon: Receipt,
      title: "11. Estruturas Tarifárias das 652 Cidades",
      category: "Economia & Sustentabilidade",
      render: () => (
        <div>
          <h3>11. Governança e Metodologia do Banco Tarifário das 652 Cidades</h3>
          <p>
            O catálogo tarifário foi estruturado em conformidade com as regras das agências infranacionais de saneamento e da ANEEL:
          </p>
          <ul className="doc-list">
            <li><b>Estruturas em Faixas Progressivas:</b> Cálculo exato da tarifa marginal por bloco de consumo (ex: 0–10 m³, 11–15 m³, 16–20 m³, &gt;20 m³).</li>
            <li><b>Tarifa Fixa / TFDI:</b> Inclusão da Tarifa Fixa de Disponibilidade de Infraestrutura quando aplicável pela agência reguladora.</li>
            <li><b>Alíquotas Regulatórias de Esgoto:</b> Consideração da alíquota oficial (50%, 70%, 80%, 85% ou 100% sobre o valor da água).</li>
            <li><b>Tarifa Residencial B1 ANEEL:</b> Tarifas homologadas vigentes em R$/kWh para cada distribuidora de energia.</li>
          </ul>
        </div>
      ),
    },
    {
      id: "discussion",
      icon: Lightbulb,
      title: "12. Discussão: Métodos Empíricos vs Simulação Diária",
      category: "Métodos & Modelagem",
      render: () => (
        <div>
          <h3>12. Comparação entre Métodos Empíricos e Simulação Contínua</h3>
          <p>
            Métodos simplificados tradicionais (Azevedo Netto, Rippl sem restrição, Método Prático Alemão) utilizam médias mensais ou anuais que ignoram a estocasticidade da chuva diária e a dinâmica de reservação, levando frequentemente a <b>superdimensionamento severo</b> ou <b>subatendimento crônico</b>.
          </p>
          <div className="doc-card-highlight">
            <h4>Por que o Método Diário Contínuo (YAS) é Superior?</h4>
            <ul>
              <li>Registra o extravasamento diário real quando o reservatório atinge a capacidade máxima.</li>
              <li>Calcula o bombeamento exatamente nos dias em que há demanda e volume disponível.</li>
              <li>Determina com precisão o número de dias com 100% de atendimento e a curva de permanência.</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      id: "references",
      icon: Library,
      title: "13. Referências Bibliográficas Completas",
      category: "Referências & CLI",
      render: () => (
        <div>
          <h3>13. Referências Bibliográficas e Normas Técnicas</h3>
          <div className="references-box">
            <p><b>ABNT — Associação Brasileira de Normas Técnicas (2019).</b> <i>NBR 15527: Água de chuva — Aproveitamento de coberturas em áreas urbanas para fins não potáveis — Requisitos</i>. Rio de Janeiro: ABNT.</p>
            <p><b>ABNT — Associação Brasileira de Normas Técnicas (2019).</b> <i>NBR 16783: Uso de fontes alternativas de água não potável em edificações</i>. Rio de Janeiro: ABNT.</p>
            <p><b>VAZ, I. C. M.; GHISI, E. (2026).</b> <i>Netuno: Aproveitamento de água de chuva em edificações (Versão 5)</i>. Florianópolis: Universidade Federal de Santa Catarina.</p>
            <p><b>HWANG, C. L.; YOON, K. (1981).</b> <i>Multiple Attribute Decision Making: Methods and Applications</i>. New York: Springer-Verlag.</p>
            <p><b>LAHDELMA, R.; SALMINEN, P. (2001).</b> SMAA-2: Stochastic Multicriteria Acceptability Analysis for Group Decision Making. <i>Operations Research</i>, v. 49, n. 3, p. 444-454.</p>
            <p><b>MARTINSON, D. B.; THOMAS, T. (2005).</b> Quantifying the first-flush phenomenon. In: <i>12th International Rainwater Catchment Systems Conference</i>, New Delhi, India.</p>
            <p><b>MAYKOT, J. K.; VAZ, I. C. M.; GHISI, E. (2025).</b> Characterisation of First Flush for Rainwater Harvesting Purposes in Buildings. <i>Water</i>, v. 17, n. 12, art. 1772. DOI: <a href="https://doi.org/10.3390/w17121772" target="_blank" rel="noreferrer">10.3390/w17121772</a>.</p>
            <p><b>OPRICOVIC, S.; TZENG, G. H. (2004).</b> Compromise solution by MCDM methods: A comparative analysis of VIKOR and TOPSIS. <i>European Journal of Operational Research</i>, v. 156, n. 2, p. 445-455.</p>
            <p><b>YAZIZ, M. I.; GANTING, H.; MOHAMAD, N.; GHAFFAR, A. W. (1989).</b> Variations in rainwater quality from roof catchments. <i>Water Research</i>, v. 23, n. 6, p. 761-765.</p>
          </div>
        </div>
      ),
    },
    {
      id: "cli",
      icon: Terminal,
      title: "14. Uso pela Linha de Comando (CLI)",
      category: "Referências & CLI",
      render: () => (
        <div>
          <h3>14. Execução e Automação pela Linha de Comando</h3>
          <p>
            O Netuno 5 dispõe de scripts para automação de simulações em massa, auditoria de tarifas e testes:
          </p>
          <div className="cli-snippet">
            <code># Iniciar Servidor Web Local e API</code>
            <pre>$env:NETUNO_ALLOW_INLINE="true"<br />python -m uvicorn netuno_web.backend.main:app --port 8000</pre>
          </div>
          <div className="cli-snippet">
            <code># Atualização Completa de Tarifas e Geração de Dashboard HTML</code>
            <pre>python tarifas/atualizar_tarifas.py</pre>
          </div>
          <div className="cli-snippet">
            <code># Execução da Suíte de Testes Automatizados</code>
            <pre>python -m pytest tests/ netuno_web/tests/</pre>
          </div>
        </div>
      ),
    },
  ];

  const categories = Array.from(new Set(topics.map((t) => t.category)));
  const currentTopic = topics.find((t) => t.id === activeTopicId) || topics[0];

  return (
    <div className="doc-viewer-container">
      <div className="doc-sidebar">
        <div className="doc-sidebar-header">
          <BookOpen size={18} />
          <strong>Índice de Tópicos</strong>
        </div>
        <nav className="doc-topics-nav">
          {categories.map((cat) => (
            <div key={cat} className="doc-category-group">
              <span className="doc-category-label">{cat}</span>
              {topics
                .filter((t) => t.category === cat)
                .map((topic) => {
                  const Icon = topic.icon;
                  const isActive = topic.id === activeTopicId;
                  return (
                    <button
                      key={topic.id}
                      className={`doc-topic-btn ${isActive ? "active" : ""}`}
                      onClick={() => setActiveTopicId(topic.id)}
                    >
                      <Icon size={16} />
                      <span>{topic.title}</span>
                      <ChevronRight size={14} className="chevron" />
                    </button>
                  );
                })}
            </div>
          ))}
        </nav>
      </div>

      <div className="doc-content-area">
        <div className="doc-content-header">
          <span className="doc-breadcrumb">Documentação Técnica &bull; {currentTopic.category}</span>
          <h2>{currentTopic.title}</h2>
        </div>
        <div className="doc-body-content">{currentTopic.render()}</div>
      </div>
    </div>
  );
}
