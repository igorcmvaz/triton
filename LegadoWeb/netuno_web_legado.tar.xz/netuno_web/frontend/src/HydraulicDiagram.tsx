import React, { useState } from "react";
import {
  Droplets,
  Zap,
  ArrowRight,
  Info,
  Waves,
  Sparkles,
  Layers,
} from "lucide-react";

interface HydraulicDiagramProps {
  area: number;
  runoffCoeff: number;
  discardMm: number;
  lowerVolL: number;
  upperVolL: number;
  upperUsed: boolean;
  pumpingThresholdL: number;
  pumpPowerKw: number;
  pumpEfficiency: number;
  potableSavingsPct?: number;
  dailyPluvialDemandL: number;
  annualRainwaterM3?: number;
  annualOverflowM3?: number;
}

export const HydraulicDiagram: React.FC<HydraulicDiagramProps> = ({
  area,
  runoffCoeff,
  discardMm,
  lowerVolL,
  upperVolL,
  upperUsed,
  pumpingThresholdL,
  pumpPowerKw,
  pumpEfficiency,
  potableSavingsPct = 0,
  dailyPluvialDemandL,
  annualRainwaterM3 = 0,
  annualOverflowM3 = 0,
}) => {
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);
  const [isFlowAnimated, setIsFlowAnimated] = useState(true);

  // Water level percentage for rendering
  const lowerWaterPct = Math.min(85, Math.max(25, (lowerVolL > 0 ? 68 : 10)));
  const upperWaterPct = upperUsed ? Math.min(85, Math.max(30, 72)) : 0;

  return (
    <div className="hydraulic-diagram-card">
      <div className="diagram-header">
        <div className="diagram-title-wrap">
          <div className="diagram-badge">
            <Waves size={16} />
            <span>Esquema Hidráulico 2D Interativo</span>
          </div>
          <span className="diagram-subtitle">
            Balanço dinâmico de captação, descarte, armazenamento e distribuição predial (NBR 15527)
          </span>
        </div>

        <div className="diagram-actions">
          <button
            type="button"
            className={`diagram-btn ${isFlowAnimated ? "active" : ""}`}
            onClick={() => setIsFlowAnimated(!isFlowAnimated)}
          >
            <Sparkles size={14} />
            {isFlowAnimated ? "Fluxo Animado" : "Pausar Animação"}
          </button>
          <div className="economy-pill">
            <span>Economia de Água:</span>
            <strong>{potableSavingsPct.toFixed(1)}%</strong>
          </div>
        </div>
      </div>

      <div className="diagram-viewport">
        <svg
          viewBox="0 0 980 430"
          className={`diagram-svg ${isFlowAnimated ? "animated" : ""}`}
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            {/* Gradients */}
            <linearGradient id="roofGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0284c7" stopOpacity="0.85" />
              <stop offset="100%" stopColor="#0369a1" stopOpacity="0.95" />
            </linearGradient>

            <linearGradient id="waterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#0284c7" />
            </linearGradient>

            <linearGradient id="upperWaterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#7dd3fc" />
              <stop offset="100%" stopColor="#0ea5e9" />
            </linearGradient>

            <linearGradient id="tankBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#f8fafc" />
              <stop offset="100%" stopColor="#f1f5f9" />
            </linearGradient>

            <filter id="shadowFilter" x="-5%" y="-5%" width="110%" height="110%">
              <feDropShadow dx="0" dy="3" stdDeviation="4" floodColor="#0f172a" floodOpacity="0.08" />
            </filter>

            {/* Flow line animation marker */}
            <marker
              id="arrow"
              viewBox="0 0 10 10"
              refX="6"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 8 5 L 0 9 z" fill="#0284c7" />
            </marker>

            <marker
              id="greenArrow"
              viewBox="0 0 10 10"
              refX="6"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 8 5 L 0 9 z" fill="#10b981" />
            </marker>

            <marker
              id="orangeArrow"
              viewBox="0 0 10 10"
              refX="6"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 8 5 L 0 9 z" fill="#f59e0b" />
            </marker>
          </defs>

          {/* 1. TELHADO & CHUVA */}
          <g
            className="diagram-group"
            onMouseEnter={() => setActiveTooltip("roof")}
            onMouseLeave={() => setActiveTooltip(null)}
          >
            {/* Gotas de Chuva */}
            <g className="rain-drops">
              {[30, 60, 90, 120, 150].map((x, i) => (
                <line
                  key={i}
                  x1={35 + x}
                  y1={25}
                  x2={30 + x}
                  y2={50}
                  stroke="#38bdf8"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                  className="rain-line"
                />
              ))}
            </g>

            {/* Telhado Triângulo */}
            <polygon
              points="40,85 145,35 250,85"
              fill="url(#roofGrad)"
              stroke="#075985"
              strokeWidth="2"
              filter="url(#shadowFilter)"
            />
            {/* Beiral */}
            <rect x="35" y="83" width="220" height="7" rx="3" fill="#0369a1" />

            <text x="145" y="65" textAnchor="middle" fill="#ffffff" fontWeight="700" fontSize="12">
              Telhado / Captação
            </text>
            <text x="145" y="80" textAnchor="middle" fill="#e0f2fe" fontSize="10">
              {area} m² · C = {runoffCoeff}
            </text>
          </g>

          {/* Calha */}
          <path
            d="M 245 88 L 275 88 L 275 125"
            fill="none"
            stroke="#0284c7"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* 2. DISPOSITIVO DE DESCARTE (FIRST FLUSH) */}
          <g
            className="diagram-group"
            onMouseEnter={() => setActiveTooltip("firstFlush")}
            onMouseLeave={() => setActiveTooltip(null)}
          >
            {/* Filtro autolimpante / Grade */}
            <rect
              x="257"
              y="125"
              width="36"
              height="45"
              rx="6"
              fill="#fff7ed"
              stroke="#ea580c"
              strokeWidth="2"
              filter="url(#shadowFilter)"
            />
            <line x1="262" y1="135" x2="288" y2="135" stroke="#f97316" strokeWidth="1.5" />
            <line x1="262" y1="145" x2="288" y2="145" stroke="#f97316" strokeWidth="1.5" />
            <line x1="262" y1="155" x2="288" y2="155" stroke="#f97316" strokeWidth="1.5" />

            <text x="275" y="118" textAnchor="middle" fill="#9a3412" fontWeight="700" fontSize="10">
              First Flush
            </text>
            <text x="310" y="145" textAnchor="start" fill="#c2410c" fontSize="10" fontWeight="600">
              Descarte: {discardMm} mm
            </text>

            {/* Dreno de descarte inicial */}
            <path
              d="M 275 170 L 275 200 L 250 200"
              fill="none"
              stroke="#f97316"
              strokeWidth="2.5"
              strokeDasharray="4 3"
              markerEnd="url(#orangeArrow)"
            />
            <text x="245" y="215" textAnchor="end" fill="#c2410c" fontSize="9">
              Purga / Galeria Pluvial
            </text>
          </g>

          {/* Tubo de Entrada na Cisterna */}
          <path
            d="M 293 145 L 345 145 L 345 260"
            fill="none"
            stroke="#0284c7"
            strokeWidth="3.5"
            strokeLinecap="round"
            className="flow-path"
          />

          {/* 3. RESERVATÓRIO INFERIOR (CISTERNA) */}
          <g
            className="diagram-group"
            onMouseEnter={() => setActiveTooltip("lowerTank")}
            onMouseLeave={() => setActiveTooltip(null)}
          >
            <rect
              x="300"
              y="260"
              width="190"
              height="130"
              rx="10"
              fill="url(#tankBodyGrad)"
              stroke="#0284c7"
              strokeWidth="2.5"
              filter="url(#shadowFilter)"
            />

            {/* Nível de Água Inferior */}
            <clipPath id="lowerTankClip">
              <rect x="303" y="263" width="184" height="124" rx="8" />
            </clipPath>
            <rect
              x="303"
              y={263 + 124 * (1 - lowerWaterPct / 100)}
              width="184"
              height={124 * (lowerWaterPct / 100)}
              fill="url(#waterGrad)"
              opacity="0.88"
              clipPath="url(#lowerTankClip)"
            />

            {/* Linha de onda de água */}
            <path
              d={`M 303 ${263 + 124 * (1 - lowerWaterPct / 100)} Q 345 ${259 + 124 * (1 - lowerWaterPct / 100)}, 395 ${263 + 124 * (1 - lowerWaterPct / 100)} T 487 ${263 + 124 * (1 - lowerWaterPct / 100)}`}
              fill="none"
              stroke="#e0f2fe"
              strokeWidth="2"
              opacity="0.6"
              clipPath="url(#lowerTankClip)"
            />

            <text x="395" y="295" textAnchor="middle" fill="#0f172a" fontWeight="800" fontSize="13">
              Cisterna Inferior
            </text>
            <text x="395" y="318" textAnchor="middle" fill="#0284c7" fontWeight="800" fontSize="16">
              {lowerVolL.toLocaleString("pt-BR")} L
            </text>
            <text x="395" y="340" textAnchor="middle" fill="#0369a1" fontSize="11" fontWeight="600">
              Nível útil ~{lowerWaterPct}%
            </text>

            {/* Extravasor / Ladrão */}
            <path
              d="M 490 280 L 530 280 L 530 360"
              fill="none"
              stroke="#f59e0b"
              strokeWidth="2.5"
              strokeDasharray="4 3"
              markerEnd="url(#orangeArrow)"
            />
            <text x="535" y="375" textAnchor="start" fill="#b45309" fontSize="9" fontWeight="600">
              Extravasor: {annualOverflowM3.toFixed(1)} m³/ano
            </text>
          </g>

          {/* 4. MOTOBOMBA E RECALQUE OU USO DIRETO */}
          {upperUsed ? (
            <>
              {/* Sucção da bomba */}
              <path
                d="M 430 380 L 545 380 L 545 325"
                fill="none"
                stroke="#10b981"
                strokeWidth="3.5"
                strokeLinecap="round"
              />

              <g
                className="diagram-group"
                onMouseEnter={() => setActiveTooltip("pump")}
                onMouseLeave={() => setActiveTooltip(null)}
              >
                {/* Corpo da Motobomba */}
                <circle
                  cx="545"
                  cy="305"
                  r="24"
                  fill="#ecfdf5"
                  stroke="#059669"
                  strokeWidth="2.5"
                  filter="url(#shadowFilter)"
                />
                <circle cx="545" cy="305" r="16" fill="#10b981" />
                <path d="M 545 295 L 553 305 L 545 315 L 537 305 Z" fill="#ffffff" />

                <text x="545" y="345" textAnchor="middle" fill="#065f46" fontWeight="700" fontSize="11">
                  Motobomba Recalque
                </text>
                <text x="545" y="360" textAnchor="middle" fill="#047857" fontSize="9.5">
                  {pumpPowerKw} kW · {pumpEfficiency}% rend.
                </text>
              </g>

              {/* Tubo de Recalque para o Reservatório Superior */}
              <path
                d="M 545 281 L 545 105 L 650 105"
                fill="none"
                stroke="#10b981"
                strokeWidth="3.5"
                strokeLinecap="round"
                className="flow-path-green"
              />

              {/* 5. RESERVATÓRIO SUPERIOR */}
              <g
                className="diagram-group"
                onMouseEnter={() => setActiveTooltip("upperTank")}
                onMouseLeave={() => setActiveTooltip(null)}
              >
                <rect
                  x="650"
                  y="55"
                  width="155"
                  height="100"
                  rx="8"
                  fill="url(#tankBodyGrad)"
                  stroke="#0284c7"
                  strokeWidth="2"
                  filter="url(#shadowFilter)"
                />

                <clipPath id="upperTankClip">
                  <rect x="653" y="58" width="149" height="94" rx="6" />
                </clipPath>
                <rect
                  x="653"
                  y={58 + 94 * (1 - upperWaterPct / 100)}
                  width="149"
                  height={94 * (upperWaterPct / 100)}
                  fill="url(#upperWaterGrad)"
                  opacity="0.9"
                  clipPath="url(#upperTankClip)"
                />

                <text x="727" y="85" textAnchor="middle" fill="#0f172a" fontWeight="700" fontSize="12">
                  Res. Superior
                </text>
                <text x="727" y="105" textAnchor="middle" fill="#0284c7" fontWeight="800" fontSize="14">
                  {upperVolL.toLocaleString("pt-BR")} L
                </text>
                <text x="727" y="122" textAnchor="middle" fill="#0369a1" fontSize="9.5">
                  Limiar recalque: {pumpingThresholdL} L
                </text>

                {/* Alimentação de backup da rede pública */}
                <path
                  d="M 727 20 L 727 55"
                  fill="none"
                  stroke="#64748b"
                  strokeWidth="2"
                  strokeDasharray="3 3"
                  markerEnd="url(#arrow)"
                />
                <text x="733" y="35" textAnchor="start" fill="#475569" fontSize="8.5" fontWeight="600">
                  Backup Rede Pública (By-pass)
                </text>
              </g>

              {/* Tubulação por Gravidade para Pontos de Consumo */}
              <path
                d="M 760 155 L 760 260 L 840 260"
                fill="none"
                stroke="#0284c7"
                strokeWidth="3.5"
                strokeLinecap="round"
                className="flow-path"
              />
            </>
          ) : (
            // USO DIRETO SEM RESERVATÓRIO SUPERIOR
            <>
              <path
                d="M 490 325 L 840 325"
                fill="none"
                stroke="#0284c7"
                strokeWidth="4"
                strokeLinecap="round"
                className="flow-path"
              />
              <text x="665" y="315" textAnchor="middle" fill="#0284c7" fontSize="11" fontWeight="700">
                Alimentação Direta por Pressurização / Gravidade
              </text>
            </>
          )}

          {/* 6. PONTOS DE CONSUMO NÃO POTÁVEL */}
          <g
            className="diagram-group"
            onMouseEnter={() => setActiveTooltip("fixtures")}
            onMouseLeave={() => setActiveTooltip(null)}
          >
            <rect
              x="840"
              y="225"
              width="125"
              height="165"
              rx="10"
              fill="#f0fdf4"
              stroke="#10b981"
              strokeWidth="2"
              filter="url(#shadowFilter)"
            />

            <text x="902" y="250" textAnchor="middle" fill="#065f46" fontWeight="800" fontSize="12">
              Usos Pluviais
            </text>
            <text x="902" y="270" textAnchor="middle" fill="#059669" fontWeight="800" fontSize="14">
              {dailyPluvialDemandL.toFixed(0)} L/dia
            </text>

            <line x1="850" y1="280" x2="955" y2="280" stroke="#bbf7d0" strokeWidth="1" />

            {/* Ícones de Aparelhos */}
            <g transform="translate(850, 290)">
              <text x="0" y="12" fill="#15803d" fontSize="10.5">🚽 Bacias Sanitárias</text>
              <text x="0" y="32" fill="#15803d" fontSize="10.5">🧺 Máq. Lavar Roupas</text>
              <text x="0" y="52" fill="#15803d" fontSize="10.5">🌿 Rega de Jardim</text>
              <text x="0" y="72" fill="#15803d" fontSize="10.5">🚗 Lavagem de Pisos</text>
            </g>
          </g>
        </svg>

        {/* Tooltip Overlay Informativo */}
        {activeTooltip && (
          <div className="diagram-tooltip-box">
            {activeTooltip === "roof" && (
              <div>
                <strong>Captação no Telhado</strong>
                <p>Área: {area} m² | Coeficiente de Escoamento (C): {runoffCoeff}</p>
                <span>Volume médio afluente antes do descarte inicial.</span>
              </div>
            )}
            {activeTooltip === "firstFlush" && (
              <div>
                <strong>Descarte Inicial (First Flush) & Gradeamento</strong>
                <p>Lâmina descartada: {discardMm} mm</p>
                <span>Remove poeira, folhas e sedimentos da primeira lavagem do telhado.</span>
              </div>
            )}
            {activeTooltip === "lowerTank" && (
              <div>
                <strong>Cisterna / Reservatório Inferior</strong>
                <p>Capacidade: {lowerVolL.toLocaleString("pt-BR")} Litros</p>
                <span>Armazena a água de chuva tratada para abastecer o sistema predial.</span>
              </div>
            )}
            {activeTooltip === "pump" && (
              <div>
                <strong>Conjunto Elevatório (Motobomba)</strong>
                <p>Potência: {pumpPowerKw} kW | Rendimento: {pumpEfficiency}%</p>
                <span>Recalca a água pluvial para o reservatório superior conforme demanda.</span>
              </div>
            )}
            {activeTooltip === "upperTank" && (
              <div>
                <strong>Reservatório Superior</strong>
                <p>Capacidade: {upperVolL.toLocaleString("pt-BR")} L | Limiar: {pumpingThresholdL} L</p>
                <span>Distribui por gravidade aos pontos de uso com alimentação de backup.</span>
              </div>
            )}
            {activeTooltip === "fixtures" && (
              <div>
                <strong>Pontos de Uso Não Potável</strong>
                <p>Demanda pluvial: {dailyPluvialDemandL.toFixed(0)} L/dia ({annualRainwaterM3.toFixed(1)} m³/ano)</p>
                <span>Substituição direta de água tratada da concessionária por água de chuva.</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="diagram-legend-bar">
        <div className="legend-item">
          <span className="dot blue" />
          <span>Água Pluvial Coletada</span>
        </div>
        <div className="legend-item">
          <span className="dot green" />
          <span>Recalque / Distribuição</span>
        </div>
        <div className="legend-item">
          <span className="dot orange" />
          <span>Descarte & Extravasamento</span>
        </div>
        <div className="legend-item">
          <span className="dot gray" />
          <span>Backup Rede Concessionária</span>
        </div>
      </div>
    </div>
  );
};
