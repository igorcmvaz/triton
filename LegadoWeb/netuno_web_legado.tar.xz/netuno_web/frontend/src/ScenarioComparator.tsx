import React, { useState } from "react";
import {
  Layers,
  Plus,
  Trash2,
  BarChart3,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Leaf,
  ShieldCheck,
  FileSpreadsheet,
  Download,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import type { ScenarioRecord, AnalysisResult, Config } from "./types";

interface ScenarioComparatorProps {
  currentResult: AnalysisResult | null;
  currentConfig: Config;
  currentRainName: string;
}

export const ScenarioComparator: React.FC<ScenarioComparatorProps> = ({
  currentResult,
  currentConfig,
  currentRainName,
}) => {
  const [scenarios, setScenarios] = useState<ScenarioRecord[]>(() => {
    try {
      const saved = localStorage.getItem("netuno-web-scenarios");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [newScenarioName, setNewScenarioName] = useState("");

  const saveScenariosToStorage = (list: ScenarioRecord[]) => {
    setScenarios(list);
    localStorage.setItem("netuno-web-scenarios", JSON.stringify(list));
  };

  const addCurrentScenario = () => {
    if (!currentResult) return;
    const tech = currentResult.technical.alternatives || [];
    const econ = currentResult.economic?.alternatives || [];
    const env = currentResult.environmental?.alternatives || [];

    const optVol = Number(
      currentResult.topsis?.best_volume_l ||
      currentResult.technical.summary.optimal_volume_l ||
      tech.at(-1)?.lower_tank_volume_l ||
      0
    );

    const optTech = tech.find((r) => r.lower_tank_volume_l === optVol) || tech.at(-1);
    const optEcon = econ.find((r) => r.lower_tank_volume_l === optVol) || econ.at(-1);
    const optEnv = env.find((r) => r.lower_tank_volume_l === optVol) || env.at(-1);

    const newRecord: ScenarioRecord = {
      id: "scen_" + Date.now(),
      name: newScenarioName.trim() || `Cenário ${scenarios.length + 1} (${currentConfig.project_name || "Netuno"})`,
      timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      config: { ...currentConfig },
      rainName: currentRainName,
      optimalVolume: optVol,
      waterSavingsPct: Number(optTech?.potable_savings_pct || 0),
      annualWaterM3: Number(optTech?.annual_rainwater_m3 || 0),
      vplBrl: Number(optEcon?.npv_brl || 0),
      tirPct: Number(optEcon?.tir_annual_pct || optEcon?.irr_annual_pct || 0),
      paybackYears: optEcon?.discounted_payback_months
        ? (Number(optEcon.discounted_payback_months) / 12.0).toFixed(1)
        : (optEcon?.simple_payback_years || "--"),
      lifetimeCo2Kg: Number(optEnv?.lifetime_net_co2_saved_kg || 0),
      topsisScore: Number(currentResult.topsis?.best_score || 0),
    };

    const updated = [...scenarios, newRecord];
    saveScenariosToStorage(updated);
    setNewScenarioName("");
  };

  const removeScenario = (id: string) => {
    const updated = scenarios.filter((s) => s.id !== id);
    saveScenariosToStorage(updated);
  };

  const clearAllScenarios = () => {
    saveScenariosToStorage([]);
  };

  // Chart data preparation
  const chartData = scenarios.map((s) => ({
    name: s.name,
    "Economia Água (%)": s.waterSavingsPct,
    "VPL (R$)": s.vplBrl,
    "Carbono Saldo (kg CO2e)": s.lifetimeCo2Kg,
    "Score TOPSIS": (s.topsisScore * 100),
  }));

  return (
    <div className="scenario-comparator-root">
      <div className="section-heading">
        <div>
          <h3>Comparador Multicenários & Análise de Sensibilidade</h3>
          <p>
            Salve diferentes variações de projeto (modelos climáticos, áreas de telhado, demandas ou materiais) e compare os indicadores lado a lado.
          </p>
        </div>
      </div>

      {/* Barra para salvar o resultado atual como cenário */}
      <div className="save-scenario-bar">
        <div className="input-wrap-flex">
          <input
            type="text"
            placeholder="Nome do cenário (ex: Clima SSP5-8.5 / Telhado 200m² / Demanda +50%)"
            value={newScenarioName}
            onChange={(e) => setNewScenarioName(e.target.value)}
          />
        </div>
        <button
          type="button"
          className="primary"
          onClick={addCurrentScenario}
          disabled={!currentResult}
        >
          <Plus size={16} /> Salvar Simulação Atual como Cenário
        </button>
      </div>

      {scenarios.length === 0 ? (
        <div className="empty-scenarios-box">
          <Layers size={36} />
          <strong>Nenhum cenário salvo para comparação</strong>
          <p>
            Execute uma simulação e clique em <b>"Salvar Simulação Atual como Cenário"</b> para começar a comparar hipóteses de projeto.
          </p>
        </div>
      ) : (
        <>
          {/* CARDS COMPARATIVOS LADO A LADO */}
          <div className="scenario-cards-grid">
            {scenarios.map((scen, idx) => (
              <div key={scen.id} className="scenario-card">
                <div className="scen-head">
                  <div>
                    <span className="scen-badge">Cenário {idx + 1}</span>
                    <h4>{scen.name}</h4>
                    <small>{scen.rainName}</small>
                  </div>
                  <button
                    type="button"
                    className="scen-del-btn"
                    onClick={() => removeScenario(scen.id)}
                    title="Excluir cenário"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="scen-metrics-list">
                  <div className="scen-metric-row">
                    <span>Cisterna Ótima:</span>
                    <strong>{scen.optimalVolume.toLocaleString("pt-BR")} L</strong>
                  </div>
                  <div className="scen-metric-row">
                    <span>Economia de Água:</span>
                    <strong className="text-emerald">{scen.waterSavingsPct.toFixed(1)}%</strong>
                  </div>
                  <div className="scen-metric-row">
                    <span>Uso Pluvial Anual:</span>
                    <strong>{scen.annualWaterM3.toFixed(1)} m³/ano</strong>
                  </div>
                  <div className="scen-metric-row">
                    <span>VPL 20 Anos:</span>
                    <strong>
                      {scen.vplBrl.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                    </strong>
                  </div>
                  <div className="scen-metric-row">
                    <span>TIR (% a.a.):</span>
                    <strong>{scen.tirPct.toFixed(1)}%</strong>
                  </div>
                  <div className="scen-metric-row">
                    <span>Saldo Carbono:</span>
                    <strong className="text-emerald">{scen.lifetimeCo2Kg.toFixed(0)} kg CO₂e</strong>
                  </div>
                  <div className="scen-metric-row">
                    <span>Score TOPSIS:</span>
                    <strong>{scen.topsisScore.toFixed(3)}</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* GRÁFICO COMPARATIVO DE BARRAS */}
          <div className="chart-card" style={{ marginTop: 24 }}>
            <h4>Comparativo de Economia de Água e Retorno Financeiro</h4>
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={chartData} margin={{ top: 16, right: 20, left: 8, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#d9e7e2" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="Economia Água (%)" fill="#087f6b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Score TOPSIS" fill="#0284c7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* TABELA COMPARATIVA DE MATRIZ DE DECISÃO */}
          <div className="section-card" style={{ marginTop: 20 }}>
            <div className="section-heading">
              <div>
                <h3>Matriz Comparativa de Desempenho</h3>
                <p>Quadro analítico consolidado para suporte à tomada de decisão.</p>
              </div>
              <button type="button" className="ghost" onClick={clearAllScenarios}>
                <Trash2 size={15} /> Limpar todos os cenários
              </button>
            </div>

            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Cenário</th>
                    <th>Telhado (m²)</th>
                    <th>Demanda (L/hab)</th>
                    <th>Cisterna Ótima</th>
                    <th>Economia (%)</th>
                    <th>VPL (R$)</th>
                    <th>TIR (% a.a.)</th>
                    <th>CO₂ Mitigado</th>
                    <th>TOPSIS Score</th>
                  </tr>
                </thead>
                <tbody>
                  {scenarios.map((s) => (
                    <tr key={s.id}>
                      <td><b>{s.name}</b></td>
                      <td>{String(s.config.area || 100)} m²</td>
                      <td>{String(s.config.demand_value || 120)} L</td>
                      <td><b>{s.optimalVolume.toLocaleString("pt-BR")} L</b></td>
                      <td className="text-emerald"><b>{s.waterSavingsPct.toFixed(1)}%</b></td>
                      <td>{s.vplBrl.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</td>
                      <td>{s.tirPct.toFixed(1)}%</td>
                      <td>{s.lifetimeCo2Kg.toFixed(0)} kg</td>
                      <td><b>{s.topsisScore.toFixed(3)}</b></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
