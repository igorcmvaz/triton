import type { ClimateCatalog, ClimateSeriesResponse, Config, JobRecord, TariffCityData } from "./types";

export const API_BASE = import.meta.env.VITE_API_BASE || "/netuno/api/v1";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, options);
  if (!response.ok) {
    let detail = `Erro ${response.status}`;
    try {
      const body = await response.json();
      detail = body.detail || detail;
    } catch {
      // Resposta sem JSON.
    }
    throw new Error(detail);
  }
  return response.json() as Promise<T>;
}

export async function getDefaults(): Promise<Config> {
  const payload = await request<{ config: Config }>("/defaults");
  return payload.config;
}

export async function parseRainfall(file: File): Promise<{ rainfall_mm: number[]; file_name: string }> {
  const form = new FormData();
  form.append("file", file);
  return request("/rainfall/parse", { method: "POST", body: form });
}

export async function importProject(file: File): Promise<{ config: Config; rainfall_mm: number[] }> {
  const form = new FormData();
  form.append("file", file);
  return request("/projects/upload", { method: "POST", body: form });
}

export async function loadClimateCatalog(): Promise<ClimateCatalog> {
  return request<ClimateCatalog>("/climate/catalog");
}

export async function loadClimateCities(query = ""): Promise<string[]> {
  const payload = await request<{ items: string[] }>(`/climate/cities?q=${encodeURIComponent(query)}`);
  return payload.items;
}

export async function loadClimateSeries(
  city: string,
  model = "INM-CM4",
  scenario = "HIST",
  startDate?: string,
  endDate?: string
): Promise<ClimateSeriesResponse> {
  let url = `/climate/series?city=${encodeURIComponent(city)}&model=${encodeURIComponent(model)}&scenario=${encodeURIComponent(scenario)}`;
  if (startDate) url += `&start_date=${encodeURIComponent(startDate)}`;
  if (endDate) url += `&end_date=${encodeURIComponent(endDate)}`;
  return request<ClimateSeriesResponse>(url);
}

export async function createAnalysis(config: Config, rainfall_mm: number[], weights: number[], sensitivity: number) {
  const pipes = Array.isArray(config.pipes_list)
    ? config.pipes_list.map((item) => ({ diameter_mm: Number((item as unknown[])[0]), length_m: Number((item as unknown[])[1]) }))
    : [];
  return request<{ job_id: string; status: string }>("/analyses", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      config,
      rainfall_mm,
      analysis: "all",
      weights,
      weight_sensitivity: sensitivity,
      source: "Netuno Web",
      environmental: {
        lower_material_key: config.lower_tank_material || "PEAD",
        upper_material_key: config.upper_tank_material || "PEAD",
        chlorine_dose_mg_l: config.chlorine_treatment_enabled ? config.chlorine_dose_mg_l : 0,
        chlorine_co2_kg_per_kg: config.chlorine_co2_kg_per_kg || 25,
        system_lifespan_years: config.analysis_period_years || 20,
        pump_count: config.pump_count || 1,
        pipes,
      },
    }),
  });
}

export function getJob(jobId: string): Promise<JobRecord> {
  return request(`/jobs/${jobId}`);
}

export async function loadTariffUfs(): Promise<{ code: string; name: string }[]> {
  const payload = await request<{ items: { code: string; name: string }[] }>("/tariffs/ufs");
  return payload.items;
}

export async function loadTariffCities(uf: string): Promise<string[]> {
  const payload = await request<{ items: string[] }>(`/tariffs/cities?uf=${encodeURIComponent(uf)}`);
  return payload.items;
}

export function loadTariff(uf: string, city: string): Promise<TariffCityData> {
  return request(`/tariffs/${encodeURIComponent(uf)}/${encodeURIComponent(city)}`);
}

export function getExportUrl(jobId: string, format: string, reportType = "summary", lang = "pt", volume?: number): string {
  let url = `${API_BASE}/jobs/${jobId}/export/${format}?report_type=${encodeURIComponent(reportType)}&lang=${encodeURIComponent(lang)}`;
  if (volume != null && !isNaN(volume)) {
    url += `&volume=${encodeURIComponent(volume)}`;
  }
  return url;
}
