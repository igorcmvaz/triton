export type Config = Record<string, string | number | boolean | unknown[]>;

export interface JobRecord {
  job_id: string;
  status: string;
  progress: number;
  message: string;
  error?: string;
  result?: AnalysisResult;
}

export interface AnalysisRow {
  lower_tank_volume_l: number;
  potable_savings_pct?: number;
  annual_rainwater_m3?: number;
  annual_overflow_m3?: number;
  annual_potable_consumed_m3?: number;
  full_supply_days_pct?: number;
  partial_supply_days_pct?: number;
  no_supply_days_pct?: number;
  satisfaction_full_days_pct?: number;
  satisfaction_zero_days_pct?: number;
  delta_potential_per_m3?: number;
  marginal_gain_pct_per_m3?: number;
  capex_total_brl?: number;
  capex_brl?: number;
  npv_brl?: number;
  tir_annual_pct?: number;
  irr_annual_pct?: number;
  simple_payback_years?: number | string;
  discounted_payback_months?: number | null;
  annual_gross_savings_first_year_brl?: number;
  annual_water_savings_brl?: number;
  annual_opex_brl?: number;
  annual_pump_kwh?: number;
  total_embodied_co2_kg?: number;
  embodied_co2_kg?: number;
  annual_pumping_co2_kg?: number;
  annual_avoided_co2_kg?: number;
  annual_operational_co2_kg?: number;
  net_annual_avoided_co2_kg?: number;
  lifetime_net_co2_saved_kg?: number;
  environmental_payback_years?: number;
  environmentally_viable?: boolean;
  score?: number;
  rank?: number;
  distance_to_ideal?: number;
  distance_from_anti_ideal?: number;
  technical_gap_pct?: number;
  economic_gap_pct?: number;
  environmental_gap_pct?: number;
}

export interface ClimateScenario {
  key: string;
  label: string;
  file_suffix: string;
  start_date: string;
  end_date: string;
  default_years: number;
}

export interface ClimateCatalog {
  models: string[];
  scenarios: ClimateScenario[];
  cities?: string[];
}

export interface ClimateSeriesResponse {
  city: string;
  model: string;
  scenario: string;
  start_date: string;
  end_date: string;
  total_days_file: number;
  selected_days: number;
  source_file: string;
  rainfall_mm: number[];
}

export interface TariffTier {
  limite_m3?: number;
  faixa_fim?: number;
  tarifa_agua_r_m3?: number;
  tarifa_esgoto_r_m3?: number;
  tarifa_unitaria?: number;
}

export interface TariffCityData {
  municipio?: string;
  uf?: string;
  concessionaria?: string;
  categoria?: string;
  tarifa_fixa_mensal?: number;
  energia_r_kwh?: number;
  taxa_esgoto_pct?: number;
  faixas?: TariffTier[];
  faixas_agua?: TariffTier[];
  faixas_esgoto?: TariffTier[];
}

export interface MonthlyResultItem {
  month: number;
  name: string;
  precip_mm: number;
  harvested_m3?: number;
  pluvial_consumed_m3?: number;
  potable_consumed_m3?: number;
  spill_m3?: number;
  potable_savings_pct?: number;
  [key: string]: unknown;
}

export interface AnnualCashFlowItem {
  year: number;
  gross_savings_brl: number;
  pump_cost_brl: number;
  om_cost_brl: number;
  chlorine_cost_brl: number;
  net_savings_brl: number;
  discounted_net_savings_brl: number;
  cumulative_npv_brl: number;
}

export interface HydrologicalStats {
  total_days: number;
  annual_average_mm: number;
  max_daily_mm: number;
  rainy_days_count: number;
  dry_days_count: number;
  rainy_days_pct: number;
  monthly_averages_mm: { month: number; name: string; mm: number }[];
}

export interface SingleSimulationDetails {
  lower_tank_vol_l: number;
  potential_savings_pct: number;
  annual_pluvial_m3: number;
  annual_potable_consumed_m3: number;
  annual_spill_m3: number;
  pct_days_full_satisfaction: number;
  pct_days_partial_satisfaction: number;
  pct_days_null_satisfaction: number;
  total_pumped_m3: number;
  total_pump_cycles: number;
  monthly_results?: MonthlyResultItem[];
}

export interface EconomicDetails {
  capex_total_brl: number;
  vpl_brl: number;
  tir_annual_pct: number;
  payback_months?: number | null;
  payback_years?: number | null;
  annual_water_savings_brl: number;
  annual_opex_brl: number;
  annual_pump_kwh: number;
  annual_pump_cost_brl: number;
  lcow_brl_m3: number;
  benefit_cost_ratio: number;
  annual_cash_flows: AnnualCashFlowItem[];
  capex_breakdown?: {
    lower_tank: number;
    upper_tank: number;
    pump: number;
    piping: number;
    accessories: number;
    labor: number;
  };
}

export interface BuildingTemplate {
  id: string;
  name: string;
  icon: string;
  description: string;
  occupantLabel: string;
  defaultResidents: number;
  defaultPerCapita: number;
  defaultShare: number;
  potableIndoorShare: number;
  nonPotableIndoorShare: number;
  gardenArea: number;
  gardenRate: number;
  toiletFlushes: number;
  toiletVolume: number;
  washingCyclesWeekly: number;
  washingVolumePerCycle: number;
  washFloorsWeeklyLiters: number;
}

export interface ScenarioRecord {
  id: string;
  name: string;
  timestamp: string;
  config: Config;
  rainName: string;
  optimalVolume: number;
  waterSavingsPct: number;
  annualWaterM3: number;
  vplBrl: number;
  tirPct: number;
  paybackYears: number | string;
  lifetimeCo2Kg: number;
  topsisScore: number;
}

export interface AnalysisResult {
  generated_at_utc: string;
  metadata?: Record<string, string>;
  rainfall_stats?: HydrologicalStats;
  single_sim?: SingleSimulationDetails;
  economic_details?: EconomicDetails;
  technical: {
    summary: {
      mode?: string;
      optimal_volume_l?: number;
      optimal_potential_pct?: number;
      optimal_annual_rainwater_m3?: number;
      optimal_annual_overflow_m3?: number;
      total_days?: number;
      annual_average_rainfall_mm?: number;
      [key: string]: unknown;
    };
    alternatives: AnalysisRow[];
  };
  economic?: {
    summary?: Record<string, unknown>;
    alternatives: AnalysisRow[];
  };
  environmental?: {
    summary?: Record<string, unknown>;
    alternatives: AnalysisRow[];
  };
  topsis?: {
    best_volume_l: number;
    best_score: number;
    technical_best_volume_l?: number;
    economic_best_volume_l?: number;
    environmental_best_volume_l?: number;
    ranking: AnalysisRow[];
    weights: Record<string, number>;
    weight_sensitivity?: {
      samples: number;
      seed: number;
      winner_frequency_pct: Record<string, number>;
    };
  };
}
