import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
    plugins: [react()],
    base: "/netuno/",
    server: {
        port: 5173,
        proxy: {
            "/netuno/api": "http://127.0.0.1:8000",
        },
    },
});
