import os

os.environ.setdefault("NETUNO_ALLOW_INLINE", "true")
os.environ.setdefault("NETUNO_REDIS_URL", "redis://127.0.0.1:6399/15")

from fastapi.testclient import TestClient

from netuno_web.backend.main import app


client = TestClient(app)


def test_health_and_defaults():
    assert client.get("/netuno/api/v1/health").json()["status"] == "ok"
    defaults = client.get("/netuno/api/v1/defaults")
    assert defaults.status_code == 200
    assert defaults.json()["config"]["area"] > 0


def test_climate_endpoints():
    catalog = client.get("/netuno/api/v1/climate/catalog")
    assert catalog.status_code == 200
    data = catalog.json()
    assert "models" in data
    assert "scenarios" in data
    assert "cities" in data
    assert len(data["models"]) >= 1
    assert len(data["scenarios"]) >= 1

    cities = client.get("/netuno/api/v1/climate/cities?q=Flor")
    assert cities.status_code == 200
    assert "items" in cities.json()


def test_tariffs_endpoints():
    ufs = client.get("/netuno/api/v1/tariffs/ufs")
    assert ufs.status_code == 200
    assert len(ufs.json()["items"]) > 0

    cities = client.get("/netuno/api/v1/tariffs/cities?uf=SC")
    assert cities.status_code == 200
    assert len(cities.json()["items"]) > 0


def test_inline_job_lifecycle():
    response = client.post("/netuno/api/v1/analyses", json={
        "config": {
            "area": 100,
            "runoff_coeff": 0.8,
            "demand_value": 100,
            "residents_count": 3,
            "rainwater_share": 0.4,
            "lower_tank_max": 2000,
            "lower_tank_step": 500,
            "delta_ideal": 5,
        },
        "rainfall_mm": [0, 12, 0, 3, 18, 0, 0] * 60,
        "analysis": "all",
        "weights": [0.33, 0.33, 0.34],
    })
    assert response.status_code == 202
    job_id = response.json()["job_id"]
    job = client.get(f"/netuno/api/v1/jobs/{job_id}")
    assert job.status_code == 200
    assert job.json()["status"] == "finished"

    # Test JSON export
    exported_json = client.get(f"/netuno/api/v1/jobs/{job_id}/export/json")
    assert exported_json.status_code == 200

    # Test CSV export
    exported_csv = client.get(f"/netuno/api/v1/jobs/{job_id}/export/csv")
    assert exported_csv.status_code == 200

    # Test XLSX export
    exported_xlsx = client.get(f"/netuno/api/v1/jobs/{job_id}/export/xlsx")
    assert exported_xlsx.status_code == 200

    # Test Executive HTML export
    exported_exec = client.get(f"/netuno/api/v1/jobs/{job_id}/export/html?report_type=executive")
    assert exported_exec.status_code == 200
    assert "Laudo Técnico Executivo" in exported_exec.text

    # Test Environmental HTML export
    exported_env = client.get(f"/netuno/api/v1/jobs/{job_id}/export/html?report_type=environmental")
    assert exported_env.status_code == 200
    assert "Desempenho Ambiental" in exported_env.text

    # Test Research HTML export
    exported_res = client.get(f"/netuno/api/v1/jobs/{job_id}/export/html?report_type=research")
    assert exported_res.status_code == 200
    assert "Relatório Técnico-Científico" in exported_res.text


