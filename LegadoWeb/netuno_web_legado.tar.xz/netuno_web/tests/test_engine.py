from pathlib import Path

import numpy as np

from netuno_web.backend.engine import execute_analysis, parse_project_document, rainfall_statistics


ROOT = Path(__file__).resolve().parents[2]


def test_rainfall_statistics_respect_calendar_months():
    rainfall = np.ones(60)
    stats = rainfall_statistics(rainfall, "01/01/2024")
    assert stats["monthly_averages_mm"][0]["mm"] == 31
    assert stats["monthly_averages_mm"][1]["mm"] == 29
    assert stats["start_date"] == "01/01/2024"
    assert stats["end_date"] == "29/02/2024"


def test_flat_project_import_resolves_repository_rainfall():
    import json

    document = json.loads((ROOT / "examples" / "estudo_caso_1_florianopolis1.netuno").read_text(encoding="utf-8"))
    parsed = parse_project_document(document)
    assert parsed["config"]["area"] == 180.0
    assert parsed["config"]["rainwater_share"] == 0.4
    assert len(parsed["rainfall_mm"]) > 365


def test_web_engine_uses_shared_core_for_technical_analysis():
    report = execute_analysis({
        "config": {
            "area": 100.0,
            "runoff_coeff": 0.85,
            "demand_value": 120.0,
            "residents_count": 4,
            "rainwater_share": 0.4,
            "lower_tank_mode": 1,
            "lower_tank_max": 2000.0,
            "lower_tank_step": 500.0,
        },
        "rainfall_mm": [0, 10, 0, 4, 20, 0, 0] * 60,
        "analysis": "technical",
    })
    assert report["schema"]["name"] == "netuno-analysis"
    assert report["technical"]["alternatives"][0]["lower_tank_volume_l"] == 0
    assert report["technical"]["summary"]["sweep_grid"]["maximum_volume_l"] == 2000
