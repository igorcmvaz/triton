"""Processador assíncrono da edição web."""

