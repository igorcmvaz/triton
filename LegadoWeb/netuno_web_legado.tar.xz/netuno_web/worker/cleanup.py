"""Remove resultados expirados; execute periodicamente pelo cron do host."""

from netuno_web.backend.jobs import cleanup_expired


if __name__ == "__main__":
    print(f"Arquivos removidos: {cleanup_expired()}")

